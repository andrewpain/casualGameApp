﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public abstract class infoItem : MonoBehaviour
{
    
    protected int rent = 100;
    protected int cost = 1000;
    public string iName = "Item name here";
    public string iDesc = "Item description here";
    public bool isPurchased = false;
    public bool isPermanent = false;
    public bool permanent = false;//possible make this readonly
    public bool unlockableWithAd = false;

    public abstract int calRent();
    public abstract int calCost();


}
