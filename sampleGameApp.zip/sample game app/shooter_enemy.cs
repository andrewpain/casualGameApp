﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class shooter_enemy : MonoBehaviour
{
    // Reference to projectile prefab to shoot

    public GameObject projectile;
    //public float projectileSpeed=1f;
    [Tooltip("If true/checked, then projectile is not guided, thus the enemy/projectile auto calculates the angle to rotate projectile at")]
    public bool defCalRotation = true;
    //public float power = 10.0f;

    public int atOnce = 1;
    public float rotateBy = 45f;
    public int inARow = 1;
    public float rowTime = .5f;
    public float shootIn = 1.25f;//1.5f;

    //[HideInInspector]
    float shootWait = 0f;

    //made true when gameobject colides with borders, thus cant shoot
    //private bool isColliding = false;
    //HARD CODED THE POSION OF PLAYER, SINCE RIGHT NOW PLAYER DOESNT MOVE FOR FINAL PRODUCT OF GAME
    protected readonly float yPos = GameManager.playerYPos;
    protected readonly float zPos = GameManager.playerZPos;

    //private IEnumerator ifCollision;
    movement move;
	protected Animator anim;
	Health he;
    // Use this for initialization
    protected virtual void Start()
    {
        if (GameManager.gm)
        {
            move = gameObject.GetComponent<movement>();
			anim = gameObject.GetComponent<Animator>();
            //if not a boss then reduce based on level
            if (!gameObject.name.Contains("boss"))
            {
                switch (GameManager.gm.level)
                {
                    case 1: break;
                    case 2: shootIn -= .25f; break;
                    case 3: shootIn -= .4f; break;
                    case 4: shootIn -= .55f; break;
                    default: shootIn -= .65f; break;
                }
            }
        }
		he = GetComponent<Health>();
        shootWait = Time.time + shootIn;
        ///PRESUMING THAT THE MOUTH IS THE LAST CHILD OBJECT
        if (!mouth)mouth = gameObject.transform.GetChild(transform.childCount - 1);

    }

   // protected virtual void OnTriggerEnter(Collider other)
   // {
   //     if (other && other.gameObject.name!="wall" && other.gameObject.transform.parent && other.gameObject.transform.parent.name == "surroundings") 
			//isColliding = true;       
   // }

   // protected virtual void OnTriggerExit(Collider other)
   // {
   //     if (other && other.gameObject.name != "wall" && other.gameObject.transform.parent && other.gameObject.transform.parent.name == "surroundings")
   //         isColliding = false;
   // }

    private void FixedUpdate()
    {
        allShootCal();
    }
    protected virtual void allShootCal()
    {
        //if wait time till shot is past, position is high enough, and enough projectiles to not overwhelm player
        if (shootCheck())
        {
            shoot();
            shootAgainCheck();
        }
    }
    protected void  shootAgainCheck()
    {
        if (inARow > 1)
        {
            Invoke("shoot", rowTime);
            if (inARow == 3) Invoke("shoot", rowTime * 2);
        }
    }

    protected bool shootCheck()
    {
        //print("shoot time being checked");
        //print("LEAVING: "+move.leaving.ToString());
        //print("PROJECTILES: " + GameManager.gm.ifCreateProjectiles(transform.position.y).ToString());
        //if wait time till shoot is past, position is high enough, and enough projectiles to not overwhelm player
        bool b = Time.time >= shootWait && he.isAlive && !move.leaving && GameManager.gm && GameManager.gm.ifCreateProjectiles(transform.position.y);
        
        if (b) shootWait = Time.time + shootIn;
        return b;
    }

    protected void getDefRotation(Transform t)
    {
        if (!defCalRotation) return;// 0f;

        else
        {
            //float deltaZ = zPos - pos.z;
            //float deltaY = yPos - pos.y;
            //return (Mathf.Atan2(deltaY, deltaZ) * Mathf.Rad2Deg) - 180;
            Vector3 p = new Vector3(t.position.x,yPos,zPos);
            t.LookAt(p);
            //return 0f;
        }
    }
    public Transform mouth;
    protected Coroutine mouthAni;
    //opens and closes mouth of the enemy
    protected IEnumerator mouthShot()
    {
        if (!mouth) yield break;

        mouth.localScale = new Vector3(1, 1, 1);
        yield return new WaitForSeconds(.25f);
        mouth.localScale = new Vector3(0, 0, 0);
        mouthAni = null;
    }
    public GameObject createProjectile()
    {
        if (mouthAni == null) mouthAni = StartCoroutine(mouthShot());
        GameObject go = Instantiate(projectile, transform.position + transform.forward - transform.up, projectile.transform.rotation) as GameObject;
        go.transform.parent = GameManager.gm.gameObject.transform;
        GameManager.gm.editProjectileCount(false);
        AudioManager.am.playSound("enemyShoot");//not optimised for 3d yet
        return go;//Instantiate(projectile, transform.position + transform.forward - transform.up, projectile.transform.rotation) as GameObject;
    }
    public virtual void shoot() {
        // Instantiante projectile at the camera + 1 meter forward with camera rotation// this moves projectile down from center of enemy
        //for 3D game
        //GameObject np = Instantiate(projectile, transform.position + transform.forward -transform.up, transform.rotation) as GameObject;
        //TESTING FOR 2D GAME
        GameObject np = createProjectile();
        //if(defCalRotation)
        //float angle = 
        getDefRotation(np.transform);
	    //TESTING FOR 2D VERSION OF THE GAME
        //if (atOnce!=2) getDefRotation(np.transform); ;// np.transform.Rotate(angle,0f,0f);
        //if it is required to shoot any more than 1 at a time
        if (atOnce > 1)
        {
            //for 3D game
            //GameObject np = Instantiate(projectile, transform.position + transform.forward -transform.up, transform.rotation) as GameObject;
            //TESTING FOR 2D GAME
            GameObject np1 = createProjectile();
            //float angle1 = 
            getDefRotation(np1.transform);
            if (atOnce == 2)
            {
                //np.transform.Rotate(angle, -rotateBy, 0f);
                //np1.transform.Rotate(angle, rotateBy, 0f);

                //np.transform.Rotate(angle, 0, 0f);
                //np1.transform.Rotate(angle1, 0, 0f);
                np.transform.Rotate(0, -rotateBy, 0f);
                np1.transform.Rotate(0, rotateBy, 0f);

            }
            else if (atOnce == 3)
            {
                //for 3D game
                //GameObject np = Instantiate(projectile, transform.position + transform.forward -transform.up, transform.rotation) as GameObject;
                //TESTING FOR 2D GAME
                GameObject np2 = createProjectile();
                //float angle2 = 
                getDefRotation(np2.transform);

                //np1.transform.Rotate(angle, rotateBy, 0f);
                //np2.transform.Rotate(angle, -rotateBy, 0f);

                //np1.transform.Rotate(angle1, 0, 0f);
                //np2.transform.Rotate(angle2, 0, 0f);
                np1.transform.Rotate(0, rotateBy, 0f);
                np2.transform.Rotate(0, -rotateBy, 0f);
            }
        }
    }
}
