﻿using UnityEngine;
//using System.Collections;

public class move_player : movement {

    //public variables
    //public float moveSpeed = 3.0f;
    //public float gravity = 9.81f;

    private CharacterController myController;
    bool ifAc;
    [HideInInspector] 
    public float border = 0f;
    //float yVal = 1f;
    Vector3 pPos;
    Animator ani;
    // Use this for initialization
    public override void Start()
    {
        myController = gameObject.GetComponent<CharacterController>();
        ifAc = SystemInfo.supportsAccelerometer;
        //yVal = transform.position.y;
        pPos = new Vector3(0, 1, -7);//transform.position; 
        //speed = 8f;
        ani = GetComponent<Animator>();
    }

    public override void startPoints(){}

    [HideInInspector]
    public bool moved = false;
    const float min = .2f;
    //bool aMoved = false;
    //void toggleAniMove()
    //{
    //    aMoved = true;
    //}
    protected override void calMove()
    {
		if (GameManager.gm.jumping)return;
        moved = false;
        //determines how much movement on x axis
        Vector3 movementx = new Vector3();
        //Vector3 movementy = new Vector3();
        Vector3 movementz = new Vector3();
        float inType = 0;
        if (!ifAc && Input.GetAxis("Horizontal") != 0f)
            inType = Input.GetAxis("Horizontal");
        else if (ifAc && (Input.acceleration.x < -min || Input.acceleration.x > min))
            inType = Input.acceleration.x;
        //seting the movement animation
        //if (ani) ani.SetFloat("move", inType);

        if (inType != 0f)
        {
            moved = true;
            movementx = inType * Vector3.right * speed * Time.unscaledDeltaTime;//Time.deltaTime;
        }
        if (transform.position.y != pPos.y || transform.position.z != pPos.z)
        {
            //GameManager.gm.jumping = true;
            pPos.x = transform.position.x;
            transform.position = Vector3.MoveTowards(transform.position, pPos, 2f * Time.unscaledDeltaTime);
        }
        //else if (GameManager.gm.jumping) GameManager.gm.jumping = false;
        //converts combined Vector3 inputs from local space to world space based on position of current gameobject (player)
        ani.SetBool("move", moved);
        if (moved)
        {
            Vector3 movement = transform.TransformDirection(movementx /*+ movementy*/+ movementz);
            //finally actually moves character in direction
            myController.Move(movement);
        }
    }

    protected override void OnTriggerEnter(Collider other) { }
    protected override void OnBecameInvisible() { }

    protected override void OnTriggerStay(Collider other)
    {
        if (!ifBeyondBorders()/*pastXBorder()*/ || GameManager.gm.jumping) return;

        float newX = 0f;
        if (transform.position.x + (transform.lossyScale.x / 2) >= border)
            newX = transform.position.x - (transform.position.x + (transform.lossyScale.x / 2) - border);
        else if (transform.position.x - (transform.lossyScale.x / 2) <= -border)
            newX = transform.position.x + (-border - (transform.position.x - (transform.lossyScale.x / 2)));

        transform.position = new Vector3(newX, transform.position.y, transform.position.z);

    }

    //protected override bool pastXBorder()
    //{
    //    return border != 0f &&(
    //        transform.position.x + (transform.lossyScale.x / 2) >= border || 
    //        transform.position.x - (transform.lossyScale.x / 2) <= -border);
    //}

    protected override bool ifBeyondBorders()
    {
        return border != 0f && (
            transform.position.x + (transform.lossyScale.x / 2) >= border ||
            transform.position.x - (transform.lossyScale.x / 2) <= -border);
    }
}
