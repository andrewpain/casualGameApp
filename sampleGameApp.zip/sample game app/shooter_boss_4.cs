﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

public class shooter_boss_4 : shooter_boss
{
    move_boss_4_randomMoves tr;
    protected override void Start()
    {
        base.Start();
        tr = gameObject.GetComponent<move_boss_4_randomMoves>();
    }
    protected override void allShootCal()
    {
        //restCheck();
        //to check if the boss is still alive, because boss is not auto destroyed when it runs out of life
        if (hb.isAlive && shootCheck() && !tr.waiting)
        {
            if (tr.shooting || lowLife)
            {
                shoot();
                shootAgainCheck();
            }
                //if low life then advanced shots to be made
            if (tr.advShooting || lowLife)
            {
                shoot2();
                shootAgainCheck2();
            }
        }
        //if (!lowLife && GameManager.gm.progressbar.fillAmount <= .5) lowLife = true;
        lowLifeCheck();
    }
}