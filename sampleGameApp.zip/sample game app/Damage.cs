﻿using UnityEngine;
//using System.Collections;

public class Damage : MonoBehaviour {
	
	public float damageAmount = 10.0f;

    bool damageDone = false;
    //public bool damageOnTrigger = true;
    //public bool damageOnCollision = false;
    //public bool continuousDamage = false;
    //public float continuousTimeBetweenHits = 0;
    //private float savedTime = 0;

    //public bool destroySelfOnImpact = false;	// variables dealing with exploding on impact (area of effect)
    //public float delayBeforeDestroy = 0.0f;

    public GameObject explosionPrefab;
    public bool rotateToFace = false;
    public bool detatchChildren = false;
    public string damageSound;
    private void OnTriggerEnter(Collider collision)// used for things like bullets, which are triggers.  
    {
        if (damageDone || //if damage is already done
            collision.gameObject.tag == "Player" && gameObject.tag == "Projectile" ||// if player's projectile hits player
            collision.gameObject.tag == "Enemy" && gameObject.tag == "Enemy_projectile" ||//if enemy's projectile hits itself/another enemy
            collision.gameObject.name.Contains("enemyBomb") && (gameObject.tag == "Enemy_projectile" || gameObject.tag == "Projectile")//if player's/enemy's projectile hits bomb
            ) return;



        //if (damageOnTrigger) {
        //if (collision.gameObject.GetComponent<Health>())
        //{   // if the hit object has the Health script on it, deal damage
        Health h = collision.gameObject.GetComponent<Health>();
        if (h)
        {
            h.ApplyDamage(damageAmount);
            damageDone = true;

            if (explosionPrefab)
            {
                //placed here to rotate back the fireball projectile
                if (rotateToFace) gameObject.transform.Rotate(-90f, 0, 0);
                //detatches children and turns off looping so it will eventually phase out
                if (detatchChildren && gameObject.transform.childCount != 0)
                {

                    ParticleSystem ps = gameObject.transform.GetChild(0).gameObject.GetComponent<ParticleSystem>();
                    Vector3 psScale = ps.gameObject.transform.localScale;
                    if (ps)
                    {
                        ParticleSystem.MainModule psm = ps.main;
                        psm.loop = false;
                    }
                    gameObject.transform.DetachChildren();
                    ps.gameObject.transform.localScale = psScale;
                }

                AudioManager.am.playSound(damageSound,Instantiate(explosionPrefab, transform.position, Quaternion.LookRotation(-transform.forward)));

            }
            if (GameManager.gm.playerInfo.lessSuicide && tag=="Enemy_projectile") gameObject.GetComponent<move_projectile>().destroyFakeTarget();
            if (gameObject) Destroy(gameObject);      // destroy the object whenever it hits something
                                                      //}
        }

        //}

    }


}