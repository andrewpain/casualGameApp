﻿using UnityEngine;
//using System.Collections;
//using System;

public class Health_Enemy : Health
{
    //public float points = 1;

    public bool carryingCoins = false;
    //int coinAmnt = 10;
    [HideInInspector]
    public GameObject coincollect;//interacted with in the movement class
	
    public override void ApplyDamage(float amount)
    {
        explosionSound = "enemyExp";
        if (isAlive)
        {
            isAlive = false;
            if (GameManager.gm)
            {
                //if carrying coins, then add to the player's in game coin amount
                if (carryingCoins)
                {
                    //if (GameManager.gm.playerInfo.moreCoins) coinAmnt *= 2;
                    //GameManager.gm.Collect(coinAmnt);
                    if (coincollect) Instantiate(coincollect, transform.position, coincollect.transform.rotation);
                }
                //adding to players progress
                GameManager.gm.change_progress(false, 1f);
                //for hit enemy mission
                if (GameManager.gm.currentMission && GameManager.gm.currentMission.missionAlias == mission.missionType.hitEnemy)
                    GameManager.gm.currentMission.progressMission(1, transform.position, transform.rotation);
                
            }
            //activateExplosion();
			if (GameManager.powerActive != powerUp.powerType.grenade) activateExplosion();
			else gameObject.GetComponent<Animator>().SetTrigger("hit");
        }
    }

}
