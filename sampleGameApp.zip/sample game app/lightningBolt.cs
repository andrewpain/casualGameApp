﻿//using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightningBolt : MonoBehaviour {

    //Prefab for a line
    //public GameObject LinePrefab;

    //Transparency
    //public float Alpha;

    //The speed at which our bolts will fade out
    //public float FadeOutRate;

    //The color of our bolts
    //public Color Tint { get; set; }

    //The position where our bolt started
    Vector3 boltStart;

    //The position where our bolt ended
    Vector3 boltEnd;

    //public int segmentCount;

    [Tooltip("affects how sporadic and scattered the lightning is/ affects how wide the bolt is allowed to spread")]
    public float boltWildRange;

    LineRenderer [] boltLines; 
    // Use this for initialization
    void Start () {
        boltLines = new LineRenderer[transform.childCount];
        int cc = boltLines.Length;
        for (int i = 0; i < cc; i++)
        {
            boltLines[i] = transform.GetChild(i).gameObject.GetComponent<LineRenderer>();
            //boltLines[i].positionCount = segmentCount;
            //print("BOLT LINE AQUIRED: " + boltLines[i] != null);
        }
	}
    //when lightning is finished showing
    Coroutine fadingNow;
    Coroutine curBolt;
    [HideInInspector]
    public bool boltActive = false;

    public void setBoltPos(Vector3 startPt, Vector3 endPt)
    {
        //if (boltActive) return;
        //boltActive = true;
        //if (curBolt != null) StopCoroutine(curBolt);
        //curBolt = 
        //StartCoroutine(settingBolt(startPt, endPt));
        settingBolt(startPt, endPt);
    }
    
    /*IEnumerator*/ void settingBolt(Vector3 startPt, Vector3 endPt)
    {
        //int count = 0;
        do
        {
            //print("bolt lines cal count: "+count);
            //count++;
            //if lines was fading away, cancel and reset to visible again
            if (fadingNow != null)
            {
                StopCoroutine(fadingNow);
                fadingNow = null;
                int cc = boltLines.Length;
                //setting visibility of lines here to be visible again
                //for (int i = 0; i < cc; i++) ;
            }
            //Prevent from getting a 0 magnitude
            if (Vector3.Distance(startPt, endPt) <= 0)
            {
                Vector3 adjust = Random.insideUnitCircle;
                if (adjust.magnitude <= 0) adjust.x += .1f;
                endPt += adjust;
                print("end point adjusted by: " + adjust);
            }

            //difference from source to destination
            Vector3 slope = endPt - startPt;
            Vector3 normal = (new Vector3(slope.y, -slope.x)).normalized;

            //distance between source and destination
            float distance = slope.magnitude;


            List<float> positions = new List<float>();
            positions.Add(0);

            for (int i = 0; i < distance /1.5/*/ 4*/; i++)
            {
                //Generate random positions between 0 and 1 to break up the bolt
                //positions.Add (Random.Range(0f, 1f));
                positions.Add(Random.Range(.25f, .75f));
            }

            positions.Sort();
            const float Sway = 80;
            const float Jaggedness = 1 / Sway;
            //Start at the source
            //Vector3 prevPoint = startPt;

            //No previous displacement, so just 0
            //float prevDisplacement = 0;

            int pc = positions.Count;
            //check to avoid the chance of returning null
            if (boltLines!=null && boltLines[transform.childCount-1]!=null)
            foreach (LineRenderer lr in boltLines)
            {
                lr.positionCount = pc;
                lr.SetPosition(0, startPt);
                for (int i = 1; i < pc-1; i++)
                {
                    float pos = positions[i];

                    //used to prevent sharp angles by ensuring very close positions also have small perpendicular variation.
                    float scale = (distance * Jaggedness) * (pos - positions[i - 1]);

                    //defines an envelope. Points near the middle of the bolt can be further from the central line.
                    float envelope = pos > 0.95f ? 20 * (1 - pos) : boltWildRange;

                    float displacement = Random.Range(-Sway, Sway);
                    displacement -= (displacement /*- prevDisplacement*/) * (1 - scale);
                    displacement *= envelope;

                    //Calculate the end point of new point in line renderer
                    Vector3 point = startPt + (pos * slope) + (displacement * normal);

                    //activateLine(prevPoint, point, thickness);
                    lr.SetPosition(i, point);
                    //prevPoint = point;
                    //prevDisplacement = displacement;
                }
                lr.SetPosition(pc - 1, endPt);
            }
            //yield return null;
        }
        while (boltActive);
        //where the fading away of the bolt(s) is supposed to happen
        //if (!boltActive)
        //{
        //    fadingNow = StartCoroutine()

        //}
        //curBolt = null;
    }
	
	// Update is called once per frame
	//void Update () {
		
	//}
}
