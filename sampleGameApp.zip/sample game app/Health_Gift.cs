﻿using UnityEngine;
//using System.Collections;
//using System;

public class Health_Gift : Health
{
    public GameObject[] powerUps;// what power ups to choose from
    public GameObject powerCarrier;
    private GameObject chosen_power;

    public override void Start()
    {
        /**HERE IS WHERE CODE FOR POWERUPS IS EDITED TO SUIT NUMBER OF POWER UPS*/

        if (powerUps!=null)chosen_power = powerUps[UnityEngine.Random.Range(0, powerUps.Length)];
        //if avatar's ability allows the player to see the power ups
        if (GameManager.gm && GameManager.gm.playerInfo.morePowerUps && name == "gift(Clone)")
        {
            // Renderer r = gameObject.GetComponent<Renderer>();
			// Mesh m = gameObject.GetComponent<Mesh>();

             string rn = "";
            switch (chosen_power.GetComponent<powerUp>().powerName)
            {
                case powerUp.powerType.auto: rn += "autoGift"; break;
                case powerUp.powerType.shield: rn += "shieldGift"; break;
                case powerUp.powerType.slow: rn += "slowGift"; break;
                case powerUp.powerType.grenade: rn += "grenadeGift"; break;

            }
            GameObject go = Resources.Load("powers/" + rn, typeof(GameObject)) as GameObject;
            Instantiate(go).AddComponent(gameObject.GetComponent<move_spiral>().GetType());// as GameObject;
            //Destroy(gameObject);
            byeBye();
        }
        powerUps = null;
    }
    public override void ApplyDamage(float amount)
    {
        if (isAlive)
        {
            isAlive = false;
            Instantiate(powerCarrier, transform.position, Quaternion.identity).GetComponent<rewardMovement>().setStart(.18f,0,chosen_power);
            //GameManager.gm.addPowerUps(chosen_power);

            activateExplosion();
        }
        
    }
    private void OnDestroy()
    {
        if (GameManager.gm)GameManager.gm.spawn.giftCurrent = false;
    }
}
