﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class move_clouds : movement
{


    cloudSpawner cs;
    // Use this for initialization
    public override void startPoints()
    {
        cs = transform.parent.gameObject.GetComponent<cloudSpawner>();
        //if (cs) print("cloud spawner is here");
        //else print("no cloud spawner");
        speed = .1f;
        //transform.position = new Vector3(startPos.x, startPos.y, Random.Range(minZ, maxZ));
    }

    protected override void calMove()
    {
        gameObject.transform.Translate(Vector3.left * Time.deltaTime * speed);
    }

    protected override bool ifBeyondBorders()
    {
        return transform.position.x - (transform.lossyScale.x / 2) <= (-cs.startPos.x);
    }

    //protected override void OnTriggerEnter(Collider other){ doOutsideCheck(); }
    //protected override void OnTriggerStay(Collider other){ doOutsideCheck(); }
    //private void OnTriggerExit(Collider other){doOutsideCheck();}

    //protected override bool pastXBorder()
    //{
    //    if (cs) return (transform.position.x - (transform.lossyScale.x / 2)) <= (-cs.startPos.x);
    //    else return false;
    //}
}
