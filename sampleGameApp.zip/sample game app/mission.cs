﻿using UnityEngine;
//using System.Collections;
using System;
//#if UNITY_ANDROID
//using UnityEngine.WSA;
//#endif
public abstract class mission : MonoBehaviour
{
    public static readonly TimeSpan timeBetweenMissions = new TimeSpan(0, 4, 0, 0, 0);
    public static readonly TimeSpan timeBetweenGifts    = new TimeSpan(0, 6, 0, 0, 0);
    public static readonly TimeSpan timeBetweenDayGifts = new TimeSpan(0, 24, 0, 0, 0);
    public static readonly string pastMissionKey = "sampleMiss";
    public int count = 0;
    public int maxCount;
    public bool complete = false;//if mission is completed
    public bool oneGame = false;//if mission is to be completed in one game
    public string misc = "";

    public enum missionType {hitEnemy,usePowerUp,playGame,hitPro,hitLaser};
    public missionType missionAlias;

    public enum missionType2 {none, dontMiss, noLifeLost, usePowerUp,notShotAt, useWeapon,useAvatar};
    public missionType2 missionAlias2 = missionType2.none;

    public enum missionTough {easy,medium,hard};
    public missionTough missionDiff;

    public GameObject progressParticle;

    private void Start()
    {
        progressParticle = Resources.Load("missions/plus_particle", typeof(GameObject)) as GameObject;
    }
    /**HERE IS WHERE MISSIONS ARE ADDED TO BE CHOSEN AT RANDOM*/
    public static Type getMission()
    {
        //makes sure not to choose a mission that was chosen recently
        int choice = UnityEngine.Random.Range(0, 13);
        string past = PlayerPrefs.GetString(pastMissionKey,"");

        while (past.Contains(choice.ToString())) choice = UnityEngine.Random.Range(0, 13);
        
        if (past.Length >= 6) past = past.Substring(1);
        
        print("missions after: " + past);
        past += choice.ToString();
        print("missions after add: " + past);
        PlayerPrefs.SetString(pastMissionKey,past);
        switch (choice)
        {
            default: return typeof(mission_useAnyPowerUp);
            case 0: return typeof(mission_dontMiss);//hit enemies without missing
            case 1: return typeof(mission_hitNoLifeLost);//hits enemies without losing life
            case 2: return typeof(mission_useAnyPowerUp);//use any 1 power up
            case 3: return typeof(mission_usePowerUp);//use any power up a number of times
            case 4: return typeof(mission_useSpecPowerUp);//use specific power up
            case 5: return typeof(mission_scoreNoPowerUps);//get a score without using power ups
            case 6: return typeof(mission_notShotAt);//shoot enemies without any projectiles being spawned
            case 7: return typeof(mission_useAvatar);//use a specific avatar
            case 8: return typeof(mission_useWeapon);//use specific weapon
            case 9: return typeof(mission_scoreWithWeapon);//get score with specific weapon
            case 10: return typeof(mission_hitLaserBeforeHit);//shoot lasers just before they shoot
            case 11: return typeof(mission_shootBeforeHit);//shoot projectiles just before it hits
            case 12: return typeof(mission_hitEnemies);//hit a number of enemies
        }

    }

    protected void setDiff(int e, int m, int h)
    {
        if (maxCount == 0)
        {
            switch (UnityEngine.Random.Range(0, 3))
            {
                case 0: missionDiff = missionTough.easy; maxCount = e; break;
                case 1: missionDiff = missionTough.medium; maxCount = m; break;
                case 2: missionDiff = missionTough.hard; maxCount = h; break;
            }
        }

        else
        {
            if (maxCount == e) missionDiff = missionTough.easy;
            else if (maxCount==m) missionDiff = missionTough.medium;
            else if (maxCount==h) missionDiff = missionTough.hard;
        }
    }

    public virtual void setMissionStart(int cc, int mc, string mi)
    {
        if (!oneGame) count = cc;
        maxCount = mc;
        misc = mi;

    }

    
    public abstract string getStatus();
    public abstract void progressMission(int p, Vector3 pos, Quaternion rot);

    protected void finishMission()
    {
        if (!complete)
        {
            complete = true;
            GameManager.gm.gameMissionControl.toggleMissionVisibility(true);
			AudioManager.am.playSound("missionDone");
            Invoke("removeMission", 2f);
        }
    }

    private void removeMission()
    {
        GameManager.gm.gameMissionControl.toggleMissionVisibility(false);
    }

    public int completedMissionGiveReward()
    {
        print("mission difficulty: " + missionDiff.ToString());
        switch (missionDiff)
        {
            //make sure divisible by 15 for reward collector
            default: return 150;
            case missionTough.easy: return 150;
            case missionTough.medium: return 300;
            case missionTough.hard: return 600;
        } 
    }
    ///saves the game localy
    public void saveMission()
    {
        if (GameManager.gamePlayer.mname != "none" || GameManager.gamePlayer.mname != "")
            GameManager.gamePlayer.mname = GetType().ToString();
        if (!oneGame) GameManager.gamePlayer.curcount = count;
        GameManager.gamePlayer.maxcount = maxCount;
        if (misc != "") GameManager.gamePlayer.misc = misc;
        GameManager.gamePlayer.ifMission = true;
        dataControl.savePlayer(GameManager.gamePlayer);
    }

    public static void deleteMissionInfo()
    {
        bool ready = 
            PlayerPrefs.GetInt(GameManager.missionUnsynchedKey, 0) == 1 && 
            PlayerPrefs.GetInt(GameManager.missionUnRewardedKey, 0) == 1;
        if (ready)
        {
            if (PlayerPrefs.HasKey(GameManager.missionUnsynchedKey))
                PlayerPrefs.DeleteKey(GameManager.missionUnsynchedKey);
            PlayerPrefs.DeleteKey(GameManager.missionUnRewardedKey);
            GameManager.gamePlayer.mname = "none";
            GameManager.gamePlayer.curcount = 0;
            GameManager.gamePlayer.maxcount = 0;
            GameManager.gamePlayer.misc = "";
            GameManager.gamePlayer.ifMission = false;

            dataControl.savePlayer(GameManager.gamePlayer);
        }
    }
}
