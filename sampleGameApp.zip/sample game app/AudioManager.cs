﻿//using UnityEngine.Audio;
using UnityEngine;
using System;
using System.Collections;

//[Serializable]
public class AudioManager : MonoBehaviour {
    public static readonly string sfxToggleKey = "sfxToggle";
    public static readonly string musicToggleKey = "musicToggle";
    public static AudioManager am;
    public customSound[] sounds;
    public customSound[] music;
    public static bool sfxEnabled = false;
    public static bool musicEnabled = false;
    private void Awake()
    {
        if (!am)
        {
            am = this;
            sfxEnabled = PlayerPrefs.GetInt(sfxToggleKey, 1) == 1;
			//sfxEnabled = false;
            musicEnabled = PlayerPrefs.GetInt(musicToggleKey, 1) == 1;
			//musicEnabled = false;
			
            if (sfxEnabled) StartCoroutine(createSfx());
            else StartCoroutine(gmCheck());
            if (musicEnabled) StartCoroutine(createMusic());
            else StartCoroutine(gmCheck());
        }
    }
    //when music/sfx button is pushed
    public void toggleAudio(bool isMusic)
    {
        //if sound effects
        if (!isMusic)
        {
            //if (!sfxEnabled && !GetComponent<AudioSource>()) createSfx();
            //else 
            if (!sfxEnabled)
            {
                PlayerPrefs.SetInt(sfxToggleKey, 1);
                sfxEnabled = true;
            }
            else
            {
                PlayerPrefs.SetInt(sfxToggleKey, 0);
                sfxEnabled = false;
            }
        }
        //if music
        else 
        {
            //AudioSource a = null;
            //if (currentMusic!=null) a = currentMusic.source;//Camera.main.gameObject.GetComponent<AudioSource>();
            if (musicEnabled/* && a*/)
            {
                //a.Pause();
                musicEnabled = false;
                PlayerPrefs.SetInt(musicToggleKey, 0);
            }
            else if (!musicEnabled/* && a*/)
            {
                //a.Play();
                musicEnabled = true;
                PlayerPrefs.SetInt(musicToggleKey, 1);
            }
            //else if (!a)
            //{
            //    createMusic();
            //}
        }
    }

    IEnumerator createMusic()
    {
        //if(GameManager.gm.gameState != GameManager.gameStates.GameOver)
        foreach (customSound m in music)
        {

            m.source = gameObject.AddComponent<AudioSource>();
            m.source.clip = m.clip;

            m.source.volume = m.volume;
            m.source.pitch = m.pitch;
            m.source.loop = m.loop;
            yield return new WaitForSeconds(.06f);
        }

        if (!musicEnabled)
        {
            PlayerPrefs.SetInt(musicToggleKey,1);
            musicEnabled = true;
        }
        //print("finished making music");
        StartCoroutine(gmCheck());
    }
    IEnumerator gmCheck()
    {
        yield return new WaitUntil(() => GameManager.gm && GameManager.sceneLoaded);
        GameManager.gm.checkLoad();
    }
    IEnumerator createSfx()
    {
        foreach (customSound s in sounds)
        {
            if (s.addToManager)
            {
                s.source = gameObject.AddComponent<AudioSource>();
                s.source.clip = s.clip;

                s.source.volume = s.volume;
                s.source.pitch = s.pitch;
                yield return new WaitForSeconds(.1f);
            }
        }
        if (!sfxEnabled)
        {
            PlayerPrefs.SetInt(sfxToggleKey, 1);
            sfxEnabled = true;
        }
        //print("finished making sfx");
        StartCoroutine(gmCheck());
    }


    //for 2d sounds that doesnt use 3d space
    public void playSound(string soundName)
    {
        if (!sfxEnabled) return;
        customSound cs = Array.Find(sounds, customSound => customSound.soundName == soundName);
        if (cs != null)
        {
            if (cs.source)
            {
                if (cs.source.isPlaying) cs.source.Stop();
                cs.source.Play();
            }
            //to accomodate the button down sound when sfx is turned on after the game finishes
            else /*if (cs.soundName == "buttonDown")*/
			{			
			    AudioSource.PlayClipAtPoint(cs.clip, Camera.main.gameObject.transform.position);
			    Debug.LogWarning("No sound effect for found sound: " +soundName+", Made play clip at point");
			}
            //else print("No sound effect exist for found sound: " +soundName);
        }

        else Debug.LogWarningFormat("could not find sound: {0} in sound array", soundName);


        //customSound []temp = new customSound[sounds.Length - 1];
        //int index = Array.IndexOf(sounds, cs);
        //for (int i = 0; i < temp.Length; i++)
        //    if (sounds[index]!=cs)
        //        temp[i] = sounds[i];
        //sounds = temp;
    }
    //idealy used for sounds used in a 3d space
    public void playSound(string soundName, GameObject go)
    {
        if (!sfxEnabled) return;
        customSound cs = Array.Find(sounds, customSound => customSound.soundName == soundName);
        if (cs != null)
        {
            AudioSource a = go.AddComponent<AudioSource>();
            a.clip = cs.clip;
            a.volume = cs.volume;
            a.pitch = cs.pitch;
            a.spatialBlend = cs.spatialBlend;
            //a.loop = isLoop;//loop is used mainly for theme music
            //weapons don't play on awake, explosions do
            //a.playOnAwake = playNow;// .Play();
            a.Play();
            
        }
        else Debug.LogWarningFormat("could not find sound: {0} in sound array", soundName);
    }
    //specifically made for boss entering and dying
    public void playSoundAndMusic(string soundName, string musicName)
    {
        if (!sfxEnabled && !musicEnabled) return;
        StartCoroutine(fadeBoss(soundName, musicName));
    }

    IEnumerator fadeBoss(string soundName, string musicName)
    {
        //do
        //{
        //    currentMusic.source.volume -= .1f;
        //    yield return null;
        //}
        //while (currentMusic.source.volume != 0);
        //sfx condition to avoid non smooth transition with music
        if (musicEnabled && sfxEnabled)currentMusic.source.Stop();
        //currentMusic.source.volume = currentMusic.volume;
        //plays boss entry/explosion sound
        if (sfxEnabled)
        {
            customSound cs = Array.Find(sounds, customSound => customSound.soundName == soundName);
            cs.source.Play();
            yield return new WaitWhile(() => cs.source.isPlaying);
        }
        //plays boss music
        playMusic(musicName);
        yield return null;
    }
    customSound currentMusic;

    public void playMusic(string musicName)
    {
        if (!musicEnabled) return;
        customSound cs = Array.Find(music, customSound => customSound.soundName == musicName);
        if (cs != null && musicName!="theme")
        {
            if (fading == null) fading = StartCoroutine(fadeSound(cs));
        }
        else if (musicName == "theme")
        {
            StartCoroutine(playTheme(cs));
        }

        else Debug.LogWarningFormat("could not find music: {0} in music array", musicName);
    }
    //coroutine that plays theme music
    IEnumerator playTheme(customSound theme)
    {        
        theme.source.Play();
        theme.source.loop = true;
		bool play = false;
		do
		{
			yield return new WaitUntil(() => GameManager.gm.gameState != GameManager.gameStates.PrePlay); 
			if(GameManager.gm.gameState == GameManager.gameStates.Playing)play = true;
			else
			{
				
				do{
					if(ItemManager.playingAD && theme.source.isPlaying)theme.source.Pause();
					else if (!ItemManager.playingAD && !theme.source.isPlaying)theme.source.Play();
					yield return null;
					}
				while (GameManager.gm.gameState == GameManager.gameStates.weaponMenu ||
					GameManager.gm.gameState == GameManager.gameStates.avatarMenu);
				
			}
			if (!theme.source.isPlaying)theme.source.Play();

			
		}
		while(!play);
		
        yield return new WaitUntil(() => GameManager.gm.gameState == GameManager.gameStates.Playing);
         
        theme.source.loop = false;
        while (theme.source.isPlaying && theme.source.volume !=0f)
        {
            theme.source.volume -= .01f;
            yield return null;
        }
        Destroy(theme.source);
    }
    Coroutine fading;
    //plays next music sound as soon as the last finishes
    public IEnumerator fadeSound(/*customSound oldM, */customSound newM)
    {
        if (currentMusic != null)
        {
            customSound oldM = currentMusic;
            //currentMusic = newM;
            //print("TRANSITIONING TO: " + newM.soundName);

            if (oldM.source.loop) oldM.source.loop = false;
            yield return new WaitUntil(() => 
            (!oldM.source.isPlaying && GameManager.gm.gameState==GameManager.gameStates.Playing) ||
            GameManager.gm.gameState == GameManager.gameStates.GameOver
            );
            if (GameManager.gm.gameState == GameManager.gameStates.GameOver) yield break;
            //currentMusic = newM;
        }

        //if (GameManager.gm.bossLoading || GameManager.gm.bossMode)
        //    newM.source.volume = currentMusic.source.volume;//for boss fade coroutine
        //else if (newM.source.volume != newM.volume) newM.source.volume = newM.volume;
        currentMusic = newM;
        currentMusic.source.Play();
        currentMusic.source.loop = true;

        //print("TRANSITIONING TO: " + newM.soundName+ " COMPLETE");
        fading = null;
        if (!currentMusic.loop) playMusic((Int32.Parse(currentMusic.soundName) +1).ToString());
        yield return null;
    }

    public void togglePauseMusic(bool b)
    {
        if (!musicEnabled || currentMusic==null) return;
        
        if (currentMusic.source.isPlaying && b) currentMusic.source.Pause();
        else if (!currentMusic.source.isPlaying && !b) currentMusic.source.UnPause();
        //if (pause!=null) StopCoroutine(pause);
        //pause = StartCoroutine(pausing());
    }

    public void slowDownAudio(/*float slow*/)
    {
        if (!sfxEnabled && !musicEnabled) return;
        if (sfxEnabled)
            foreach (customSound s in sounds)
            {
                if (!s.soundName.StartsWith("slow"))
                {
                    s.pitch = Time.timeScale;// slow;
                    if (s.addToManager) s.source.pitch = s.pitch;
                }
            }
        if (musicEnabled)
            foreach (customSound m in music) if (m.source!=null)m.source.pitch = Time.timeScale;
            
    }
    //Coroutine pause;
    //IEnumerator pausing()
    //{
    //    if (currentMusic.source.isPlaying)
    //    {
    //        while (currentMusic.source.volume != 0f) { currentMusic.source.volume -= .1f; yield return null; }
    //        currentMusic.source.Pause();
    //    }
    //    else
    //    {
    //        while (currentMusic.source.volume < currentMusic.volume) { currentMusic.source.volume += .1f; yield return null; }
    //        currentMusic.source.UnPause();
    //    }
    //}
}
