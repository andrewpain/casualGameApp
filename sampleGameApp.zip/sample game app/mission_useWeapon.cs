﻿using UnityEngine;
//using System.Collections;
using System;
public class mission_useWeapon : mission
{


    public GameManager.weapons missionWeapon;
    public override void setMissionStart(int cc, int mc, string mi)
    {
        base.setMissionStart(cc, mc, mi);
        missionAlias = missionType.playGame;
        missionAlias2 = missionType2.useWeapon;

        //setting the power up type that is to be counted for mission
        if (misc == "")
        {
            //max number of weapons in game available to user
            int num = UnityEngine.Random.Range(1, Enum.GetValues(typeof(GameManager.weapons)).Length);
            misc = (Resources.Load("weapons/" + Enum.GetValues(typeof(GameManager.weapons)).GetValue(num).ToString(), typeof(GameObject)) as GameObject).GetComponent<infoWeapon>().iName;
            missionWeapon = (GameManager.weapons)Enum.GetValues(typeof(GameManager.weapons)).GetValue(num);
        }
        else
        {
            bool fin = false;
            int maxed = Enum.GetValues(typeof(GameManager.weapons)).Length;
            for (int i = 0; i < maxed && !fin; i++)
            {
                if (misc == (Resources.Load("weapons/" + Enum.GetValues(typeof(GameManager.weapons)).GetValue(i).ToString(), typeof(GameObject)) as GameObject).GetComponent<infoWeapon>().iName)
                {
                    missionWeapon = (GameManager.weapons)Enum.GetValues(typeof(GameManager.weapons)).GetValue(i);
                    fin = true;
                }
            }
            

        }
        //if max count not set, thus new mission
        setDiff(4, 8, 16);
        //setDiff(1, 2, 3);

    }

    public override string getStatus()
    {
        if (!complete) return string.Format("Use the {0} in {1} game(s). {2}/{3} completed", misc, maxCount, count, maxCount);
        else return string.Format("Use the {0} {1} times completed! :)", misc,maxCount);
    }

    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        if (GameManager.gm.weapon.GetComponent<infoWeapon>().iName == misc)
        {
            count += p;
            if (count >= maxCount) finishMission();
        }
    }
}
