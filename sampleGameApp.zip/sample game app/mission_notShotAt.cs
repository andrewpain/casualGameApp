﻿using UnityEngine;
//using System.Collections;

//hit a number of enemies without being shot at. (makes the player shoot fast)
public class mission_notShotAt : mission
{

    public override void setMissionStart(int cc, int mc, string mi)
    {
        //all base does is set the current count
        base.setMissionStart(cc, mc,mi);
        oneGame = true;
        missionAlias = missionType.hitEnemy;
        missionAlias2 = missionType2.notShotAt;
        //if the mission hasnt been set, thus new mission
        setDiff(10, 20, 40);
        //setDiff(1,2,3);

        //doneMessage = "Hit " + maxCount + " enemies without missing completed! :)";

    }


    public override string getStatus()
    {
        if(!complete)return "Hit " + maxCount + " enemies without seeing any projectiles. " + count + "/" + maxCount + " completed";
        else return "Hit " + maxCount + " enemies without seeing any projectiles completed! :)";

    }
    //public override string getDoneMsg()
    //{
    //    return "Hit " + maxCount + " enemies without seeing any projectiles completed! :)";
    //}
    //keeps track of if shot at
    bool pFree = true;
    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        if (pFree && !complete)
        {
            if (p > 0)
            {
                count += p;
                Instantiate(progressParticle, pos, rot);
            }
            else pFree = false;
            if (count >= maxCount && pFree) finishMission();
        }
    }


}
