﻿using UnityEngine;
//using System.Collections;

[System.Serializable]
public class customSound
{
    public string soundName;

    public bool addToManager = false;//if sound is used in 2d or 3d space NOTE: is not used for music
    public AudioClip clip;

    [Range(0f,1f)]
    public float volume =1;
    [Range(.1f, 3f)]
    public float pitch=1;
    [Range(0f, 1f)]
    public float spatialBlend;

    public bool loop;//NOTE: only used for music


    [HideInInspector]
    public AudioSource source;
}
