﻿using UnityEngine;
//using System.Collections;

public class mission_useAnyPowerUp : mission
{
    public override void setMissionStart(int cc, int mc,string mi)
    {
        missionAlias = missionType.usePowerUp;
        missionDiff = missionTough.easy;

    }
    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        finishMission();
    }

    public override string getStatus()
    {
        if(!complete)return "Use any power up in a game";
        else return "Use any power up completed! :)";

    }

    //public override string getDoneMsg()
    //{
    //    return "Use any power up completed! :)";
    //}
}
