﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class shooter_boss : shooter_enemy {

    protected bool isShooting = true;
    protected float shootRest = 0;
    protected float shootTimer = 15f;

    [Tooltip("Time spent shooting")]
    public float shootTimeCap = 15f;

    [Tooltip("Time spent resting")]
    public float restTimeCap = 5f;

    protected bool lowLife = false;
    public GameObject projectile1;
    //public GameObject projectile2;
    protected Health_Boss hb;
    //these variables are for when the boss' life is below half
    public int atOnce2 = 1;
    public float rotateBy2 = 45f;
    public int inARow2 = 1;
    public float rowTime2 = .5f;
    public float shootIn2 = 1.5f;

    protected override void Start()
    {
        base.Start();
        hb = gameObject.GetComponent<Health_Boss>();
        shootRest = Time.time + shootTimeCap;

    }

    //protected override void OnTriggerEnter(Collider other) { }
    //protected virtual void OnTriggerStay(Collider other) { }
    private void OnBecameInvisible() { }

    protected void restCheck()
    {
        if (Time.time >= shootRest)
        {
            isShooting = !isShooting;
            if (isShooting) shootTimer = shootTimeCap;//time spent shooting
            else shootTimer = restTimeCap;//time spent resting
            shootRest = Time.time + shootTimer;
        }
    }
    protected override void allShootCal()
    {
        restCheck();
        //to check if the boss is still alive, because boss is not auto destroyed when it runs out of life
        if (isReadyToShoot())
        {
            //suppose to shoot
            shoot();
            shootAgainCheck();
            //if low life then advanced shots to be made
            if (lowLife)
            {
                shoot2();
                shootAgainCheck2();
            }
        }
        lowLifeCheck();
        //if (!lowLife && GameManager.gm.progressbar.fillAmount <= .5)
        //{
        //    lowLife = true;
        //    AudioManager.am.playMusic("8");
        //}
    }
    protected void lowLifeCheck()
    {
        if (!lowLife && GameManager.gm.progressbar.fillAmount <= .5)
        {
            lowLife = true;
            AudioManager.am.playMusic("8");
        }
    }
    protected bool isReadyToShoot()
    {
        return hb.isAlive && shootCheck() && isShooting;
    }

    public override void shoot()
    {
        base.shoot();
    }
    protected void shoot2()
    {
        createProjectile2();
    }
    GameObject createProjectile2()
    {
        //anim.SetTrigger("shoot");
        if (mouthAni == null) mouthAni = StartCoroutine(mouthShot());
        GameObject go = Instantiate(projectile1, transform.position + transform.forward - transform.up, projectile1.transform.rotation) as GameObject;
        go.transform.parent = GameManager.gm.gameObject.transform;
        GameManager.gm.editProjectileCount(false);
        return go;// Instantiate(projectile1, transform.position + transform.forward - transform.up, projectile1.transform.rotation) as GameObject;
    }

    protected void shootAgainCheck2()
    {
        if (inARow2 > 1)
        {
            Invoke("shoot2", rowTime2);
            if (inARow2 == 3) Invoke("shoot2", rowTime2 * 2);
        }
    }

    //protected abstract void shoot2();

}
