﻿using UnityEngine;
//using System.Collections;

public class move_projectile_circle : move_projectile
{

    public Vector3 direction;
    public override void Start()
    {
        base.Start();

        
        

        //TO DERERMINE WHICH DIRECTION IS BEST FOR WHICH GENERAL POSITION (LEFT, RIGHT) SECTION ON SCREEN
        //left
        //if (transform.position.x < 0f) direction = Vector3.up;// forward;//down;
        //right
        //else if (transform.position.x >= 0f) direction = Vector3.down;// back;// up;



        
    }

    protected override void calMove()
    {
        if (target)
        {
            transform.LookAt(target);
            //transform.RotateAround(target.position, direction, speed * Time.deltaTime);
            //transform.position = Vector3.MoveTowards(transform.position, target.position, speed / 5 * Time.deltaTime);
            transform.position = Vector3.Slerp(transform.position, target.position, speed * Time.deltaTime);
            transform.position = Vector3.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
            //rocket is no longer moving, then destory it , to patch slight hickup with rockets moving to fake target
            if (transform.position == target.position)
            {
                Health_Projectile hp = gameObject.GetComponent<Health_Projectile>();
                if(hp)hp.activateExplosion();
            }
        }
        else
        {
            transform.position += transform.forward * speed * Time.deltaTime;
        }
    }


}
