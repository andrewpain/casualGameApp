﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class playButtonSounds : MonoBehaviour {


    void playButtonDownSound()
    {
        AudioManager.am.playSound("buttonDown");
    }

}
