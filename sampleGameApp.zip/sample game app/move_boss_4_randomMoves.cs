﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class move_boss_4_randomMoves : move_boss
{
    bool moving = false;
    float moveTime = 15f;
    float pauseTime = 7.5f;
    //float waitTime = 7.5f
    float timeStart = 0;
    [HideInInspector]
    public bool shooting = true, advShooting = false, waiting = false;

    //MeshRenderer mr;
    //BoxCollider bc;
    Animator an;
    Vector3 tPos;
    Vector3 minRange;
    Vector3 maxRange;
    //Transform target;
    //}
    public override void startPoints()
    {
        //speed = 35;
        //target = GameManager.gm.player.transform;
        //mr = gameObject.GetComponent<MeshRenderer>();
        //bc = gameObject.GetComponent<BoxCollider>();
        an = gameObject.GetComponent<Animator>();

        minRange = GameManager.gm.MinRange;
        maxRange = GameManager.gm.MaxRange;

        float randomx = (minRange.x + maxRange.x) / 2;//middle
        float randomy = maxRange.y - (transform.lossyScale.y / 2) - 1f;// at the top of the screen
        //float randomz = 0f;// closer to player than where enemies usually spawn
        //TESTING FOR 3D GAME
        float randomz = minRange.z - (transform.lossyScale.z / 2); //minRange.z;
        transform.position = new Vector3(randomx, randomy, randomz);
        //print("X: " + randomx);
        //print("Y: " + randomy);
        //randomPos();
        timeStart = Time.time;
    }
    int border = 0;
    bool touchBorder = false;
    void randomPos()
    {
        float randomx = UnityEngine.Random.Range(minRange.x + (transform.lossyScale.x / 2), maxRange.x - (transform.lossyScale.x / 2));//middle
        float randomy = UnityEngine.Random.Range(minRange.y + 2 + (transform.lossyScale.y / 2), maxRange.y - (transform.lossyScale.y / 2));//middle
        //float randomz = minRange.z; //0f;// closer to player than where enemies usually spawn
        
        switch (border)
        {
            //max y
            case 2:
                border = 0;
                randomx = UnityEngine.Random.Range(minRange.x+1.5f, maxRange.x-1.5f);
                randomy = maxRange.y-1.5f;
                break;
            //max x
            case 0:
                border = 1;
                randomx = maxRange.x-1.5f;
                randomy = UnityEngine.Random.Range(minRange.y, maxRange.y-1.5f);
                break;
            //min x
            case 1:
                border = 2;
                randomx = minRange.x-1.5f;
                randomy = UnityEngine.Random.Range(minRange.y, maxRange.y-1.5f);
                break;
        }
        //print("X: " + randomx);
        //print("Y: " + randomy);
        //transform.position = new Vector3(randomx, randomy, randomz);
        tPos = new Vector3(randomx, randomy, transform.position.z);
        //touchBorder = false;
    }

    protected override bool ifBeyondBorders()
    {
        //return false;//throw new NotImplementedException();
        return 
        transform.position.y + (transform.lossyScale.y / 2) >= (GameManager.gm.MaxRange.y -2.5f) ||
        transform.position.y - (transform.lossyScale.y / 2) <= .5f ||
        transform.position.x + (transform.lossyScale.x / 2) >= GameManager.gm.MaxRange.x -.5f ||
        transform.position.x - (transform.lossyScale.x / 2) <= GameManager.gm.MinRange.x +.5f;
        
    }

    protected override void OnTriggerStay(Collider other)
    {
        if (!moving || touchBorder || !ifBeyondBorders()) return;
        touchBorder = true;
        randomPos();
    }

    private void OnTriggerExit(Collider other)
    {
        if (touchBorder) touchBorder = false;
    }

    void moveNow()
    {
        //print("moving now");
        waiting = false;
        timeStart = Time.time;
        moving = true;
        shooting = false;
        advShooting = true;
    }

    protected override void calMove()
    {
        if (moving)
        {
            //transform.LookAt(target);
            //print("suppose to move");
            transform.position = Vector3.MoveTowards(transform.position, tPos, Time.deltaTime * speed);
            float dis = (Vector3.Distance(transform.position, tPos));
            if (dis == 0f)
            {
                //print("distance: " + dis);
                randomPos();
            }
            if ((Time.time - timeStart) >= moveTime )
            {
                //print("not moving");
                timeStart = Time.time;
                moving = false;
                advShooting = false;
                shooting = true;
                an.SetTrigger("still");
            }
        }
        //if not moving
        else if ((Time.time - timeStart) >= pauseTime && !waiting)
        {
            //print("about to move");
            waiting = true;
            randomPos();
            Invoke("moveNow", pauseTime);
            an.SetTrigger("move");

        }
        


    }
}