﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class cloudSpawner : MonoBehaviour {

    public Vector2 startPos;//x is 300, y is 222
    //public float minZ;
    //public float maxZ;
    public int maxClouds = 10;
    public float secsPerCloud = 10;
    float timer = 0;

    public GameObject[] allClouds;
    // Use this for initialization
    void Start () {
        timer = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
        if (GameManager.gm && GameManager.gm.gameState == GameManager.gameStates.Playing && 
            transform.childCount < maxClouds && Time.time - timer >secsPerCloud)
        {
            int i = Random.Range(0, allClouds.Length);
            Vector3 pos = allClouds[i].transform.position;
            GameObject go = Instantiate(allClouds[i], transform);
            //go.transform.parent = transform;
            go.transform.localPosition = new Vector3(startPos.x, startPos.y, 0/*minZ*/); // allClouds[i].transform.rotation));
            go.transform.localEulerAngles = new Vector3(0, Random.Range(0, 80), 0);//random rotation to give 3D look
            //go.transform.localScale = new Vector3(.02f, .02f, .02f);
            timer = Time.time;
        }
	}
}
