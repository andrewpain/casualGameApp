﻿using UnityEngine;
//using System.Collections;

//this class simply forbits the boss from exiting from the player's view and exiting
public abstract class move_boss : movement
{
    Health_Boss bossHealth;

    public override void Start()
    {
        bossHealth = gameObject.GetComponent<Health_Boss>();
        //speed = 3;
        startPoints();
    }
    //method can still be overridden
    protected override void OnTriggerEnter(Collider other){}
    protected override void OnTriggerStay(Collider other){}
    protected override void OnBecameInvisible(){}

    protected override void FixedUpdate()
    {
        if (GameManager.gm && GameManager.gm.gameState == GameManager.gameStates.Playing && bossHealth.isAlive) calMove();
    }

    protected override bool ifBeyondBorders()
    {
        return false;//throw new NotImplementedException();
    }
}
