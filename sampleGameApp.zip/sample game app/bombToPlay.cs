﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class bombToPlay : MonoBehaviour {

    
    private void Start()
    {
        if (GameManager.gm) GameManager.gm.bombMode = true;
    }
    private void OnDestroy()
    {
        if (GameManager.gm) GameManager.gm.bombMode = false;
    }
}
