﻿using UnityEngine;
using System.Collections;
//using System;

public class Health_Boss : Health
{
    [HideInInspector]
    public float healthPoints = 1f;
    bool ifSpray = false;
    bool ifAuto = false;
    public GameObject preExplosion;
    //public GameObject explosion2;
    [Tooltip("MAKE SURE THE BODY OBJECT IS THE FORST ONE, FOR TAKING DAMAGE ANIMATION")]
    public MeshRenderer[] visibleRenderers;

    //Animator bossAnim;
    [HideInInspector]
    public Material bossMat;
    public float hitTime = .5f;
    public GameObject lifeHeart;
    public override void Start()
    {
        //healthPoints = 1;

        base.Start();
        //this sets the spray to avoid the boss' life from going down to quickly
        if (GameManager.gm)
        {
            shooter_weapon sw = GameManager.gm.weapon.gameObject.GetComponent<shooter_weapon>();
            ifSpray = sw.isSpray;
            ifAuto = sw.isAuto;
            //if (ifSpray)healthPoints *= 9;
            //if (ifAuto) healthPoints *= 7;
            healthPoints = GameManager.gm.prepareForBoss(ifSpray, ifAuto);
            bossMat = visibleRenderers[0].gameObject.GetComponent<Renderer>().material;

        }
        StartCoroutine(doBulletTime(.1f, 5f, isAlive));
    }
    bool grenadeUsed = false;
    bool oneHeart = true;
    void changeBackMat()
    {
        //bossMat.SetColor("_Color", Color.black);
        if (isAlive) bossMat.SetColor("_EmissionColor", Color.black);

        else //if (!isAlive)
        {

            gameObject.GetComponent<BoxCollider>().enabled = false;

            if (oneHeart)
            {
                oneHeart = false;
                Vector3 nPos = transform.position;
                nPos.z = 0;
                Instantiate(lifeHeart, nPos, Quaternion.identity).GetComponent<rewardMovement>().setStart(1.5f, 0);
                StartCoroutine(doPreExps());

            }
        }
    }
    public override void ApplyDamage(float amount)
    {
        if (!isAlive) return;

        if (GameManager.gm && (GameManager.powerActive == powerUp.powerType.auto || GameManager.powerActive == powerUp.powerType.grenade))
        {
            //this is so that when player shoots the boss after the grenade, the boss doesnt take damage as though tho the power up is still being used
            if (GameManager.powerActive == powerUp.powerType.grenade)
            {
                if (!grenadeUsed && amount > 2)
                {
                    grenadeUsed = true;
                    //Invoke("endGrenade", 3f);
                    if (ifSpray) amount *= 9;
                    if (ifAuto) amount *= 7;
                }
            }
            else
            {
                //assumes that 9 projectiles hit boss since ALL spray weapons shoot nine projectiles
                if (ifSpray) amount *= 9;
                if (ifAuto) amount *= 7;
            }
        }
        else if (grenadeUsed) grenadeUsed = false;

        healthPoints -= amount;
        isAlive = healthPoints > 0;

        if (GameManager.gm) GameManager.gm.change_progress(true, healthPoints);

        //changing the material colour of the boss for a very shot space of time
        //bossMat.SetColor("_Color", Color.white);
        bossMat.SetColor("_EmissionColor", Color.white);
        Invoke("changeBackMat", hitTime);


    }
    Coroutine preExp;
    Coroutine bulTime;
    IEnumerator doPreExps()
    {

        //Coroutine curr =
        if (preExp == null && bulTime == null)
        {
            //transform.position = GameManager.explosionLocation(transform.position);
            Vector3 ePos = GameManager.explosionLocation(transform.position);
            float x = ePos.x - transform.lossyScale.x / 2;
            float y = ePos.y - transform.lossyScale.y / 2;
            float z = ePos.z - transform.lossyScale.z / 2;

            float x2 = ePos.x + transform.lossyScale.x / 2;
            float y2 = ePos.y + transform.lossyScale.y / 2;
            float z2 = ePos.z - transform.lossyScale.z / 2;
            preExp = StartCoroutine(gameOverControl.repeatParticles(preExplosion, .25f, new Vector3(x, y, z), new Vector3(x2, y2, z2),"bossSmall"));
            yield return new WaitForSecondsRealtime(2.5f);
            //if the boss has children with mesh renderers, make those invisible as well
            foreach (MeshRenderer mr in visibleRenderers) mr.enabled = false;
            //print("BIG Explosions!");
            activateExplosion();
            //print("bullet time!");
            bulTime = StartCoroutine(doBulletTime(.2f, 8f, isAlive));
        }

    }

    private IEnumerator doBulletTime(float slow, float time, bool livingNow)
    {
        // slowDownTo = slow;
        //endBulletTimeIn = time;
        if (GameManager.powerActive != powerUp.powerType.slow &&
            GameManager.powerActive != powerUp.powerType.grenade)
        {
            const float ifSlow = 1;//determines the max the slow motion would return to; 1 as default if returning to regular time scale
            Time.timeScale = slow;//slowDownTo;
            Time.fixedDeltaTime = Time.timeScale * .02f;
            //AudioManager.am.slowDownAudio();
            while (Time.timeScale < ifSlow && isAlive == livingNow &&//isAlive == livingNow is to ensure that this loop is not being run twice by two different coroutines!
                (GameManager.powerActive != powerUp.powerType.slow &&
                GameManager.powerActive != powerUp.powerType.grenade))
            {
                float usdt = (1 / time/*endBulletTimeIn*/) * Time.unscaledDeltaTime;
                //slowly raises the time scale back to regular time scale
                if (GameManager.gm && GameManager.gm.gameState == GameManager.gameStates.Playing)
                {
                    Time.timeScale += usdt;
                    Time.timeScale = Mathf.Clamp(Time.timeScale, 0, ifSlow);
                    Time.fixedDeltaTime = Time.timeScale * .02f;
                    //print("Time scale: " + Time.timeScale);
                }
                yield return new WaitForSecondsRealtime(usdt);
            }
            //to fix the glitch the the boss dying and nothing happening
        }
        //print("bullet time finished");
        //AudioManager.am.slowDownAudio();
        if (!livingNow)
        {

            //print("suppose to initiate boss death");
            if (GameManager.gm && GameManager.gm.bombMode)
            {
                //print("waiting for explosion to finish so initiate Boss Death");
                yield return new WaitWhile(() => GameManager.gm.bombMode);
            }

            Destroy(gameObject);
        }
        //yield return null;

    }

    public float shakeRange = .5f, shakeSpeed = .1f, shakeTime = 2.5f;
    public override void activateExplosion()
    {
        //HAVE TO CALL A METHOD FROM THE GAMEMANAGER CLASS HERE THAT WOULD TRACK MISSION PROGRESS IF ANY 
        //if (transform.childCount > 0) transform.DetachChildren();
        //if (explosionPrefab)
        //print("regular explosions now");
        //AudioManager.am.playSound("bossBig");
        AudioManager.am.playSoundAndMusic("bossBig", "9");
        Instantiate(explosionPrefab, transform.position, explosionPrefab.transform.rotation);
        GameManager.gm.setCamManualMove(shakeRange, shakeSpeed, shakeTime);


        //Instantiate(explosion2, transform.position, explosion2.transform.rotation);
    }



}
