﻿using UnityEngine;
//using System.Collections;

public class infoAvatar : infoItem
{
    public GameManager.avatars identity;

    [Tooltip("self explanatory")]
    public bool moreLife;//done

    [Tooltip("Gives the player the ability to see into the power up boxes")]
    public bool morePowerUps;//done

    [Tooltip("Actually makes the bombs fail to explode")]
    public bool lessBombs;//done

    [Tooltip("self explanatory")]
    public bool moreCoins;//done...ish (frame rate issue) UPDATE : FIXED

    [Tooltip("actually is less aim from enemy missiles")]
    public bool lessSuicide;//done..more or less

    public void setAbilities()
    {
        if (moreLife) GameManager.gm.playerHealth.startHealthPoints+=1;

        //if (morePowerUps) GameManager.gm.spawn.enemiesPerGift -= 10;

        //if (lessBombs) GameManager.gm.spawn.enemiesPerBomb += 5;
        //GameManager.gm.spawn.enemiesPerCoin -= 10;
        ParticleSystem.EmissionModule em = GameManager.gm.spawn.coinCollected/*coinParticle*/.GetComponent<ParticleSystem>().emission;
        ParticleSystem.Burst b;
        if (moreCoins)
        {
            //em.rateOverTime = 25f;
            b = new ParticleSystem.Burst(0f, 1, 2, 1f);
            //em.SetBurst(0, b);
        }
        else /*em.rateOverTime = 10;*/b = new ParticleSystem.Burst(0f, 1, 1, .1f);
        em.SetBurst(0, b);


        //if (lessSuicide) GameManager.gm.spawn.enemiesPerSuicide += 10;

    }

    public override int calRent()
    {
        if (rent > 100) return rent;

        //logically setting the price, assuming the price starts at 100 by default
        if (moreLife) { rent += 300; if (morePowerUps || lessBombs || moreCoins || lessSuicide) rent += 150; }
        if (morePowerUps) { rent += 300; if (moreLife || lessBombs || moreCoins || lessSuicide) rent += 300; }
        if (lessBombs) { rent += 150; if (morePowerUps || moreLife || moreCoins || lessSuicide) rent += 200; }
        if (moreCoins) { rent += 150; if (morePowerUps || lessBombs || moreLife || lessSuicide) rent += 150; }
        if (lessSuicide) { rent += 100; if (morePowerUps || lessBombs || moreCoins || moreLife) rent += 100; }

        return rent;
    }
    public override int calCost()
    {
        if (cost > 1000) return cost;

        //logically setting the price, assuming the price starts at 100 by default
        if (moreLife) { cost += 3000; if (morePowerUps || lessBombs || moreCoins || lessSuicide) cost += 1500; }
        if (morePowerUps) { cost += 3000; if (moreLife || lessBombs || moreCoins || lessSuicide) cost += 3000; }
        if (lessBombs) { cost += 1500; if (morePowerUps || moreLife || moreCoins || lessSuicide) cost += 2000; }
        if (moreCoins) { cost += 1500; if (morePowerUps || lessBombs || moreLife || lessSuicide) cost += 1500; }
        if (lessSuicide) { cost += 1000; if (morePowerUps || lessBombs || moreCoins || moreLife) cost += 1000; }

        return cost;
    }
}
