﻿using UnityEngine;
//using System.Collections;

public class mission_hitLaserBeforeHit : mission
{

    public override void setMissionStart(int cc, int mc, string mi)
    {
        //all base does is set the current count
        base.setMissionStart(cc, mc, mi);
        //oneGame = true;
        missionAlias = missionType.hitLaser;
        //missionAlias2 = missionType2.hitPro;
        //if the mission hasnt been set, thus new mission
        setDiff(10, 20, 30);
        //setDiff(1, 2, 3);
        //doneMessage = "Hit " + maxCount + " enemies without missing completed! :)";

    }


    public override string getStatus()
    {
        if(!complete)return "Hit " + maxCount + " lasers just before they shoot. " + count + "/" + maxCount + " completed";
        else return "Hit " + maxCount + " lasers just before they shoot completed! :)";

    }
    //public override string getDoneMsg()
    //{
    //    return "Hit " + maxCount + " lasers just before they shoot completed! :)";
    //}

    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        count += p;
        if (count <= maxCount) Instantiate(progressParticle, pos, rot);
        if (count >= maxCount) finishMission();
    }


}

