﻿using UnityEngine;
//using System.Collections;

public abstract class bounce : movement
{
    protected bool turn = false;
    bool turnFin = false;
    protected string wall;
    protected string exitWall;
    Coroutine c;
    protected override void OnTriggerEnter(Collider other)
    {
        triggerCheck(other);
    }
    void triggerCheck(Collider other)
    {
        if (other.gameObject.name == wall && !turn && !turnFin)
            turn = true;

        else if (other.gameObject.name == exitWall && turn && turnFin)
            base.OnTriggerStay(other);
    }
    protected override void OnTriggerStay(Collider other)
    {
        triggerCheck(other);
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.name == wall) turnFin = true;
    }

}
