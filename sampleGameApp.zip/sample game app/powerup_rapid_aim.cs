﻿using UnityEngine;
//using System.Collections;

public class powerup_rapid_aim : MonoBehaviour {

    //public GameObject player;
    //GameObject rapid;
    powerup_rapidRage rapid;
    private bool dir_switch = false;
    //to stop code from making projectile too fast
    private float power= 5;
    //[SerializeField]
    public float timeOut = 1.0f;

    void Start() {

        if (GameManager.gm && GameManager.powerActive == powerUp.powerType.auto)
            rapid = ((powerup_rapidRage)GameManager.gm.activePowerUp);
        if (rapid) power = 35f;

        //moves forward here to attempt the zigzagging of projectile
        gameObject.transform.Translate(transform.forward * Time.deltaTime * power);
        dir_switch = true;
        
        Invoke("timeUp", timeOut); 
    }


    private void timeUp()
    {
        //if (/*detatchChildren && */gameObject.transform.childCount != 0)
        //{
        //    gameObject.transform.DetachChildren();
        //}
        Destroy(gameObject);
    }

    // Update is called once per frame
    void Update () {

        if (!dir_switch) return;

        else if (rapid && rapid.isActive)
        {
            if (rapid.closestEnemy)
            {
                transform.LookAt(rapid.closestEnemy.transform);
                transform.position = Vector3.MoveTowards(transform.position, rapid.closestEnemy.transform.position, Time.deltaTime * power);
            }
            //just moves the projectile forward if no target to aim at while in rapid fire mode
            else gameObject.transform.Translate(/*transform.forward*/Vector3.forward * Time.deltaTime * power);

        }
        //if rapid mode was stitched on but came off after
        else gameObject.transform.Translate(/*transform.forward*/Vector3.forward * Time.deltaTime * power);

    }
}
