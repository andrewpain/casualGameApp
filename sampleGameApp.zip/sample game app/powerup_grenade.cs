﻿using UnityEngine;
using System.Collections;
using System.Linq;

public class powerup_grenade : powerUp {

    private GameObject[] allenemies;
    private GameObject[] allprojectiles;
    private GameObject[] allothers;
    public GameObject explosionParticle;
    public float damageAmount = 20f;
    public float shakeRange = .5f, shakeSpeed = .1f, shakeTime = 2.5f;
    // Use this for initialization
    //public void Start () {
        //powerName = powerType.grenade;
    //}

    public override void activeOn()
    {
        base.activeOn();
        Instantiate(explosionParticle, GameManager.gm.player.transform.position,explosionParticle.transform.rotation);
        if (GameManager.gm) GameManager.gm.bombMode = true;
        GameManager.gm.setCamManualMove(false);
        StartCoroutine(doBulletTime());

    }

    //public float endStartBulletIn = .2f;
    //private float endBulletTimeIn = 3f;
    public float slowDownTo = .1f;
    public float destroyEvery = .4f;//375f;
    public float lookTime = .65f;
    IEnumerator doBulletTime()
    {
        //slows down time
        Time.timeScale = slowDownTo;
        Time.fixedDeltaTime = Time.timeScale * .02f;
        AudioManager.am.slowDownAudio();
        //destroys the projectiles first since they can do damage
        allprojectiles = GameObject.FindGameObjectsWithTag("Enemy_projectile");
        //IDEA: SORT ALL PROJECTILES BY DISTANCE, THEN DESTROY STATING FROM THE CLOSEST
        //BELOW IS SORTING CODE THAT NEEDS TO BE ADJUSTED TO SUIT
        allprojectiles = allprojectiles.OrderBy(pro => Vector3.Distance(GameManager.gm.player.transform.position, pro.transform.position)).ToArray();
        foreach (GameObject enemy_pro in allprojectiles)
        {
            yield return new WaitForSeconds(.2f * Time.timeScale);
            if (enemy_pro) enemy_pro.GetComponent<Health>().ApplyDamage(damageAmount);
        }
        //wait to destroy other objects
        yield return new WaitForSeconds(destroyEvery * Time.timeScale);
        //gets the other objects
        allenemies = GameObject.FindGameObjectsWithTag("Enemy");
        allothers = GameObject.FindGameObjectsWithTag("OtherObject");
        //destroys the other objects and waits for a fraction of a second after each one
        Transform c = Camera.main.gameObject.transform;
        Vector3 oPos = c.position;
        //Vector3 relPos;
        //Quaternion tarRot;
        //Quaternion oRot = c.rotation;
        //print("x: " + oRot.x + "y: " + oRot.y + "z: " + oRot.z);
        float t = 0;
        //float smoothSpeed = 35f;
        foreach (GameObject enemy in allenemies)
        {
            if (enemy)
            {
                if (!enemy.name.Contains("Boss"))enemy.GetComponent<movement>().leaving = true;//to avoid the enemy leaving the game
                t = Time.time;
                while (Time.time - t < lookTime * Time.timeScale && enemy)
                {
                    if (enemy)
                    {
                        //relPos = enemy.transform.position - c.position;
                        //tarRot = Quaternion.LookRotation(relPos);
                        //c.rotation = Quaternion.Lerp(c.rotation, tarRot, lookTime);
                        Vector3 tpos = new Vector3(enemy.transform.position.x, enemy.transform.position.y,c.position.z);
                        //c.position = Vector3.Lerp(c.position,tpos,smoothSpeed * Time.unscaledDeltaTime);
                        c.position = Vector3.Lerp(c.position, tpos, lookTime);
                        yield return new WaitForEndOfFrame();
                    }
                }
                if (enemy) enemy.GetComponent<Health>().ApplyDamage(damageAmount);
                yield return new WaitForSeconds(destroyEvery * Time.timeScale);

            }
        }
        foreach (GameObject oo in allothers)
        {
            if (oo)
            {
                oo.GetComponent<movement>().leaving = true;//to avoid the enemy leaving the game
                t = Time.time;
                while (Time.time - t < lookTime * Time.timeScale && oo)
                {
                    if (oo)
                    {
                        //relPos = oo.transform.position - c.position;
                        //tarRot = Quaternion.LookRotation(relPos);
                        //c.rotation = Quaternion.Lerp(c.rotation, tarRot, lookTime);
                        Vector3 tpos = new Vector3(oo.transform.position.x, oo.transform.position.y, c.position.z);
                        //c.position = Vector3.MoveTowards(c.position, tpos, smoothSpeed * Time.unscaledDeltaTime);
                        c.position = Vector3.Lerp(c.position, tpos, lookTime);
                        yield return new WaitForEndOfFrame();
                    }
                }
                if (oo) oo.GetComponent<Health>().ApplyDamage(damageAmount);
                yield return new WaitForSeconds(destroyEvery * Time.timeScale);

            }
        }

        t = Time.unscaledTime;
        while (Time.unscaledTime - t < lookTime)
        {
            //relPos = c.position - c.position;
            //tarRot = Quaternion.LookRotation(relPos);
            //c.rotation = Quaternion.Lerp(c.rotation, oRot, lookTime);
            //Vector3 tpos = new Vector3(oPos.x, oPos.y, c.position.z);
            c.position = Vector3.Lerp(c.position, oPos, lookTime);
            yield return new WaitForEndOfFrame();
        }
        //Camera.main.transform.rotation = oRot;// new Vector3(0, 0, 0);
        yield return new WaitUntil(() => GameManager.gm.gameState != GameManager.gameStates.Pause);
        c.position = oPos;
        //returns to regular speed
        Time.timeScale = 1f;
        Time.fixedDeltaTime = Time.timeScale * .02f;
        AudioManager.am.slowDownAudio();
        GameManager.gm.setCamManualMove(shakeRange,shakeSpeed,shakeTime);
    }
}
