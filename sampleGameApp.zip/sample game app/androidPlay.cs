﻿//using System.Collections;
using UnityEngine;
#if UNITY_ANDROID && !UNITY_EDITOR
using GooglePlayGames;
using GooglePlayGames.BasicApi;
#endif
public class androidPlay : platformPlay//MonoBehaviour
{
    //public static GameObject instance;
    //public static bool isAuth = false;
    //public static readonly string restoreKey = "restored";
    //public static readonly string newIdKey = "newId";

    
    // Use this for initialization 
    public override void Start()
    {
        base.Start();
        //if (instance == null) instance = gameObject;
        //else if (!isAuth)
        //{
        //    Destroy(instance);
        //    instance = gameObject;
        //}
        //else
        //{
        //    Destroy(gameObject);
        //    return;
        //}
        //DontDestroyOnLoad(gameObject);

        SignInWithPlayGames();
    }

    public void SignInWithPlayGames()
    {
        string Id = "";
        // Initialize Play Games Configuration and Activate it. 
#if UNITY_ANDROID && !UNITY_EDITOR
        PlayGamesClientConfiguration config = new PlayGamesClientConfiguration.Builder().Build();
        PlayGamesPlatform.InitializeInstance(config);
        PlayGamesPlatform.Activate();

        Debug.LogFormat("SignInOnClick: Play Games Configuration initialized");

        // Sign In and Get a server auth code. 
        UnityEngine.Social.localUser.Authenticate((bool success) =>
        {
            //bool success = true;
            if (!success)
            {
                Debug.LogError("SignInOnClick: Failed to Sign into Play Games Services.");
                //GameManager.gm.timedMsg("Failed to sign into play games services");
                return;
            }

            isAuth = true;
            Id = ((PlayGamesLocalUser)Social.localUser).id;
            print("Platform ID: " + Id);
            //GameManager.gm.statusMsg.text = "SIGNED IN \n ID: " + Id;
			//GameManager.gm.timedMsg("ID: "+Id);
            StartCoroutine(platformIdCheck(Id));
        });
#else

        Id = "ap1234567";
        print("Platform ID: " + Id);
        //GameManager.gm.statusMsg.text = "SIGNED IN \n ID: " + Id;
        StartCoroutine(platformIdCheck(Id,"go"));
#endif
        //string idToken = ((PlayGamesLocalUser)Social.localUser).GetIdToken();
        //string eMail = ((PlayGamesLocalUser)Social.localUser).Email;
        //GameManager.gm.timedMsg("SIGNED INTO play games services \n ID: " + Id);



    }

  //  IEnumerator platformIdCheck(string pid)
  //  {
		//float tUp = Time.time + 120f;
  //      yield return new WaitUntil(() =>
  //      GameManager.conMade && 
  //      GameManager.fundaCheck == null && 
  //      GameManager.gamePlayer.id != "" && 
  //      GameManager.gm.gameState != GameManager.gameStates.GameOver && 
  //      GameManager.gm.gameState != GameManager.gameStates.newName);// || Time.time > tUp);

  //      //tutorial is done and platform hasn't been done before
  //      if (GameManager.conMade
  //          && GameManager.fundaCheck == null
  //          && GameManager.gamePlayer.id != ""
  //          && GameManager.gm.gameState != GameManager.gameStates.GameOver
  //          && GameManager.gm.gameState != GameManager.gameStates.newName
  //          //&& PlayerPrefs.HasKey(GameManager.tutorialKey)
  //          && !PlayerPrefs.HasKey(restoreKey))
  //      {
  //          GameManager.gamePlayer.go = pid;
  //          dataControl.savePlayer(GameManager.gamePlayer);
  //          StartCoroutine(GameManager.client.InvokeApi<Message, jointSynch>("getPlatformInfo", RESTClient.Method.POST, Message.Create(pid, "go"), platformIdCheckComplete));
  //          print("checking platform now");
  //      }
  //      else if (!PlayerPrefs.HasKey(restoreKey)) StartCoroutine(platformIdCheck(pid));
  //      //yield return null;
  //  }
    //restoreControl rc;
    //void platformIdCheckComplete(RESTClient.IRestResponse<jointSynch[]> res)
    //{
    //    if (res.IsError)
    //    {
    //        Debug.Log("Couldn't get player's platform information Status:" + res.StatusCode + " Url: " + res.Url);
    //        return;
    //    }

    //    jointSynch []pl = res.Data;
    //    Debug.Log("On getting player information complete: " + res.Url + " data: " + res.Content);
    //    if (pl[0].id!="none")
    //    {
    //        print("record of player exists, checking for items..");
    //        rc = new restoreControl
    //        {
    //            cloudJoint = pl[0]
    //        };
    //        StartCoroutine(GameManager.client.InvokeApi<Message, playerItem>("getPlayerItems", RESTClient.Method.POST, Message.Create(pl[0].id), OnItemRestoreCompleted));
    //    }
    //    //no record with platform key
    //    else 
    //    {
    //        print("no record, about to synch google id");
    //        //GameManager.gamePlayer.go = pl[0].go;
    //        dataControl.savePlayer(GameManager.gamePlayer);
    //        PlayerPrefs.SetInt(newIdKey, 0);
    //        PlayerPrefs.SetInt(restoreKey, 0);

    //        //appempting to synch here
    //        if (GameManager.fundaCheck == null && (GameManager.gamePlayer.id != null && GameManager.gamePlayer.id != ""))
    //        {
    //            GameManager.fundaCheck = StartCoroutine(GameManager.client.InvokeApi<Message, Message>
    //                ("firstUpdate", RESTClient.Method.POST,
    //                Message.Create(GameManager.gamePlayer.go, GameManager.gamePlayer.id, "go"),
    //                GameManager.playerUpdateComplete));
    //        }
    //    }


    //}

    //private void OnItemRestoreCompleted(RESTClient.IRestResponse<playerItem[]> response)
    //{
    //    if (response.IsError)
    //    {
    //        Debug.LogWarning("Read Item Restore Status:" + response.StatusCode + " Url: " + response.Url);
    //        return;
    //    }
    //    Debug.Log("On getting player items complete: " + response.Url + " data: " + response.Content);

    //    rc.cloudItems = response.Data;
    //    print("items, if any, retrieved");
    //    GameObject g = Instantiate(Resources.Load("begin/restoreCanvas", typeof(GameObject))) as GameObject;
    //    Canvas c = g.GetComponent<Canvas>();
    //    c.worldCamera = Camera.main;
    //    c.planeDistance = 3f;
    //    g.GetComponent<restoreManager>().restoreInfoShow(rc);
    //}

    public static void postHighscoreToLeaderBoard(int newScore, bool ifHigh)
    {
        //bool done = false;
        if (!isAuth) return;

        Social.ReportScore(newScore,GPGSIds.leaderboard_high_scores,(bool success) => 
        {
            if (success)
            {
                //GameManager.gm.timedMsg("SignInOnClick: posted new high score!");
                print("SignInOnClick: posted new high score!");
                //done = true;
                if (ifHigh && PlayerPrefs.HasKey(GameManager.playerPlatformUnsynchedKey))
                    PlayerPrefs.DeleteKey(GameManager.playerPlatformUnsynchedKey);

            }

            else
            {
                //GameManager.gm.timedMsg("couldn't post new high score :(");
                print("SignInOnClick: couldn't post new high score :(");
                //done = false;
            }
        });
        //return done;
    }

    public static void showLeaderBoard()
    {
        if (!isAuth)
        {
            GameManager.gm.timedMsg("Can't Log on to Google Play Services");
            return;
        }
            //GameManager.gm.timedMsg("try to show leaderboard");
#if UNITY_ANDROID && !UNITY_EDITOR
        PlayGamesPlatform.Instance.ShowLeaderboardUI(GPGSIds.leaderboard_high_scores);
#endif
    }

    public static void signOutPlayer()
    {

    }
}
