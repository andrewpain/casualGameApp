﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class move_cautionThenMissile : movement {
    //public GameObject caution;
    //private Material exclaimMaterial;
    //private bool isRed = false;
    public GameObject missile;
    public float blinkingSpeed = 1f;
    public float waitingTime = 5f;
    //private float waiting = 0f;
    private float increaseSpeedTime;
    private float waitingCap;
    // Use this for initialization
    protected float exitIn = .4f;
    public override void Start() {
        base.Start();
        //if (!exclaimMaterial)
        //{
        //    exclaimMaterial = transform.GetChild(0).gameObject.GetComponent<Renderer>().material;
        //    transform.GetChild(1).gameObject.GetComponent<Renderer>().material = exclaimMaterial;
        //    exclaimMaterial.SetColor("_Color", Color.white);
        //}
        waitingTime -= exitIn;
        increaseSpeedTime = Time.time + (waitingTime- 1.2f);//.705 is the length of the sound
        //waiting = Time.time + blinkingSpeed;
        waitingCap = Time.time + waitingTime;

    }


    void destroyCautionCreateMissile()
    {

        missile = Instantiate(missile, transform.position + transform.forward, transform.rotation) as GameObject;
        AudioManager.am.playSound("rocket");
        //Animator a = gameObject.GetComponent<Animator>();
        //if (a != null)a.SetTrigger("exit");
        //else 
        Destroy(gameObject);
    }
    //void switchColour()
    //{
    //    if (isRed)
    //    {
    //        exclaimMaterial.SetColor("_Color", Color.white);
    //        isRed = false;
    //    }
    //    else
    //    {
    //        exclaimMaterial.SetColor("_Color", Color.red);
    //        isRed = true;
    //    }
    //}

    public override void startPoints()
    {
        Vector3 minrange = GameManager.gm.MinRange;
        Vector3 maxrange = GameManager.gm.MaxRange;

        float randomx = 0;
        float randomy = 0;
        float randomz = Random.Range(minrange.z, maxrange.z-.5f);// was 0 but made random to suite both 2/3 D 
		if (minrange.z==maxrange.z) randomz = minrange.z-.5f;

        int rn = Random.Range(0, 3);
        
        switch (rn)
        {
            case 0://on the top of the screen
                randomx = Random.Range(minrange.x + .5f, maxrange.x - .5f);
                randomy = 7.9f ;// highest visible point in the screen; (maxrange.y - 1.1f)
                break;
            case 1://on the left of the screen
                randomx = minrange.x + .5f;
                randomy = Random.Range(minrange.y + 2f, maxrange.y - 1.1f);
                break;
            case 2://on the right on of the screen
                randomx = maxrange.x - .5f;
                randomy = Random.Range(minrange.y + 2f, maxrange.y - 1.1f);
                break;

        }
        transform.position = new Vector3(randomx, randomy, randomz);
    }
    private bool isFaster = false;
    private bool isDone = false;
    protected override void calMove() {
        //if (Time.time > waiting && Time.time < waitingCap)
        //{
        //    switchColour();

        //    if (Time.time < increaseSpeedTime)
        //        waiting = Time.time + blinkingSpeed;
        //    else

        //{
        if (!isFaster && Time.time > increaseSpeedTime)
        {
            isFaster = true;
            gameObject.GetComponent<Animator>().SetTrigger("up");
            //gameObject.GetComponent<SpriteRenderer>().color = Color.red;
            AudioManager.am.playSound("missileWarning", gameObject);
        }
        //waiting = Time.time + blinkingSpeed / 5;
            //}
        //}
        else if (Time.time >= waitingCap && !isDone)
        {
            isDone = true;
            destroyCautionCreateMissile();
        }
    }

    protected override bool ifBeyondBorders()
    {
        return false;
    }
}
