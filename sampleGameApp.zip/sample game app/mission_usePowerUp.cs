﻿using UnityEngine;
//using System.Collections;
//this mission is to use a number of power ups in any number of games 
public class mission_usePowerUp : mission
{
    string powerKey;
    public override void setMissionStart(int cc, int mc,string mi)
    {
        base.setMissionStart(cc, mc,mi);
        missionAlias = missionType.usePowerUp;
        //if max count not set, thus new mission
        setDiff(5, 10, 20);
        //setDiff(1, 2, 3);

    }
    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        count += p;
        if (count >= maxCount) finishMission();
    }

    public override string getStatus()
    {
        if (!complete)return "Use " + maxCount + " power ups. " + count + "/" + maxCount + " completed";
        else return "Use " + maxCount + " power ups completed! :)";

    }

    //   public override string getDoneMsg()
    //   {
    //       return "Use " + maxCount + " power ups completed! :)";
    //   }
}
