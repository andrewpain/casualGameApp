﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bossExplosionEnd : MonoBehaviour
{
    public void OnParticleSystemStopped()
    {
        if (GameManager.gm) GameManager.gm.initiateBossDeath();
        Destroy(gameObject);
    }
}
