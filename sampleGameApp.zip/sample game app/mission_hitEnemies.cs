﻿using UnityEngine;
//using System.Collections;

public class mission_hitEnemies : mission
{

    public override void setMissionStart(int cc,int mc, string mi)
    {
        //all base does is set the current count
        base.setMissionStart(cc,mc,mi);

        missionAlias = missionType.hitEnemy;
        //if the mission hasnt been set, thus new mission
        setDiff(200, 500, 800);
        //setDiff(1, 2, 3);
    }


    public override string getStatus()
    {
        if(!complete)return "Hit " + maxCount + " enemies. " + count + "/" + maxCount + " completed";
        else return "Hit " + maxCount + " enemies completed! :)";

    }
    //public override string getDoneMsg()
    //{
    //    return "Hit " + maxCount + " enemies completed! :)";
    //}
    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
            count += p;
            if (count<=maxCount)Instantiate(progressParticle, pos, rot);
            if (count >= maxCount) finishMission();   
    }


}
