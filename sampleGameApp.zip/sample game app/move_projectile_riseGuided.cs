﻿using UnityEngine;
//using System.Collections;

public class move_projectile_riseGuided : move_projectile
{
    public float waitTime = 3;
    private float waitCap;
    public float increaseBy = .02f;
    private bool moving = false;
    private bool rising = true;
    public bool ifRotateFace = true;
    //Vector3 dir;
    public float rotateSpeed = 200f;
    //Coroutine rotating;
    //Vector3 dir2;

    public override void Start()
    {
        base.Start();
        //if (!ifRotateFace)
        //{
            transform.rotation = Quaternion.LookRotation(Vector3.up);
        //    dir = Vector3.forward;
        //}
        //else dir = Vector3.up;
    }

    protected override void calMove()
    {

        //if target exists, to avoid returning a null target
        if (moving || rising)
        {
            //transform.position += transform.forward * speed * Time.deltaTime;
            gameObject.transform.Translate(Vector3.forward * Time.deltaTime * speed);
            if (moving)
            {
                if (GameManager.gm && GameManager.powerActive != powerUp.powerType.slow)
                    speed += speed * increaseBy;
                else
                    speed += speed * increaseBy * 0.2f;
            }
        }

        else
        {
            //rotating TOWARDS the player
            Vector3 relPos = target.position - transform.position;
            Quaternion tarRot = Quaternion.LookRotation(relPos);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, tarRot, rotateSpeed * Time.deltaTime);
            //transform.LookAt(target);
            //if(ifRotateFace)transform.Rotate(90f, 0, 0);
            if (/*!moving && */Time.time >= waitCap) moving = true;
        }
    }



    protected override void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "roof")
        {
            rising = false;
            waitCap = Time.time + waitTime;
            //if (target)
            //{
            //    gameObject.transform.LookAt(target);
            //    //rotates 90 degrees so that the projectile looks like a fireball animation, but has to move "up" locally
            //    gameObject.transform.Rotate(90f, 0, 0);
            //}
            //if (GetComponent<Rotate>()) GetComponent<Rotate>().enabled = true;
        }
        else base.OnTriggerEnter(other);
    }

}
