﻿using UnityEngine;
//using System.Collections;

//[RequireComponent(typeof(CharacterController))]

public class move_projectile_guided : move_projectile {
	
	public float minDist = 1f;

	// Use this for initialization
	public override void Start () 
	{
        base.Start();
			
        transform.LookAt(target);
    }

    protected override void calMove()
    {
        transform.position += transform.forward * speed * Time.deltaTime;
        
    }
}
