﻿using UnityEngine;
//using System.Collections;

public class powerup_shield : powerUp {
    //public float timeActive = 10f;
    //public bool isActive = false;
    // Use this for initialization
    //was placed here for testing

    //void Start (){
    //powerName = powerType.shield;
    /* timeActive = 30f;*/
    //}
    //GameObject player;
    public GameObject forceField;
    GameObject forceActive;
    public override void activeOn() {
        //isActive = true;
        //this.GetComponent<MeshRenderer>().enabled = true;
        //if(gameObject.GetComponent<Renderer>())
        //player = GameObject.FindGameObjectWithTag("Player");
        //player.GetComponent<Renderer>().material.SetColor("_EmissionColor", Color.cyan);

        forceActive = Instantiate(forceField, GameManager.gm.player.transform.position, GameManager.gm.player.transform.rotation);
        forceActive.transform.parent = GameManager.gm.player.transform;
        //Invoke("activeDone", timeActive);
        base.activeOn();
    }

    public override void activeOff() {
        //if(GetComponent<MeshRenderer>())this.GetComponent<MeshRenderer>().enabled = false;
        //player.GetComponent<Renderer>().material.SetColor("_EmissionColor", Color.black);
        //CREATE AN EXPLOSION FOR THE SHIELD ENDINGs
        Destroy(forceActive);
        base.activeOff();
    }

}
