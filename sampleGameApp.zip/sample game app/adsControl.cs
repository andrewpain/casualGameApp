﻿using UnityEngine;
using System.Collections;
#if UNITY_ANDROID || UNITY_IOS //|| UNITY_EDITOR && !UNITY_WSA
using UnityEngine.Advertisements;
#elif UNITY_WSA// && !UNITY_EDITOR
using WSAUnity;
//using Microsoft.UnityPlugins;
#endif

public class adsControl : MonoBehaviour
{
    //this controls if to load the home screen
    public bool loadScene;
    //if the game requires to reward player with item
    public ItemManager rewardItems;
    //name of type of video - "rewardedVideo" (can't skip) / "video" (skipable)
    private string vidName;
    public enum vidType { must, optional };
    vidType vidChosen;
    public bool videoReady = false;
    static readonly string rewardVid = "rewardedVideo";
    static readonly string regularVid = "video";

    static readonly string rewardVidWin = "paywallCustom";
    //static readonly string regularVidWin = "YET_TO_SET";

#if UNITY_WSA && UNITY_EDITOR
    private IInterstittialAd ad;
	
#elif UNITY_WSA
    private const string appId = "9mzsm7gv5rwk";//"9MZSM7GV5RWK";//"d25517cb-12d4-4699-8bdc-52040c712cab";
    private string adUnitId = "1100055517";//"test";


#endif


    public void adControlStart(vidType vidChoice, bool ifLoadScene, ItemManager im)
    {
        loadScene = ifLoadScene;
        vidChosen = vidChoice;
        //vidName = vid;
#if UNITY_ANDROID || UNITY_IOS

            if (vidChoice == vidType.must) vidName = rewardVid;
            else vidName = regularVid;
#elif UNITY_WSA && UNITY_EDITOR
        MicrosoftAdsBridge.InterstitialAdFactory = new EditorAdFactory();
        ad = MicrosoftAdsBridge.InterstitialAdFactory.CreateAd(OnAdReady, OnAdCompleted, OnAdCancelled, OnAdError);
        //This is not needed in production.. here we use it to show a fake ad so you can work your 
        //workflow of stopping pausing to play ad, unpausing, etc.. 
        ((EditorInterstitialAd)ad).syncMonoBehaviour = this;

        ad.Request("appId", "adUnitId", AdType.Video);

#elif UNITY_WSA

        print("SUPPOSE TO BE LOADING ACTUAL AD");
        Advertising.Init(appId,adUnitId);


#endif
        rewardItems = im;
        //in case internet connection fails/ network error
        //if either a mandatory video from either gameManager or itemManager, or regular video from gamemanager
        //if (vidName != rewardVid || !loadScene) /*StartCoroutine*/rewardAdNow();
        //if(doNow)rewardAdNow();
    }

    public bool RewardCheck()
    {
#if UNITY_ANDROID || UNITY_IOS
        return Advertisement.IsReady(vidName);
#elif UNITY_WSA && UNITY_EDITOR
        print("AD IS SUPPOSE TO BE READY: " + ad.State);
        return ad.State == WSAUnity.InterstitialAdState.Ready;
#elif UNITY_WSA
        print("AD IS SUPPOSE TO BE READY: " + Advertising.state.ToString());
        return Advertising.state == Advertising.adState.Ready;
#else 
           return false;
#endif
    }


    public IEnumerator longRewardCheck()
    {
        float tMax;// = Time.time + 30;

#if UNITY_ANDROID || UNITY_IOS //|| UNITY_EDITOR
        tMax = Time.time + 5;
        yield return new WaitUntil (() => Advertisement.IsReady(vidName)|| Time.time > tMax);
        if (Advertisement.IsReady(vidName)) videoReady = true;
#elif UNITY_WSA && UNITY_EDITOR
        tMax = Time.time + 30;
        yield return new WaitUntil(() => ad.State == WSAUnity.InterstitialAdState.Ready || Time.time > tMax);
        videoReady = ad.State == InterstitialAdState.Ready;
#elif UNITY_WSA
        tMax = Time.time + 30;
        yield return new WaitUntil(() => Advertising.state == Advertising.adState.Ready || Time.time > tMax);
        print("IS AD READY?!: "+Advertising.state.ToString());
        videoReady = Advertising.state == Advertising.adState.Ready;
		//if (!videoReady)AudioManager.am.playSound("missileWarning");
#endif
        yield return null;
    }

    void rewardShow()
    {

#if UNITY_ANDROID || UNITY_IOS //|| UNITY_EDITOR
        var options = new ShowOptions { resultCallback = HandleShowResult };
        Advertisement.Show(vidName, options);
#elif UNITY_WSA && UNITY_EDITOR
        ad.Show();
#elif UNITY_WSA
        print("AD IS SUPPOSE TO SHOW!!: " + Advertising.state.ToString());
        Advertising.Show();
        StartCoroutine(winAdWait());
#endif

    }
    public void rewardAdNow()
    {
        if (RewardCheck())
        {
            rewardShow();
        }

        else
        {
            Debug.LogWarning("The ad failed to be ready?!");
            if (loadScene) GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
            else if (rewardItems) rewardItems.adViewFail();
        }

    }
#if UNITY_ANDROID || UNITY_IOS
    private void HandleShowResult(ShowResult result)
    {
        switch (result)
        {
            case ShowResult.Finished:
                Debug.Log("The ad was successfully shown.");
                PlayerPrefs.SetInt("adCount", 0);
                if(PlayerPrefs.HasKey(GameManager.playerLiveAd)) PlayerPrefs.DeleteKey(GameManager.playerLiveAd);
                if (loadScene) GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
                else if (rewardItems) rewardItems.setPurchasedItem(false);
                

                break;
            case ShowResult.Skipped:
                Debug.Log("The ad was skipped before reaching the end.");

                if (loadScene)
                {
                    PlayerPrefs.SetInt("adCount", 0);
                    GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
                }
                else if (rewardItems) rewardItems.adViewFail();				

                break;
            case ShowResult.Failed:
                Debug.LogError("The ad failed to be shown.");
                if (loadScene) GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
                else if (rewardItems) rewardItems.adViewFail();			
				
                break;
        }
        Destroy(this);
    }

#elif UNITY_WSA && UNITY_EDITOR
    void OnAdReady(object unused)
    {
        videoReady = true;
        GameManager.gm.timedMsg("Windows AD: " + ad.State);
    }

    void OnAdCompleted(object unused)
    {
        GameManager.gm.timedMsg(ad.State.ToString());
        Debug.Log("The ad was successfully shown.");
        PlayerPrefs.SetInt(GameManager.adCountKey, 0);
        if (PlayerPrefs.HasKey(GameManager.playerLiveAd)) PlayerPrefs.DeleteKey(GameManager.playerLiveAd);
        if (loadScene) GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
        else if (rewardItems) rewardItems.setPurchasedItem(false);
		
        Destroy(this);

    }
    void OnAdCancelled(object unused)
    {
        GameManager.gm.timedMsg(ad.State.ToString());
        Debug.Log("The ad was skipped before reaching the end.");

        if (loadScene)
        {
            PlayerPrefs.SetInt(GameManager.adCountKey, 0);
            GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
        }
        else if (rewardItems) rewardItems.adViewFail();
        Destroy(this);

    }
    void OnAdError(object param)
    {
        //AdErrorEventArgs args = param as AdErrorEventArgs;
        //if (args != null)
        //{
        //    GameManager.gm.timedMsg("Error: " + args.ErrorMessage);
        //    Debug.LogError("The ad failed to be shown: " + args.ErrorMessage);
        //}
        Debug.LogError("The ad tried to load but failed to be shown :( ");
        if (loadScene) GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
        else if (rewardItems) rewardItems.adViewFail();
        Destroy(this);

    }

#elif UNITY_WSA
    IEnumerator winAdWait()
    {
        yield return new WaitUntil(() => Advertising.state == Advertising.adState.Showing);
        yield return new WaitUntil(() => Advertising.state != Advertising.adState.Showing);

        switch (Advertising.state)
        {
            default: /*GameManager.gm.timedMsg("AD STATE:"+Advertising.state.ToString());*/break;
            case Advertising.adState.Completed:
                Debug.Log("The ad was successfully shown.");
                //GameManager.gm.timedMsg("AD was successfully shown:" + Advertising.state.ToString());

                PlayerPrefs.SetInt(GameManager.adCountKey, 0);
                if (PlayerPrefs.HasKey(GameManager.playerLiveAd)) PlayerPrefs.DeleteKey(GameManager.playerLiveAd);
                if (loadScene) GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
                else if (rewardItems) rewardItems.setPurchasedItem(false);
                break;
            case Advertising.adState.Cancelled:
                Debug.Log("The ad was skipped before reaching the end.");
                //GameManager.gm.timedMsg("The ad was skipped before reaching the end:" + Advertising.state.ToString());

                if (loadScene)
                {
                    PlayerPrefs.SetInt(GameManager.adCountKey, 0);
                    GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
                }
                else if (rewardItems) rewardItems.adViewFail();
                break;
            case Advertising.adState.Error:
                Debug.LogError("The ad failed to be shown :( ");
                //GameManager.gm.timedMsg("The ad failed to be shown :(:" + Advertising.state.ToString());
                if (loadScene) GameManager.gm.aboutToEndScene(); //SceneManager.LoadScene(0);
                else if (rewardItems) rewardItems.adViewFail();
                break;

        }
        if(this!=null)Destroy(this);

    }

#endif
}
