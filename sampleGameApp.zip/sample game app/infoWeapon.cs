﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class infoWeapon : infoItem {

    //private GameObject[] w;
    [Header("Damage")]
    public bool isDamage = false;
    //public float damage = 1f;
    [Header("Dual")]
    public bool isDual = false;

    //if has a spread/spray of projectiles
    [Header("Spray")]
    public bool isSpray = false;
    public float spray = 1f;

    //if it is an auto fire
    [Header("Automatic")]
    public bool isAuto = false;
    public float fireRate = .5f;

    // Use this for initialization
    void Start() {
        //logically setting the price, assuming the price starts at 100 by default
        //if (damage > 1f) { cost += 75; if (isDual || isAuto || isSpray) cost += 50; }
        //if (isDual) {cost += 50; if (damage>1 || isAuto || isSpray) cost += 50; }
        //if (isAuto) {cost += 100; if (isDual || damage > 1 || isSpray) cost += 100; }
        //if (isSpray) {cost += 125; if (isDual || isAuto || damage > 1) cost += 150; }


        //w = new GameObject[transform.childCount];
        //for (int i = 0; i < w.Length; i++)
        //{
            //w[i] = transform.GetChild(i).gameObject;

            shooter_weapon ws = /*w[i]*/gameObject.GetComponent<shooter_weapon>();

            if (isDamage) ws.damage = 2;//damage;

            ws.isDual = isDual;

            ws.isSpray = isSpray;
            ws.spray = spray;

            ws.isAuto = isAuto;
            ws.fireRate = fireRate;
        //}

	}

    public override int calRent()
    {
        if (rent > 100)return rent;
        //logically setting the price, assuming the price starts at 100 by default
        if (isDamage) {rent += 75 ; if (isDual || isAuto || isSpray) rent += 50 ; }
        if (isDual) {rent += 50 ; if (isDamage || isAuto || isSpray) rent += 50 ; }
        if (isAuto) {rent += 100; if (isDual || isDamage || isSpray) rent += 100; }
        if (isSpray) {rent += 125; if (isDual || isAuto || isDamage) rent += 150; }

        return rent;
    }
    public override int calCost()
    {
        if (cost > 1000) return cost;
        //logically setting the price, assuming the price starts at 1000 by default
        if (isDamage) { cost += 750 ; if (isDual || isAuto || isSpray) cost += 500 ; }
        if (isDual) { cost += 500 ; if (isDamage || isAuto || isSpray) cost += 500 ; }
        if (isAuto) { cost += 1000; if (isDual || isDamage || isSpray) cost += 1000; }
        if (isSpray) { cost += 1250; if (isDual || isAuto || isDamage) cost += 1500; }

        return cost;
    }
}
