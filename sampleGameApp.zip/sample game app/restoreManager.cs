﻿using System;
using System.Collections;
//using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class restoreManager : MonoBehaviour {

    public GameObject mainPanel, infoPanel, saveButton, doneButton;
    //public Text localData;
    public Text cloudData;
    int doneCheck = 0;
    restoreControl restoreInfo;
    public void restoreInfoShow(restoreControl rco)
    {
        restoreInfo = rco;
        print("setting choice canvas here");
        //put code showing play the info to choose
        //SHOWING PLAYER INFO
        jointSynch p = restoreInfo.cloudJoint;
        //DateTime cTime = TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Parse(restoreInfo.cloudJoint.updatedAt));
        //DateTime cTime = TimeZoneInfo.ConvertTime(DateTime.Parse(restoreInfo.cloudJoint.updatedAt),TimeZoneInfo.Utc,TimeZoneInfo.Local);
        DateTime cTime = DateTime.Parse(restoreInfo.cloudJoint.updatedAt);
        //DateTime cTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.Parse(restoreInfo.cloudJoint.updatedAt), TimeZoneInfo.Local);
        //localData.text = "<b>LOCAL</b>\n<b>Date</b> \n" + DateTime.Now.Month +"/"+DateTime.Now.Day+"/"+DateTime.Now.Year+" " + DateTime.Now.Hour+":"+DateTime.Now.Minute+":00";
        //cloudData.text = "<b>CLOUD</b>\n<b>Date</b> \n" + cTime.Month +"/"+cTime.Day+"/"+cTime.Year+" " + cTime.Hour +":"+ cTime.Minute + ":00";
        //localData.text = "<b>LOCAL</b>\n<b>Date</b>:" + DateTime.Now.ToLongDateString();// + " "+ DateTime.Now.ToShortTimeString();
#if UNITY_ANDROID //|| UNITY_IOS
        cloudData.text = "<b>Date</b>:" + cTime.ToLongDateString();
#elif UNITY_WSA
        string numM = "th";
        switch (cTime.Day)
        {
            case 1: numM = "st";break;
            case 2: numM = "nd";break;
            case 3: numM = "rd";break;

        }
        string cMonth = "January";
        switch (cTime.Month)
        {
            case 2: cMonth = "February";break;
            case 3: cMonth = "March"; break;
            case 4: cMonth = "April"; break;
            case 5: cMonth = "May";break;
            case 6: cMonth = "June"; break;
            case 7: cMonth = "July"; break;
            case 8: cMonth = "August"; break;
            case 9: cMonth = "September"; break;
            case 10: cMonth = "October"; break;
            case 11: cMonth = "November"; break;
            case 12: cMonth = "December"; break;
        }
        cloudData.text = string.Format("<b>Date</b>: {0} {1}{2} {3},{4}", cTime.DayOfWeek,cTime.Day,numM,cMonth,cTime.Year);
        //cloudData.text = cTime.ToLongDateString();
#endif
        ////setting the player's name
        //localData.text += "\n<b>Name:</b> " + GameManager.gamePlayer.playerId;
        ////if is a Guid; very unlikely that player would have these traits..
        //if (p.playerId.StartsWith("player") && p.playerId.Length == 40) p.playerId = "";
        //cloudData.text += "\n<b>Name:</b> " + p.playerId;

        //setting the coins
        //localData.text += "\n<b>Coins:</b> " + GameManager.gamePlayer.coins;
        cloudData.text += "\n<b>Coins:</b> " + p.coins;
        //setting the high score
        //localData.text += "\n<b>Highscore:</b> " + GameManager.gamePlayer.score;
        cloudData.text += "\n<b>Highscore:</b> " + p.score;

        playerItem[] items = restoreInfo.cloudItems;

        //SHOWING ITEMS
        string[] la = new string[Enum.GetValues(typeof(GameManager.avatars)).Length];
        for (int i = 0; i < la.Length; i++)
            la[i] = Enum.GetValues(typeof(GameManager.avatars)).GetValue(i).ToString();


        string[] lw = new string[Enum.GetValues(typeof(GameManager.weapons)).Length];
        for (int i = 0; i < lw.Length; i++)
            lw[i] = Enum.GetValues(typeof(GameManager.weapons)).GetValue(i).ToString();

        //localData.text += "\n<b>Characters:</b> ";
        cloudData.text += "\n<b>Characters:</b> ";
        //int localWeaponCount = 0;
        int cloudWeaponCount = 0;
        //int localCharCount = 0;
        int cloudCharCount = 0;
        //local avatars
        //for (int i = 0; i < la.Length; i++)
        //{
        //    //if (PlayerPrefs.HasKey(la[i]))
        //    if (GameManager.gameItems.itemNames.Contains(la[i]))
        //    {
        //        //string wn = (Resources.Load("avatars/" + la[i], typeof(GameObject)) as GameObject).GetComponent<infoAvatar>().iName;
        //        //localData.text += ", "+ wn ;
        //        localCharCount++;
        //    }
        //}
        //localData.text += localCharCount;
        //cloud avatars
        string[] repeatedNames = new string[items.Length];//to avoid the repeated names

        for (int i = 0; i < items.Length; i++)
        {
            TimeSpan ts;
            if (items[i].boughtAt != "" && items[i].boughtAt != null) ts = DateTime.UtcNow - /*TimeZone.CurrentTimeZone.ToLocalTime*/(DateTime.Parse(items[i].boughtAt));
            else ts = DateTime.UtcNow - DateTime.UtcNow;
            if (ts <= ItemManager.itemTimeCap || items[i].perm)
            {

                //string iName = "";
                if (items[i].itemid.StartsWith("avatar"))
                {
                    bool repeated = false;
                    for (int k = 0; k < items.Length; k++)
                        if (repeatedNames[k] != null && repeatedNames[k] == items[i].itemid)
                            repeated = true;
                    if (!repeated)
                    {
                        //iName = (Resources.Load("avatars/" + items[i].itemid, typeof(GameObject)) as GameObject).GetComponent<infoAvatar>().iName;
                        //cloudData.text += ", " + iName ;
                        cloudCharCount++;
                        repeatedNames[i] = items[i].itemid;
                    }
                }
            }
        }
        cloudData.text += cloudCharCount;

        //localData.text += "\n <b>Weapons:</b> ";
        cloudData.text += "\n <b>Weapons:</b> ";
        //local weapons
        //for (int i = 0; i < lw.Length; i++)
        //{
        //    //if (PlayerPrefs.HasKey(lw[i]))
        //    if (GameManager.gameItems.itemNames.Contains(lw[i]))
        //    {
        //        //string wn = (Resources.Load("weapons/" + lw[i], typeof(GameObject)) as GameObject).GetComponent<infoWeapon>().iName;
        //        //localData.text += ", "+ wn;
        //        localWeaponCount++;
        //    }
        //}
        //localData.text += localWeaponCount;
        repeatedNames = new string[items.Length];
        //cloud weapons
        for (int i = 0; i < items.Length; i++)
        {
            TimeSpan ts;
            if (items[i].boughtAt != "" && items[i].boughtAt != null) ts = DateTime.UtcNow - /*TimeZone.CurrentTimeZone.ToLocalTime*/(DateTime.Parse(items[i].boughtAt));
            else ts = DateTime.UtcNow - DateTime.UtcNow;
            if (ts <= ItemManager.itemTimeCap || items[i].perm)
            {
                //string iName = "";
                if (items[i].itemid.StartsWith("weapon"))
                {
                    bool repeated = false;
                    for (int k = 0; k < items.Length; k++)
                        if (repeatedNames[k] != null && repeatedNames[k] == items[i].itemid)
                            repeated = true;
                    if (!repeated)
                    {
                        //iName = (Resources.Load("weapons/" + items[i].itemid, typeof(GameObject)) as GameObject).GetComponent<infoWeapon>().iName;
                        //cloudData.text += ", " + iName ;
                        cloudWeaponCount++;
                        repeatedNames[i] = items[i].itemid;
                    }
                }
            }
        }
        cloudData.text += cloudWeaponCount;

        GameManager.gm.statusMsg.text = "";
        restoreInfo.localWeapons = lw;
        restoreInfo.localAvatars = la;

        //if (GameManager.gm.gameState == GameManager.gameStates.Playing) GameManager.gm.togglePauseMenu(true);
        //else 
        StartCoroutine(waitToShow());
    }

    IEnumerator waitToShow()
    {
        yield return new WaitUntil(() => GameManager.gm.readyToPlay);
        GameManager.gm.gameContainer.SetActive(false);
        mainPanel.SetActive(true);
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(saveButton);
#endif
        currTimeScale = Time.timeScale;
        Time.timeScale = 0f;
    }
    float currTimeScale;

    public static readonly string idDeleteKey = "toRemove";
    public void restoringDone(bool ifCloud)
    {
        mainPanel.SetActive(false);
        //if saving cloud data
        print("saving cloud data: " + ifCloud);
        if (ifCloud)
        {
            if (GameManager.gamePlayer.id != null)
            {
                PlayerPrefs.SetString(idDeleteKey, GameManager.gamePlayer.id);
                //removeRecordNow(GameManager.gamePlayer.playerId);
            }
            restoreInfo.saveCloudData();
            infoPanel.SetActive(true);
#if UNITY_WSA
            if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(doneButton);
#endif
        }
        //local data
        else
        {
            PlayerPrefs.SetString(idDeleteKey, restoreInfo.cloudJoint.id);
            //removeRecordNow(restoreInfo.cloudJoint.id);
            destroyCheck();
        }
        //when everything is done
        PlayerPrefs.SetInt(androidPlay.restoreKey, 0);
        PlayerPrefs.SetInt(androidPlay.newIdKey, 0);
    }

    public void removeRecordNow(string rid)
    {
        StartCoroutine(GameManager.client.InvokeApi<Message, Message>("deletePlayer", RESTClient.Method.POST, Message.Create(rid), removePlayerComplete));
    }

    void removePlayerComplete(RESTClient.IRestResponse<Message> response)
    {
        if (response.IsError)
        {
            Debug.Log("coundn't remove unwanted record"+response.ErrorMessage);
            return;
        }
        Debug.Log("On deleting Player Complete: " + response.Url + " data: " + response.Content);
        if (PlayerPrefs.HasKey(idDeleteKey)) PlayerPrefs.DeleteKey(idDeleteKey);
        print("removed player completed");
        //Destroy(gameObject);
        destroyCheck();
    }
    public void closeInfoPanel()
    {
        infoPanel.SetActive(false);
        Time.timeScale = currTimeScale;
        GameManager.gm.aboutToEndScene();
        //destroyCheck();
    }
    void destroyCheck()
    {
        doneCheck++;
        if (doneCheck >= 1)
        {
            GameManager.gm.gameContainer.SetActive(true);
#if UNITY_WSA
            if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(GameManager.gm.prePlayController.defButton);
#endif
            Time.timeScale = currTimeScale;
            Destroy(gameObject);
        }
    }

}
