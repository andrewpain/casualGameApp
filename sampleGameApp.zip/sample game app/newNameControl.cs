﻿using RESTClient;
using System.Collections;
//using System.Collections.Generic;
//using System.Xml;
using UnityEngine;
using UnityEngine.UI;

public class newNameControl : MonoBehaviour {

    public Text nameFail;
    //private GameObject loadAnimation;
    //private GameObject loading;
    //public Text playerCountry;
    public GameObject newNamePanel;
    public InputField nameInput;
    

    //when creating name/highscore,country fails
    private void synchingfailed(string msg)
    {
        GameManager.gm.statusMsg.text = "";
        //destroys animation
        GameManager.gm.toggleLoading(false);
        gameObject.transform.GetChild(0).gameObject.SetActive(true);
        nameFail.text = msg;

    }
    //public Text statusMsg;

    bool nameCheck()
    {
        //checks if there is connection
        if (Application.internetReachability == NetworkReachability.NotReachable)
        {
            nameFail.text = "Failed to connect :( \n check internet connection \n Try again";
            return false;
        }
        //checks if nothing was entered
        else if (nameInput.text == "")
        {
            nameFail.text = "No name entered :(";
            //Invoke("turnOffNameFail", 2);
            return false;
        }
        //checks if a space was entered
        else if (nameInput.text.Contains(" "))
        {
            nameFail.text = "Name can't contain spaces :(";
            //Invoke("turnOffNameFail", 2);
            return false;
        }
        else if (nameInput.text.Length > 40)
        {
            nameFail.text = "Name is too long :(";
            return false;
        }
        //clears the error text if it isn't empty
        else if (nameFail.text != "") nameFail.text = "";

        return true;
    }
    //when player enters a new name
    public void enterNewName()
    {
        if (!nameCheck()) return;
        ////clears the error text if it isn't empty
        //else if (nameFail.text != "") nameFail.text = "";

        newNamePanel.SetActive(false);
        GameManager.gm.toggleLoading(true);
        //if player name is not created 


        //string cc = "";// PlayerPrefs.GetString(GameManager.countryCodeKey, "");
        //if country not found
        //if (cc == "") getGeographicalCoordinates();

        /*else*/
        StartCoroutine(newNameWait());
    }
    IEnumerator newNameWait()
    {
        if (GameManager.fundaCheck == null && (GameManager.gamePlayer.id != null|| GameManager.gamePlayer.playerId != ""))
        {
            GameManager.gm.statusMsg.text = "making connection..";
        }
        else if (GameManager.fundaCheck != null)
        {
            GameManager.gm.statusMsg.text = "waiting for player creation to complete...";
            yield return new WaitUntil(() => GameManager.fundaCheck == null);
        }
        currSynch = StartCoroutine(GameManager.client.InvokeApi<Message>("makeCon", Method.GET, onMakeConComplete));
        Invoke("restartCon", 10f);
        yield return null;
    }

    public void onMakeConComplete(IRestResponse<Message> res)
    {
        if (IsInvoking("restartCon")) CancelInvoke("restartCon");
        if (!res.IsError)
        {
            Debug.Log("Make Connection Complete data: " + res.Content);

            //if game is over, thus not regular first synch with server
            if (GameManager.gm.gameState == GameManager.gameStates.newName && nameCheck())
            {
                //creating new name and record
                if (GameManager.gamePlayer.id == "")
                {
                    GameManager.gm.statusMsg.text = "Connection made,attempting insert..";

                    jointSynch fs = new jointSynch
                    {
                        playerId = nameInput.text,
                        coins = GameManager.gamePlayer.coins,
                        weaponId = GameManager.gamePlayer.weaponId,
                        score = GameManager.gamePlayer.score,
                    };
                    StartCoroutine(GameManager.client.InvokeApi<jointSynch, jointSynch>("firstSync", Method.POST, fs, onFirstSynchComplete));
                }
                //new name, updating record
                else
                {
                    StartCoroutine(GameManager.client.InvokeApi<Message, Message>("firstUpdate", Method.POST, Message.Create(nameInput.text, GameManager.gamePlayer.id, "name"), playerUpdateComplete));

                }

            }
        }
        else
        {
            Debug.Log("Make Error Status:" + res.StatusCode + " Url: " + res.Url);
            Debug.Log("Detail Status:" + res.ErrorMessage + " Url: " + res.Url);

            if (GameManager.gm.gameState == GameManager.gameStates.newName) synchingfailed("Can't Connect. actual network error :(");
        }
    }

    Coroutine currSynch;//holds the current synching task
                        //restarts the synching if it is taking too long
    int rCount = 0;

    void restartCon()
    {
        rCount += 1;
        StopCoroutine(currSynch);
        if (rCount <= 2) enterNewName();//re-calls the method that gets coordinates/inserts the highscore
        else { rCount = 0; if (GameManager.gm.gameState == GameManager.gameStates.newName)
                synchingfailed("Connection Issue. Actual Network Error :("); }
    }

    void onFirstSynchComplete(IRestResponse<jointSynch[]> res)
    {
        if (!res.IsError)
        {
            //statusMsg.text = "Highscore updated!";
            //GameManager.gm.timedMsg("First Synch complete!");
            Debug.Log("First Synch Complete data: " + res.Content);

            jointSynch[] fs = res.Data;

            //print("playerId recieved: " + fs[0].playerId);
            //print("highscoreId recieved: " + fs[0].highscoreId);
            //print("missionId recieved: " + fs[0].missionId);
            //Message fs = res.Data;
            if (fs[0].playerId == nameInput.text) synchingfailed("Name already exists :(");
            else if (fs[0].playerId != null && fs[0].playerId != "")
            {
                //saving the player's information
                if (GameManager.gamePlayer.id=="")GameManager.gamePlayer.id = fs[0].playerId;
                GameManager.gamePlayer.playerId = nameInput.text;
                dataControl.savePlayer(GameManager.gamePlayer);
                
                //ASSUMING YOU ONLY CREATE PLAYER & HIGHSCORE BEFORE SEEING RANKINGS
                GameManager.gm.gameState = GameManager.gameStates.GameOver;
                gameObject.GetComponentInParent<gameOverControl>().getHighScores(false);
                GameManager.gm.statusMsg.text = "getting highscores!";
                gameObject.SetActive(false);


            }
            else
            {
                synchingfailed("error parsing data to information");
            }
        }
        else
        {
            Debug.Log("Make Error Status:" + res.StatusCode + " Url: " + res.Url);
            synchingfailed("Network error :(");
        }

    }
    void playerUpdateComplete(IRestResponse<Message> response)
    {
        if (!response.IsError)
        {


            Debug.Log("On updating Player Complete: " + response.Url + " data: " + response.Content);

            Message m = response.Data;
            //print("NAME: " + m.message);
            //if (m.message != GameManager.gamePlayer.id)
            if (m.message == nameInput.text) synchingfailed("Name already exists :(");

            else
            {
                GameManager.gamePlayer.playerId = nameInput.text;
                dataControl.savePlayer(GameManager.gamePlayer);

                //ASSUMING YOU ONLY CREATE PLAYER & HIGHSCORE BEFORE SEEING RANKINGS
                GameManager.gm.gameState = GameManager.gameStates.GameOver;
                gameObject.GetComponentInParent<gameOverControl>().getHighScores(false);
                GameManager.gm.statusMsg.text = "getting highscores!";

                dataControl.savePlayer(GameManager.gamePlayer);
                gameObject.SetActive(false);
            }
        }
        else
        {
            Debug.Log("player error in updating player Name: " + response.ErrorMessage);
            synchingfailed("Error occured. Try again :(");
        }

    }
    //checks if location is enabled, then initiates the method to find country player is located in
    //public void getGeographicalCoordinates()
    //{
    //    //starts searching for country here
    //    //if (Input.location.isEnabledByUser)
    //    //{

    //    //    currSynch = StartCoroutine(getGeographicalCoordinatesCoroutine());
    //    //    Invoke("restartCon", 10f);
    //    //    Debug.Log("location is enabled");
    //    //    GameManager.gm.statusMsg.text = "Finding your country..";
    //    //}
    //    ////if location not enabled
    //    //else
    //    //{
    //    //Debug.Log("location not enabled");
    //    //string cc = "iv";// System.Globalization.RegionInfo.CurrentRegion.TwoLetterISORegionName;
    //    //if handheld device, and not desktop device
    //    //if (SystemInfo.deviceType == DeviceType.Handheld || cc == "iv")
    //    //{
    //    //    synchingfailed("can't find country, plz turn on Location Services :( ");
    //    //    return;
    //    //}
    //    //if desktop device, since user can't change location services on desktop
    //    //PlayerPrefs.SetString(GameManager.countryCodeKey, cc);
    //    GameManager.gm.statusMsg.text = "making connection..";
    //    //GameManager.gameHighscore.countryid = "iv";//System.Globalization.RegionInfo.CurrentRegion.TwoLetterISORegionName;
    //    //dataControl.saveHighscore(GameManager.gameHighscore);
    //    //starts the attempt of insertion of name
    //    currSynch = StartCoroutine(GameManager.client.InvokeApi<Message>("makeCon", Method.GET, onMakeConComplete));
    //    Invoke("restartCon", 10f);
    //    //playerCountry.text = cc;

    //    //}
    //}

    //private IEnumerator getGeographicalCoordinatesCoroutine()
    //{

    //    Input.location.Start();
    //    int maximumWait = 20;
    //    while (Input.location.status == LocationServiceStatus.Initializing && maximumWait > 0)
    //    {
    //        yield return new WaitForSeconds(1);
    //        GameManager.gm.statusMsg.text = "initializing.."+ maximumWait;
    //        maximumWait--;
    //    }
    //    if (maximumWait < 1 || Input.location.status == LocationServiceStatus.Failed)
    //    {
    //        Input.location.Stop();
    //        synchingfailed("Couldn't search for country :(");
    //        yield break;
    //    }
    //    float latitude = Input.location.lastData.latitude;
    //    float longitude = Input.location.lastData.longitude;
    //    GameManager.gm.statusMsg.text = "found long and lat..";
    //    //      Asakusa.
    //    //      float latitude = 35.71477f;
    //    //      float longitude = 139.79256f;
    //    Input.location.Stop();
    //    GameManager.gm.statusMsg.text = "contacting google maps..";
    //    WWW www = new WWW("https://maps.googleapis.com/maps/api/geocode/xml?latlng=" + latitude + "," + longitude + "&sensor=true");
    //    yield return www;
    //    if (www.error != null)
    //    {
    //        synchingfailed("no response from maps");
    //        yield break;
    //    }
    //    GameManager.gm.statusMsg.text = "response from maps";

    //    XmlDocument reverseGeocodeResult = new XmlDocument();
    //    reverseGeocodeResult.LoadXml(www.text);
    //    if (reverseGeocodeResult.GetElementsByTagName("status").Item(0).ChildNodes.Item(0).Value != "OK") yield break;
    //    string countryCode = null;
    //    bool countryFound = false;
    //    foreach (XmlNode eachAdressComponent in reverseGeocodeResult.GetElementsByTagName("result").Item(0).ChildNodes)
    //    {
    //        GameManager.gm.statusMsg.text = "reading response..";
    //        if (eachAdressComponent.Name == "address_component")
    //        {
    //            foreach (XmlNode eachAddressAttribute in eachAdressComponent.ChildNodes)
    //            {
    //                if (eachAddressAttribute.Name == "short_name") countryCode = eachAddressAttribute.FirstChild.Value;
    //                if (eachAddressAttribute.Name == "type" && eachAddressAttribute.FirstChild.Value == "country")
    //                    countryFound = true;
    //            }
    //            if (countryFound) break;
    //        }
    //    }
    //    if (countryFound && countryCode != null)
    //    {
    //        //assuming country will never be changed, insert highscore with country 
    //        PlayerPrefs.SetString(GameManager.countryCodeKey, countryCode);

    //        currSynch = StartCoroutine(GameManager.client.InvokeApi<Message>("makeCon", Method.GET, onMakeConComplete));
    //        Invoke("restartCon", 10f);
    //        GameManager.gm.statusMsg.text = "country found, connecting to server..";
    //        Debug.Log("country found!");
    //    }
    //    else
    //    {
    //        synchingfailed("Couldn't find country :(");
    //    }
    //}

}
