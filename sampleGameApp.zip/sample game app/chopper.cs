﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class chopper : MonoBehaviour
{

    bool hasPlayer = false;
    bool done = false;
    //player transform
    Transform pt;
    // Use this for initialization
    void Start()
    {
        GameManager.gm.jumping = true;
        pt = GameManager.gm.player.transform;
        //pt.position = new Vector3(11.8f,6.84f,-.4f);
        //pt.rotation = new Quaternion(15,-90,16,0);
        pt.parent = transform;
        pt.localPosition = new Vector3(-.4f, -.1f, .3f);
        pt.localEulerAngles = new Vector3(0, -45, 16);

        //GameManager.gm.player.transform.SetAsFirstSibling();
        hasPlayer = true;
    }

    // Update is called once per frame
    void Update()
    {

        if (transform.position.x < 0f && hasPlayer)
        {
            hasPlayer = false;
            StartCoroutine(droppingPlayer());
        }
    }
    IEnumerator droppingPlayer()
    {
        pt.parent = null;
        pt.localScale = new Vector3(1, 1, 1);
        GameManager.gm.jumping = false;

        Quaternion tarRot = Quaternion.identity;
        float ti = Time.time;
        do
        {
            pt.rotation = Quaternion.RotateTowards(pt.rotation, tarRot, 150 * Time.deltaTime);
            yield return null;
        } while (pt.rotation != tarRot && Time.time - ti < 1.5f);
        pt.rotation = Quaternion.identity;
        done = true;
    }
    public void chopperOut()
    {
        StartCoroutine(leaving());
    }
    IEnumerator leaving()
    {
        yield return new WaitUntil(() => done);
        Destroy(gameObject);
    }
}
