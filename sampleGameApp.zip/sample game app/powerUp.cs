﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class powerUp : MonoBehaviour {
    public Sprite powerUpSprite;
    public float timeActive = 10f;
    public bool isActive = false;
    private float startTime;
    private float CurrentTime;
    public string startSfx;
    public string endSfx;

    public enum powerType {auto, shield, grenade, slow, none};
    public powerType powerName = powerType.slow;

    public virtual void activeOn()
    {
        startTime = Time.time;
        isActive = true;
        AudioManager.am.playSound(startSfx);
    }

    public virtual void activeOff() {
        isActive = false;
        GameManager.gm.deactivatePower();
        if(endSfx!=null && endSfx!="")AudioManager.am.playSound(endSfx);
        Destroy(gameObject);
    }
	// Update is called once per frame
	public virtual void Update () {
        if (isActive)
        {
            CurrentTime = (timeActive - (Time.time - startTime))/timeActive;
            //GameManager.gm.power1Button.image.fillAmount = CurrentTime;
            GameManager.gm.powerImages[0].fillAmount = CurrentTime;
            if (CurrentTime <=0) activeOff();

        }
    }
}
