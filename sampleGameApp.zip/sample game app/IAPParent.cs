﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class IAPParent : MonoBehaviour
{
    public static IAPParent instance;
    public GameObject coinObject;
    public static bool processing = false;
    public static bool initialized = false;

    public static readonly string product_250_Gold = "sample250";//.99
    public static readonly string product_1000_Gold = "sample1000";//2.99
    public static readonly string product_5000_Gold = "sample5000";//5.99
    public static readonly string product_20000_Gold = "sample20000";//9.99

    protected readonly string toSynch = "sampleSync";

    protected Vector3 spawnPos;

    public virtual void Start()
    {
        if (instance == null) instance = this;
        else if (!initialized)
        {
            Destroy(instance.gameObject);
            instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(gameObject);


        if (GameManager.gamePlayer.buy && PlayerPrefs.HasKey(toSynch) && GameManager.gamePlayer.id != "")
            StartCoroutine(GameManager.client.InvokeApi<Message, Message>("sampleSynch", RESTClient.Method.POST, Message.Create(GameManager.gamePlayer.id), onBuySynchComplete));

    }

    public static bool ifDoneIt()
    {
        return GameManager.gamePlayer.buy;// PlayerPrefs.HasKey(noMore);
    }
    public abstract void InitializePurchasing();

    public abstract bool IsInitialized();

    public void BuyGold(int idNo, Vector3 pos)
    {
        processing = true;
        spawnPos = pos;
        string proID = "";
        switch (idNo)
        {
            case 1: proID = product_250_Gold; break;
            case 2: proID = product_1000_Gold; break;
            case 3: proID = product_5000_Gold; break;
            case 4: proID = product_20000_Gold; break;
        }
        BuyProductID(proID);
    }
    public abstract void BuyProductID(string productId);

    protected void finishPurchase(bool ifDone, int collect)
    {
        if (ifDone)
        {
            PlayerPrefs.SetInt(GameManager.playerCoinsUnsynchedKey, 0);
            GameManager.gamePlayer.coins += collect;
            //if (PlayerPrefs.HasKey(noMore))PlayerPrefs.DeleteKey(noMore);
            //PlayerPrefs.SetInt(noMore,0);
            if (!GameManager.gamePlayer.buy)
            {
                GameManager.gamePlayer.buy = true;
                PlayerPrefs.SetInt(toSynch, 0);
                if (GameManager.gamePlayer.id != "") StartCoroutine(GameManager.client.InvokeApi<Message, Message>("sampleSynch", RESTClient.Method.POST, Message.Create(GameManager.gamePlayer.id), onBuySynchComplete));
            }
            dataControl.savePlayer(GameManager.gamePlayer);
            StartCoroutine(rewardsControl.repeatReward(coinObject, spawnPos, collect, 25, true));

            GameManager.gamePlayer.ifCoins = true;
            GameManager.gamePlayer.ifScore = false;
            GameManager.gamePlayer.ifMission = false;
            if (GameManager.gamePlayer.id != "") StartCoroutine(GameManager.client.InvokeApi<jointSynch, Message>("sampleSynch2", RESTClient.Method.POST, GameManager.gamePlayer, gameOverControl.onMultiSynchComplete));
            GameManager.gm.timedMsg(string.Format("ProcessPurchase: PASS. Product: '{0} Gold Coins'", collect));

        }
        processing = false;

    }

    protected virtual void onBuySynchComplete(RESTClient.IRestResponse<Message> response)
    {
        if (!response.IsError)
        {
            //statusMsg.text = "Highscore updated!";
            Debug.Log("On Buy Synch Complete: " + response.Url + " data: " + response.Content);
            Message h = response.Data;
            if (h.message == GameManager.gamePlayer.id)
                PlayerPrefs.DeleteKey(toSynch);
        }
        else
        {
            Debug.Log("Buy Synch Error Status:" + response.StatusCode + " Url: " + response.Url);
        }
    }
}
