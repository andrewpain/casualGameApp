﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class move_projectile_Forward : move_projectile
{
    //for player projectiles
    public bool isPlayerProjectile=false;

    public override void Start()
    {
        if (!isPlayerProjectile) base.Start();
    }
    protected override void calMove()
    {
        gameObject.transform.Translate(Vector3.forward * Time.deltaTime * speed);
    }

}
