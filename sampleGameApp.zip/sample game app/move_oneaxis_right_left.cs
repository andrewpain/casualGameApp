﻿using UnityEngine;
//using System.Collections;

public class move_oneaxis_right_left : movement
{

    public override void startPoints()
    {
        Vector3 minrange = GameManager.gm.MinRange;
        Vector3 maxrange = GameManager.gm.MaxRange;
        
        float randomx = maxrange.x - (transform.lossyScale.x / 2);
        float randomy = Random.Range(minrange.y + (transform.lossyScale.y / 2), maxrange.y - (transform.lossyScale.z / 2));
        float randomz = Random.Range(minrange.z + (transform.lossyScale.z / 2), maxrange.z - (transform.lossyScale.z / 2));
		if (minrange.z==maxrange.z) randomz =  maxrange.z;//TESTING FOR 2D GAME - (transform.lossyScale.z / 2);


        transform.position = new Vector3(randomx, randomy, randomz);
    }

    protected override void calMove()
    {
        gameObject.transform.Translate(-transform.right * Time.deltaTime * speed);
    }

    protected override bool ifBeyondBorders()
    {
        return transform.position.x - (transform.lossyScale.x / 2) <= GameManager.gm.MinRange.x;
    }
}
