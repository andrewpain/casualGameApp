﻿using UnityEngine;
//using System.Collections;
/// <summary>
/// this works as it should, but there is a slight glitch where when the player pauses the game,
/// a 'miss' is automatically regestered, and to undo the 'miss' cant check for if the player
/// had missed before the game was paused
/// UPDATE: glitch was fixed with method pausePowerFun
/// </summary>
public class mission_dontMiss : mission
{
    public override void setMissionStart(int cc, int mc, string mi)
    {
        oneGame = true;
        //all base does is set the current count
        base.setMissionStart(cc, mc, mi);
        missionAlias = missionType.hitEnemy;
        missionAlias2 = missionType2.dontMiss;
        //if the mission hasnt been set, thus new mission
        setDiff(10,20,50);
		//setDiff(1, 2, 3);
        //doneMessage = "Hit " + maxCount + " enemies without missing completed! :)";

    }


    public override string getStatus()
    {
        if (!complete)return "Hit " + maxCount + " enemies without missing. " + count + "/" + maxCount + " completed";
        else return "Hit " + maxCount + " enemies without missing completed! :)";

    }

    bool noMiss = true;
    bool isMissed = false;
    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        if (!noMiss && !isMissed) isMissed = true;
        if (noMiss && !complete)
        {
            if (p > 0)
            {
                count += p;
                Instantiate(progressParticle, pos, rot);
            }
            else noMiss = false;
            if (count >= maxCount && noMiss) finishMission();
        }
    }


    //function for if the player pauses the menu
    public void pausePowerFun()
    {
        if (!isMissed) noMiss = true;
    }

}
