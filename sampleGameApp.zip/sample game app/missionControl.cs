﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;
using System;
//using Azure.AppServices;
//using System.Xml;
using RESTClient;
using UnityEngine.UI;
//#if UNITY_ANDROID //&& !UNITY_EDITOR
//using Unity.Notifications.Android;
//#endif

public class missionControl : MonoBehaviour {
    Text missionDisplay;
    Animator an;
    mission gm;
    //public GameObject rewardCollector;

    //bool visible = false;
	// Use this for initialization
	void Start () {
        missionDisplay = transform.GetChild(0).gameObject.GetComponent<Text>();
        an = gameObject.GetComponent<Animator>();
        StartCoroutine(missionCheck());
    }

    IEnumerator missionCheck()
    {
        yield return new WaitUntil(() =>GameManager.gamePlayer!=null);
        if (GameManager.gamePlayer.id == "" || GameManager.gamePlayer.id==null) yield break;
        //name of mission
        string missionName = GameManager.gamePlayer.mname;
        //setting the mission if it exists
        if (missionName != "none")
        {
            //Debug.Log("mission found");
            yield return new WaitUntil(() => GameManager.sceneLoaded);
            GameManager.gm.gameMissionControl = this;
            int ms = PlayerPrefs.GetInt(GameManager.missionUnsynchedKey, -1);
            int mr = PlayerPrefs.GetInt(GameManager.missionUnRewardedKey, -1);
            //if the mission is completed
            if (ms != -1)
            {
                //if mission is complete but not synched
                if (ms == 0)
                {
                    Debug.Log("mission found is completed and to be synched");
                    GameManager.gamePlayer.ifMission = true;
                    GameManager.gamePlayer.ifMissionDone = true;
                    GameManager.gamePlayer.ifCoins = false;
                    GameManager.gamePlayer.ifScore = false;

                    GameManager.gamePlayer.missionDate = TimeZoneInfo.ConvertTime(DateTime.Parse(GameManager.gamePlayer.missionDate),TimeZoneInfo.Local, TimeZoneInfo.Utc).ToString();
                    //GameManager.gamePlayer.missionDate = TimeZone.CurrentTimeZone.ToUniversalTime(DateTime.Parse(GameManager.gamePlayer.missionDate)).ToString();
                    //GameManager.gamePlayer.missionDate = TimeZoneInfo.ConvertTimeToUtc(DateTime.Parse(GameManager.gamePlayer.missionDate),TimeZoneInfo.Local).ToString();
                    StartCoroutine(GameManager.client.InvokeApi<jointSynch, Message>("samplyMultiSynch", Method.POST, GameManager.gamePlayer, OnMissionDoneComplete));
                    //GameManager.gamePlayer.missionDate = /*TimeZoneInfo.ConvertTime(DateTime.Parse(GameManager.gamePlayer.missionDate),TimeZoneInfo.Utc, TimeZoneInfo.Local).ToString();*/TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Parse(GameManager.gamePlayer.missionDate)).ToString();
                    GameManager.gamePlayer.missionDate = TimeZoneInfo.ConvertTime(DateTime.Parse(GameManager.gamePlayer.missionDate),TimeZoneInfo.Utc, TimeZoneInfo.Local).ToString();
                    //GameManager.gamePlayer.missionDate = TimeZoneInfo.ConvertTimeFromUtc(DateTime.Parse(GameManager.gamePlayer.missionDate), TimeZoneInfo.Local).ToString();

                    //StartCoroutine(GameManager.client.InvokeApi<player_mission, Message>("missionDone", Method.POST, pm, OnMissionDoneComplete));
                    Debug.Log("completed mission began synching");
                }
                //if completed mission has not given reward yet
                if (mr == 0)
                {
                    Debug.Log("completed mission preparing for reward: " + missionName);
                    gameObject.AddComponent(Type.GetType(missionName));
                    gm = GameManager.gm.currentMission = gameObject.GetComponent<mission>();
                    //gm.setMissionStart(PlayerPrefs.GetInt(GameManager.missionCountKey, 0), PlayerPrefs.GetInt(GameManager.missionMaxCountKey, 0), PlayerPrefs.GetString(GameManager.missionMiscKey, ""));
                    gm.setMissionStart(GameManager.gamePlayer.curcount, GameManager.gamePlayer.maxcount, GameManager.gamePlayer.misc);
                    gm.complete = true;
                    toggleMissionVisibility(true);
                    Debug.Log("completed mission ready for reward collection");
                    //auto setting the mission to completed if the key exists
                }
                //to ensure the gameobject is deleted since the reward is collected 
                else if (mr==1)
                {
                    print("mission reward is collected, just to synch now");
                    if (ms ==1) Destroy(gameObject);
                    else rewardCollected = true;
                }
            }
            //if mission is not completed, thus set normally
            else
            {
                gameObject.AddComponent(Type.GetType(missionName));
                gm = GameManager.gm.currentMission = gameObject.GetComponent<mission>();
                //gm.setMissionStart(PlayerPrefs.GetInt(GameManager.missionCountKey, 0), PlayerPrefs.GetInt(GameManager.missionMaxCountKey, 0), PlayerPrefs.GetString(GameManager.missionMiscKey, ""));
                gm.setMissionStart(GameManager.gamePlayer.curcount, GameManager.gamePlayer.maxcount, GameManager.gamePlayer.misc);
                toggleMissionVisibility(true);
                //Debug.Log("mission finished setting");
            }
        }

        //is the last mission was more than a number of hours and there is a mission record synched with cloud
        else if ((DateTime.Now - DateTime.Parse(GameManager.gamePlayer.missionDate)).TotalHours >= mission.timeBetweenMissions.TotalHours)
        {
            Debug.Log("time passed..");
            //look up time of last mission
            //StartCoroutine(GameManager.client.GetTable<player_mission>("player_mission").Lookup<player_mission>(GameManager.gamePlayer.id/*PlayerPrefs.GetString(GameManager.missionIdKey, "")*/, OnMissionLookUpComplete));
            StartCoroutine(GameManager.client.InvokeApi<Message, jointSynch>("sampleGetMissionInfo", Method.POST, Message.Create(GameManager.gamePlayer.id), OnMissionLookUpComplete));

            Debug.Log("checking cloud..");
        }
        //no mission and time not yet passed
        else
        {
            print("not time for mission");
            Destroy(gameObject);
        }
    }
    public void toggleMissionVisibility(bool b)
    {
        if (b)
        {
            missionDisplay.text = gm.getStatus();
            an.SetTrigger("show");
        }
        else
        {
            an.SetTrigger("hide");
        }
    }

    public void gameOverMission()
    {

        if (gm.missionAlias == mission.missionType.playGame)
            gm.progressMission(1, transform.position, transform.rotation);

        gm.saveMission();

        if (gm.complete)
        {
            if (!PlayerPrefs.HasKey(GameManager.missionUnsynchedKey))
            {
                PlayerPrefs.SetInt(GameManager.missionUnsynchedKey, 0);
                GameManager.gamePlayer.ifMission = true;
            }
            //if it was already synched
            else GameManager.gamePlayer.ifMission = false;
            if (!PlayerPrefs.HasKey(GameManager.missionUnRewardedKey)) PlayerPrefs.SetInt(GameManager.missionUnRewardedKey, 0);

            GameManager.gamePlayer.curcount = 0;
            GameManager.gamePlayer.maxcount = 0;
            GameManager.gamePlayer.missionDate = DateTime.Now.ToString();
            GameManager.gamePlayer.misc = "";
            GameManager.gamePlayer.ifMissionDone = true;

            //if(Application.platform == RuntimePlatform.Android || 
            //    Application.platform == RuntimePlatform.IPhonePlayer)
            //    UnityEngine.iOS.LocalNotification.SendNotification(mission.timeBetweenMissions, "New Mission!", "The cubes are back at it again!",/*orange*/new Color32(254, 161, 0, 1), true, true, true, "app_icon");
            rewardsControl.makeNotification("New Mission", "The squares are back at it again!","3", mission.timeBetweenMissions);
        }
        else
        {
            GameManager.gamePlayer.curcount = gm.count;
            GameManager.gamePlayer.maxcount = gm.maxCount;
            GameManager.gamePlayer.misc = gm.misc;
            GameManager.gamePlayer.ifMission = true;
            GameManager.gamePlayer.ifMissionDone = false;
        }
        dataControl.savePlayer(GameManager.gamePlayer);

    }
    private void OnMissionLookUpComplete(IRestResponse<jointSynch[]> response)
    {
        if (!response.IsError)
        {
            Debug.Log("On Mission Look Up Complete: " + response.Url + " data: " + response.Content);
            jointSynch []pm = response.Data;
            if (pm.Length==0) return;
            if (pm[0].missionDate == null || pm[0].missionDate == "") pm[0].missionDate = new DateTime(2018, 1, 1, 1, 1, 1).ToString();
            //bool isTimePast = (DateTime.Now - TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Parse(pm[0].missionDate))).TotalHours >= mission.timeBetweenMissions.TotalHours;
            bool isTimePast = (DateTime.Now - TimeZoneInfo.ConvertTime(DateTime.Parse(pm[0].missionDate),TimeZoneInfo.Utc,TimeZoneInfo.Local)).TotalHours >= mission.timeBetweenMissions.TotalHours;
            //bool isTimePast = (DateTime.Now - TimeZoneInfo.ConvertTimeFromUtc(DateTime.Parse(pm[0].missionDate),TimeZoneInfo.Local)).TotalHours >= mission.timeBetweenMissions.TotalHours;

            //if there is already a mission saved on the cloud
            if (pm[0].mname != "none")
            {
                gameObject.AddComponent(Type.GetType(pm[0].mname));
                gm = GameManager.gm.currentMission = gameObject.GetComponent<mission>();
                gm.setMissionStart(pm[0].curcount, pm[0].maxcount, pm[0].misc);
                gm.saveMission();

                //code to show random mission here
                if (GameManager.gm.gameState == GameManager.gameStates.PrePlay)
                {
                    toggleMissionVisibility(true);
                }
                Debug.Log("mission downloaded");
            }
            //if more than certain amount of time passed, and there is no mission saved
            else if (isTimePast)
            {
                //gameObject.AddComponent(mission.getMission());
                gm = GameManager.gm.currentMission = (mission) gameObject.AddComponent(mission.getMission());// gameObject.GetComponent<mission>();
                gm.setMissionStart(0, 0, "");
                GameManager.gamePlayer.mname =  pm[0].mname = gm.GetType().ToString();
                GameManager.gamePlayer.curcount = pm[0].curcount = gm.count;
                GameManager.gamePlayer.maxcount = pm[0].maxcount = gm.maxCount;
                GameManager.gamePlayer.misc = pm[0].misc = gm.misc;
                GameManager.gamePlayer.ifCoins = false;
                GameManager.gamePlayer.ifScore = false;
                GameManager.gamePlayer.ifMission = true;
                GameManager.gamePlayer.ifMissionDone = false;
                //synching the new mission if it can
                StartCoroutine(GameManager.client.InvokeApi<jointSynch, Message>("multiSynch", Method.POST, GameManager.gamePlayer, OnMissionSynchComplete));
                Debug.Log("Attempting to synch new mission");

            }
            else if (!isTimePast)
            {

                //PlayerPrefs.SetString(GameManager.missionLastTimeKey, "" + TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Parse(pm.missionDate)));

                Debug.Log("Mission times not matching, but now fixed");
                //no mission and time not yet passed
                Destroy(gameObject);
            }
        }
        else
        {
            Debug.LogWarning("Read Error Status:" + response.StatusCode + " Url: " + response.Url);
            Debug.Log("Unable to look up mission");
            //no mission and time not yet passed
            Destroy(gameObject);
        }
    }
    //updating new mission to server complete
    private void OnMissionSynchComplete(IRestResponse<Message> response)
    {
        if (!response.IsError)
        {
            Debug.Log("On Mission Synch Complete: " + response.Url + " data: " + response.Content);
            //player_mission pm = response.Data;
            //synching the new mission if it can
            gm.saveMission();
            //code to choose random mission here
            if (GameManager.gm.gameState == GameManager.gameStates.PrePlay)
            {
                toggleMissionVisibility(true);
            }
        }
        else
        {
            Destroy(gm);
            GameManager.gm.currentMission = null;
            gm = null;
            GameManager.gamePlayer.mname = "none";
            GameManager.gamePlayer.curcount = 0;
            GameManager.gamePlayer.maxcount = 0;
            GameManager.gamePlayer.misc = "";
            dataControl.savePlayer(GameManager.gamePlayer);
            Debug.LogWarning("Read Error Status:" + response.StatusCode + " Url: " + response.Url);
            Debug.Log("Unable to synch new mission");
            //no mission and time not yet passed
            Destroy(gameObject);
        }
    }

    public void OnMissionUpdateComplete(IRestResponse<Message> response)
    {
        if (!response.IsError)
        {
            Debug.Log("On Mission Update Complete: " + response.Url + " data: " + response.Content);
            //statusMsg.text = "mission updated.";
            //GameManager.gm.timedMsg(response.Data.message);
        }
        else
        {
            //GameManager.gm.statusMsg.text = "error with synching mission";
            Debug.LogWarning("Mission update:" + response.StatusCode + " Url: " + response.Url);
        }
    }
    //bool to determine if mission control is ready to be deleted, since finished mission is synched and reward collected
    bool rewardCollected = false;
    public void OnMissionDoneComplete(IRestResponse<Message> response)
    {
        if (!response.IsError)
        {
            PlayerPrefs.SetInt(GameManager.missionUnsynchedKey,1);
            //statusMsg.text = "finished mission finished synching";
            //GameManager.gm.timedMsg("finished mission finished synching");
            Debug.Log("On Mission Done Complete: " + response.Url + " data: " + response.Content);
            mission.deleteMissionInfo();
        }
        else
        {
            //GameManager.gm.statusMsg.text = "error with synching finished mission";
            Debug.LogWarning("Mission done synch error:" + response.StatusCode + " Url: " + response.Url);
        }
        if (rewardCollected) Destroy(gameObject);
    }

}


