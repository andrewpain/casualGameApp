﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class customCoroutine {
    public Coroutine syncRoutine;
    public Coroutine waitRoutine;
    public bool isRunning = true;

    public customCoroutine(Coroutine sr,Coroutine wr)
    {
        syncRoutine = sr;
        waitRoutine = wr;
    }


}
