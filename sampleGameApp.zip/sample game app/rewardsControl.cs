﻿using System;
using System.Collections;
//using System.Collections.Generic;
using UnityEngine;
#if UNITY_ANDROID //&& !UNITY_EDITOR
using Unity.Notifications.Android;
#elif UNITY_WSA
using WSAUnity;
//using Microsoft.UnityPlugins;
#endif

using UnityEngine.UI;

public class rewardsControl : MonoBehaviour {
    public GameObject missionPanel, hourGiftPanel, dayGiftPanel,giftBox;
    public Animator boxAnimator;
    public Text boxItemNameTxt;
    //public Vector3 giftDisplayLocation;
    //public Vector3 giftDisplayScale;
    Text mText, hgTxt, dgTxt;
    DateTime mTime, hgTime, dgTime;
    //controls if the time for each is updated in the update method
    bool mCheck = false, hgCheck = false, dgCheck;
	// Use this for initialization
	void Start () {
        missionCal();
        hourGiftCal();
        dayGiftCal();
        //dgCountMax = UnityEngine.Random.Range(1,4);
    }

    private void OnEnable()
    {
        missionPanel.SetActive(false);
        hourGiftPanel.SetActive(false);
        dayGiftPanel.SetActive(false);
        StartCoroutine(showingPanels());
    }

    IEnumerator showingPanels()
    {
        if (GameManager.gm && GameManager.gm.currentMission) missionPanel.SetActive(true);
        yield return new WaitForSeconds(.25f);
        hourGiftPanel.SetActive(true);
        yield return new WaitForSeconds(.25f);
        dayGiftPanel.SetActive(true);

    }

    void missionCal()
    {
        mText = missionPanel.transform.GetChild(0).gameObject.GetComponent<Text>();
        if (/*GameManager.gm &&*/ GameManager.gm.currentMission)
        {
            mText.text = GameManager.gm.currentMission.getStatus();
            if (GameManager.gm.currentMission.complete && PlayerPrefs.GetInt(GameManager.missionUnRewardedKey,1)==0) missionPanel.transform.GetChild(1).gameObject.GetComponent<Button>().interactable = true;//making button visible
        }
        else
        {
            mTime = DateTime.Parse(GameManager.gamePlayer.missionDate);
            //calculating and displaying the amount of time remaining till next mission
            TimeSpan remain = mission.timeBetweenMissions - (DateTime.Now - mTime);
            if (remain.Hours <= 0 && remain.Minutes <= 0) missionPanel.SetActive(false);
            else
            {
                mText.text = string.Format("Next Mission in: {0}: {1}: {2}", remain.Hours, remain.Minutes,remain.Seconds);
                mCheck = true;
            }
        }
    }

    void hourGiftCal()
    {
        hgTxt = hourGiftPanel.transform.GetChild(0).gameObject.GetComponent<Text>();
        //hgTime = DateTime.Parse(PlayerPrefs.GetString(GameManager.lastHourGiftTimeKey, new DateTime(2018, 1, 1, 1, 1, 1).ToString()));
        hgTime = DateTime.Parse(GameManager.gamePlayer.hourly);
        TimeSpan remain = mission.timeBetweenGifts - (DateTime.Now - hgTime);
        if (remain.Hours <= 0 && remain.Milliseconds <= 0)
        {
            hgTxt.text = "Receive free gift!";
            hourGiftPanel.transform.GetChild(1).gameObject.GetComponent<Button>().interactable = true;//.SetActive(true);
        }
        else
        {
            hgTxt.text = string.Format("Next Gift in: {0}: {1}: {2}", remain.Hours, remain.Minutes, remain.Seconds);
            hgCheck = true;
        }
    }

    void dayGiftCal()
    {
        dgTxt = dayGiftPanel.transform.GetChild(0).gameObject.GetComponent<Text>();
        //dgTime = DateTime.Parse(PlayerPrefs.GetString(GameManager.lastDayGiftTimeKey, new DateTime(2018, 1, 1, 1, 1, 1).ToString()));
        dgTime = DateTime.Parse(GameManager.gamePlayer.daily);
        TimeSpan remain = mission.timeBetweenDayGifts - (DateTime.Now - dgTime);
        if (remain.Hours <= 0 && remain.Milliseconds <= 0)
        {
            dgTxt.text = "Receive free prize!";
            dayGiftPanel.transform.GetChild(1).gameObject.GetComponent<Button>().interactable = true;//.SetActive(true);
        }
        else
        {
            dgTxt.text = string.Format("Next Daily Gift in: {0}: {1}: {2}", remain.Hours, remain.Minutes, remain.Seconds);
            dgCheck = true;
        }
    }
	
    public GameObject rewardCollector;
    //when mission reward button is pushed
    public void missionCollect(Transform t)
    {
        StartCoroutine(repeatReward(rewardCollector,t.position, GameManager.gm.currentMission.completedMissionGiveReward(),15));
#if UNITY_WSA
        GameObject po = gameObject.GetComponentInParent<gameOverControl>().playButton;
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(po);
#endif
        PlayerPrefs.SetInt(GameManager.missionUnRewardedKey, 1);
        mission.deleteMissionInfo();
        mTime = DateTime.Parse(GameManager.gamePlayer.missionDate);
        //GameManager.gamePlayer.missionDate = DateTime.Now.ToString();
        //LocalNotification.SendNotification(mission.timeBetweenMissions,"New Mission!", "The cubes are back at it again!",/*orange*/new Color32(254, 161, 0, 1), true, true, true, "app_icon");
        mCheck = true;
    }
	
	//pushed by the hourly gift reward button
    public void hgCollect(Transform t)
    {
        StartCoroutine(repeatReward(rewardCollector, t.position, 100, 10));
#if UNITY_WSA
        GameObject po = gameObject.GetComponentInParent<gameOverControl>().playButton;
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(po);
#endif
        hgTime = DateTime.Now;
        //PlayerPrefs.SetString(GameManager.lastHourGiftTimeKey, hgTime.ToString());
        GameManager.gamePlayer.hourly = hgTime.ToString();
        dataControl.savePlayer(GameManager.gamePlayer);
        //if (Application.platform == RuntimePlatform.Android ||Application.platform == RuntimePlatform.IPhonePlayer)
        makeNotification("Coin Reward!", "Help has arrived ;)","1", mission.timeBetweenGifts);
        hgCheck = true;
    }
    //pushed by the gift collection button
    public void dgCollect(Transform t)
    {
        giftBox.SetActive(true);
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(giftBox);
#endif
        boxAnimator.SetTrigger("shake");
        AudioManager.am.playSound("boxShake");
    }

    int dgCount = 0;
    readonly int dgCountMax = 4;
    //when the gift box is hit
    public void dailyGiftBox(Transform t)
    {
        if (dgCount < dgCountMax)
        {
            dgCount++;
            boxAnimator.SetTrigger("shake");
            AudioManager.am.playSound("boxShake");
            return;
        }

        if (boxOpen == null) boxOpen = StartCoroutine(boxOpening(t));
        else if (boxOpenComplete)
        {
            giftBox.SetActive(false);
#if UNITY_WSA
            GameObject po = gameObject.GetComponentInParent<gameOverControl>().playButton;
            if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(po);
#endif
        }
    }
    Coroutine boxOpen;

    IEnumerator boxOpening(Transform t)
    {
        boxAnimator.SetTrigger("open");
		yield return new WaitUntil (() => boxAnimator.GetCurrentAnimatorStateInfo(0).IsName("voxelChestOpen"));
        yield return new WaitForSeconds(.5f);
        //yield return new WaitWhile (() => boxAnimator.GetCurrentAnimatorStateInfo(0).IsName("Open"));
        //CODE THAT CHOSES A RANDOM CHARACTER/AVATAR OR WEAPON OR SET NUMBER OF COINS
        float c = UnityEngine.Random.value;
        int i;
        string wonItem = "";
        //code for avatar
        if (c < .33)
        {                               //starts from 1 to avoid choosing the default
            i = UnityEngine.Random.Range(1, Enum.GetValues(typeof(GameManager.avatars)).Length);
            wonItem = "avatars/" + Enum.GetValues(typeof(GameManager.avatars)).GetValue(i).ToString();
        }
        //code for weapon
        else //if (c >= .66)
        {                               //starts from 1 to avoid choosing the default
            i = UnityEngine.Random.Range(1, Enum.GetValues(typeof(GameManager.weapons)).Length);
            wonItem = "weapons/" + Enum.GetValues(typeof(GameManager.weapons)).GetValue(i).ToString();
        }
        //code for coins 
        //else
        //{
        //    StartCoroutine(repeatReward(t.position, 75, 15));
        //}
        //if not a coin reward but an item
        if (wonItem!="")
        {
            GameObject go = Instantiate(Resources.Load(wonItem, typeof(GameObject))) as GameObject;
            go.transform.parent = t;
            go.transform.localPosition = new Vector3(0,0,0);
            //saving won item here, cuts out the 'weapons/' / 'avatars/' at beginning of name
            print(wonItem.Substring(8));
            ItemManager.addItem(wonItem.Substring(8),DateTime.UtcNow.ToString(),false,false);

            Animator an;
            if (go.name.StartsWith("avatar")) an = go.GetComponent<Animator>();
            else an = go.AddComponent<Animator>();
            an.runtimeAnimatorController = Resources.Load("anim/prizeItem"/*, typeof(Animator)*/) as RuntimeAnimatorController;
            an.SetTrigger("prizeMove");
            boxItemNameTxt.text = go.GetComponent<infoItem>().iName;
            boxItemNameTxt.gameObject.SetActive(true);
            //waiting for animation to finish
            yield return new WaitUntil (() => an.GetCurrentAnimatorStateInfo(0).IsName("movingPrize"));
			AudioManager.am.playSound("boxReward");
            yield return new WaitWhile (() => an.GetCurrentAnimatorStateInfo(0).IsName("movingPrize"));

            Destroy(an);
            print("animator destroyed");

            //adding rotation
            Rotate r = go.AddComponent<Rotate>();
            r.way = Rotate.whichWayToRotate.AroundY;
            r.speed = 45f;

        }
        dgTime = DateTime.Now;
        //PlayerPrefs.SetString(GameManager.lastDayGiftTimeKey, dgTime.ToString());
        GameManager.gamePlayer.daily = dgTime.ToString();
        dataControl.savePlayer(GameManager.gamePlayer);
        //if (Application.platform == RuntimePlatform.Android ||Application.platform == RuntimePlatform.IPhonePlayer)
        makeNotification("Daily Gift!", "The squares think you're weak..Prove them wrong!", "2", mission.timeBetweenDayGifts);

        dgCheck = true;
        boxOpenComplete = true;

    }
    public static void makeNotification(string title, string text, string channel, TimeSpan totalTime)
    {
#if UNITY_ANDROID //&& !UNITY_EDITOR

        var notification = new AndroidNotification();
        notification.Title = title;
        notification.Text = text;
        notification.FireTime = System.DateTime.Now.AddMinutes(totalTime.TotalMinutes);
        notification.LargeIcon = "icon_0";
        notification.SmallIcon = "icon_1";
        notification.ShouldAutoCancel= true;
        AndroidNotificationCenter.SendNotification(notification, channel);
#elif UNITY_WSA //&& !UNITY_EDITOR
        string[] info = new string []{ title, text };
        //Toasts.ShowToast(ToastTemplateType.ToastText01, new string[] { "toasting to good life." }, null);
        Toasts.ScheduleToast(ToastTemplateType.ToastText02, info/*"launcher512x512_notif.png"*/, DateTimeOffset.Now + totalTime);//new TimeSpan(0,Convert.ToInt32(timeMinutes),0));
        
#endif
    }
    bool boxOpenComplete = false;
    public static IEnumerator repeatReward(GameObject rewardObject, Vector3 pos, int reward, int count, bool safety=false)
    {
        for (int i = 0; i < count; i++)
        {
            Instantiate(rewardObject, pos, Quaternion.identity).GetComponent<rewardMovement>().setStart(1f,reward/count,null,safety);
            yield return new WaitForSeconds(.2f);
        }
    }
    private void Update()
    {
        TimeSpan remain;

        if (mCheck)
        {
            remain = mission.timeBetweenMissions - (DateTime.Now - mTime);
            mText.text = string.Format("Next Mission in: {0}: {1}: {2}", remain.Hours, remain.Minutes, remain.Seconds);
        }
        if (hgCheck)
        {
            remain = mission.timeBetweenGifts - (DateTime.Now - hgTime);
            hgTxt.text = string.Format("Next Gift in: {0}: {1}: {2}", remain.Hours, remain.Minutes, remain.Seconds);
        }
        if (dgCheck)
        {
            remain = mission.timeBetweenDayGifts - (DateTime.Now - dgTime);
            dgTxt.text = string.Format("Next Daily gift in: {0}: {1}: {2}", remain.Hours, remain.Minutes, remain.Seconds);
        }
    }
}
