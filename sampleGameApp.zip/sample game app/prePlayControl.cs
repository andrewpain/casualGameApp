﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;
using System;

public class prePlayControl : MonoBehaviour {

    public GameObject helicopter;
    [HideInInspector]
    public Animator prePlayAnimator;

    public GameObject defButton;

    void setDefButton ()
    {
#if UNITY_WSA
        if(GameManager.ifJoyStick)UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(defButton);
#endif
    }
    public void Start()
    {
        InvokeRepeating("changeSky",7.5f, 10f);
        prePlayAnimator = gameObject.GetComponent<Animator>();
    }
    public void changeSky()
    {
        if (GameManager.gm && GameManager.gm.spawn) GameManager.gm.spawn.changeTheSky(false);
		//print("sky changed");
    }
    public void loadItemsScene(string i)
    {
        //char i = 'w';
        if (GameManager.gm.gameState != GameManager.gameStates.PrePlay) return;

        int num;
        if (i == "w")
        {
            GameManager.gm.gameState = GameManager.gameStates.weaponMenu;
            num = 0;
        }
        else
        {
            GameManager.gm.gameState = GameManager.gameStates.avatarMenu;
            num = 1;
        }
        //SceneManager.LoadScene(1);
        GameManager.gm.player.SetActive(false);
        GameManager.gm.weapon.SetActive(false);
        //weapons index is 1, canvas is 3
        Animator a = GameManager.gm.itemContainer.GetComponent<Animator>();

        GameManager.gm.setCamManualMove(false);
        Animator ca = Camera.main.gameObject.GetComponent<Animator>();
        ca.SetFloat("direct", 1);
        ca.SetTrigger("toItems");

        ItemManager im = GameManager.gm.itemContainer.transform.GetChild(num).gameObject.GetComponent<ItemManager>();
        StartCoroutine(im.setViewedItem(true,true,true));
        im.resetTypeDisplay(true);

        GameManager.gm.itemContainer.transform.GetChild(2).gameObject.SetActive(true);//canvas and other objects

        //Animator ani = GameManager.gm.gameContainer.GetComponent<Animator>();

        /*ani*/prePlayAnimator.SetFloat("direct",-1);
        /*ani*/prePlayAnimator.SetTrigger("enter");
        //ani.Play("enterButtons");
        if (GameManager.gm.currentMission && GameManager.gm.gameMissionControl)
            GameManager.gm.gameMissionControl.toggleMissionVisibility(false);
        a.SetFloat("direct", 1);
        a.SetTrigger("items");

        GameManager.gm.loadingLogo.SetFloat("direct",1f);
        GameManager.gm.loadingLogo.SetTrigger("move");
        //a.Play("itemButtonsEnter");

    }
    public void preToPlaying()
    {
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(null);
#endif
        //if (GameManager.gm.statusMsg.text != "") GameManager.gm.statusMsg.text = "";
        GameManager.gm.coinDisplay.text = "0";
        GameManager.gm.scoreDisplay.text = "0";

        float bl = PlayerPrefs.GetFloat(GameManager.borderLengthKey, 0f);
        //PERHAPS put into a coroutine to make 'adjust' variable more precise
        if (bl == 0f && !PlayerPrefs.HasKey(GameManager.borderLengthKey))
        {
            //StartCoroutine(getBorder());
            Camera cam = Camera.main;

            Vector3 pMinRange = new Vector3(GameManager.gm.MinRange.x, GameManager.gm.MinRange.y, GameManager.gm.player.transform.position.z);
            Vector3 pMaxRange = new Vector3(GameManager.gm.MaxRange.x, GameManager.gm.MaxRange.y, GameManager.gm.player.transform.position.z);
            if (cam.WorldToViewportPoint(pMinRange).x < 0 || cam.WorldToViewportPoint(pMaxRange).x > 1)
            {
                float adjust = .1f;
                do
                {
                    pMinRange.x += adjust;
                    pMaxRange.x -= adjust;
                    print("finding border");
                    //yield return null;
                } while (cam.WorldToViewportPoint(pMinRange).x < 0 || cam.WorldToViewportPoint(pMaxRange).x > 1);
            }

            bl = pMaxRange.x;
            PlayerPrefs.SetFloat(GameManager.borderLengthKey, bl);
            //GameManager.gm.player.GetComponent<move_player>().border = GameManager.gm.border = PlayerPrefs.GetFloat(GameManager.borderLengthKey, 0f);
        }

        //setting the borders here 
        GameManager.gm.MinRange.x = -bl;
        GameManager.gm.MaxRange.x = bl;
        GameObject w1 = GameObject.Find("wallLeft");
        GameObject w2 = GameObject.Find("wallRight");
        w1.transform.position = new Vector3(-bl-.5f, w1.transform.position.y, w1.transform.position.z);
        w2.transform.position = new Vector3(bl, w2.transform.position.y, w2.transform.position.z);
        w1.isStatic = true;
        w2.isStatic = true;

        //if (GameManager.gm.missionPanel.activeInHierarchy) GameManager.gm.missionPanel.SetActive(false);
        if (GameManager.gm.currentMission) GameManager.gm.gameMissionControl.toggleMissionVisibility(false);
        Destroy(GameManager.gm.itemContainer);
        Destroy(GameManager.gm.loadingLogo.gameObject);

        //setting the muzzle flash 
        GameManager.gm.weapon.GetComponent<shooter_weapon>().setMuzzleFlash();
        //setting the avatar ans its special abilites
        GameManager.gm.playerInfo.setAbilities();
        GameManager.gm.playerHealth.setLife();
        GameManager.gm.player.GetComponent<move_player>().border = GameManager.gm.border = PlayerPrefs.GetFloat(GameManager.borderLengthKey, 0f);

        //destroys crosshair if weapon is not dual, thus not using it
        if (!GameManager.gm.weapon.GetComponent<infoWeapon>().isDual) Destroy(GameManager.gm.crossHair2.gameObject);
        
        //creates helicopter that brings player into the game
        Instantiate(helicopter);

        GameManager.gm.gameState = GameManager.gameStates.Playing;
		GameManager.gm.spawn.resetEnemiesShown();

        AudioManager.am.playMusic("1");
        Invoke("camCheck", 1f);


    }
    void camCheck()
    {
        Destroy(Camera.main.GetComponent<Animator>());
        GC.Collect();
        Destroy(gameObject);
    }

}
