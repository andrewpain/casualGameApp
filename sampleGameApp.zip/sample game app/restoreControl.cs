﻿using UnityEngine;
//using System.Collections;
using System;
//class used to hold cloud records, and save if need be
public class restoreControl
{
    //public player cloudPlayer;//cloud player
    //public highscore cloudHighscore;//cloud highscore
    public jointSynch cloudJoint;//cloud jointSynch

    public playerItem[] cloudItems;
    public string[] localWeapons; //local weapons
    public string[] localAvatars;//local avatars


    public void saveCloudData()
    {
        //if (cloudItems == null) return;

        GameManager.gamePlayer.id = cloudJoint.id;
        GameManager.gamePlayer.playerId = cloudJoint.playerId;
        if (GameManager.gamePlayer.playerId.StartsWith("play") || GameManager.gamePlayer.playerId.StartsWith("uwpp") || GameManager.gamePlayer.playerId.StartsWith("test"))
        {
            Guid guid;
            try
            {
                guid = new Guid(GameManager.gamePlayer.playerId.Substring(4, GameManager.gamePlayer.playerId.Length - 4));
                GameManager.gamePlayer.playerId = "";
            }
            catch (Exception e) { Debug.Log("could not parse Guid for player id: " + e.Message); }
        }
        //platform id(s)
#if UNITY_ANDROID
        GameManager.gamePlayer.go = cloudJoint.go;
#elif UNITY_WSA
        GameManager.gamePlayer.mi = cloudJoint.mi;
#endif

        GameManager.gamePlayer.buy = cloudJoint.buy;
        GameManager.gamePlayer.coins = cloudJoint.coins;

        GameManager.gamePlayer.score = cloudJoint.score;
        GameManager.gamePlayer.weaponId = cloudJoint.weaponId;


        PlayerPrefs.SetInt(GameManager.missionUnsynchedKey,1);
        PlayerPrefs.SetInt(GameManager.missionUnRewardedKey,1);
        mission.deleteMissionInfo();

        GameManager.gamePlayer.mname = cloudJoint.mname;
        GameManager.gamePlayer.curcount = cloudJoint.curcount;
        GameManager.gamePlayer.maxcount = cloudJoint.maxcount;
        GameManager.gamePlayer.misc = cloudJoint.misc;

        dataControl.savePlayer(GameManager.gamePlayer);

        //deleting the current weapons to overwrite them
        for (int i = 0; i < localWeapons.Length; i++)
        {
            if(GameManager.gameItems.itemNames.Contains(localWeapons[i]))
            {
                ItemManager.deleteItem(GameManager.gameItems.itemNames.IndexOf(localWeapons[i]));
            }
        }
        //deleting local avatars
        for (int i = 0; i < localAvatars.Length; i++)
        {
            //if (PlayerPrefs.HasKey(localAvatars[i]))
            if (GameManager.gameItems.itemNames.Contains(localAvatars[i]))
            {
                ItemManager.deleteItem(GameManager.gameItems.itemNames.IndexOf(localAvatars[i]));
            }
        }

        //saving cloud weapons/items
        for (int i = 0; i < cloudItems.Length; i++)
        {
            DateTime ts;
            //gettine time if there is a time saved
            if (cloudItems[i].boughtAt != "" && cloudItems[i].boughtAt != null)
                ts = /*TimeZone.CurrentTimeZone.ToLocalTime*/(DateTime.Parse(cloudItems[i].boughtAt));
            //if there is no time, just in case
            else ts = DateTime.UtcNow;

            //if there is still time on the weapon
            if ((DateTime.UtcNow - ts).TotalHours <= 4 || cloudItems[i].perm)
            {
                //if not permanent, save a start time
                ItemManager.addItem(cloudItems[i].itemid,ts.ToString(),cloudItems[i].perm, true);
            }
        }

    }
}
