﻿using UnityEngine;
//using System.Collections;
//using System;

public class Health_Projectile : Health
{
    //private bool hitSurface = false;
    //public GameObject hitExplosion;
    public bool detatchChildren = false;
	// [HideInInspector]
	// public bool isDestroyable = true;
    public override void ApplyDamage(float amount)
    {
        if (isAlive)
        {
            isAlive = false;
            if (GameManager.gm && GameManager.gm.currentMission && GameManager.gm.currentMission.missionAlias == mission.missionType.hitPro)
                GameManager.gm.currentMission.progressMission(1, transform.position, transform.rotation);
            activateExplosion();
        }
    }
    //placed in this class because gameobjects that use damage class doesnt always use the hit ground function/particle effect
    //private void OnTriggerStay(Collider other)
    //{

    //    if (other.gameObject.name == "ground" && isAlive && gameObject.transform.position.y <= .5f)
    //    {
    //        isAlive = false;
    //        hitSurface = true;
    //        activateExplosion();
    //    }
    //}
    public override void activateExplosion()
    {
        if (detatchChildren && gameObject.transform.childCount > 0)
        {
            //gameObject.transform.GetChild(0).GetComponent<ParticleSystem>().loop = false;
            ParticleSystem ps = gameObject.transform.GetChild(0).gameObject.GetComponent<ParticleSystem>();
            Vector3 psScale = ps.gameObject.transform.localScale;
            if (ps)
            {
                ParticleSystem.MainModule psm = ps.main;
                psm.loop = false;
            }
            gameObject.transform.DetachChildren();
            ps.gameObject.transform.localScale = psScale;
        }

        //GameObject go = null;
        //if the player hit the projectile (regular projectile)
        //if (/*explosionPrefab && */!hitSurface) go = Instantiate(explosionPrefab, transform.position, transform.rotation);
        // if projectile hits the ground in the game (same animation as hitting the player for now)
        //else if(/*hitExplosion &&*/ hitSurface) go = Instantiate(hitExplosion, transform.position,Quaternion.LookRotation(Vector3.up));

        AudioManager.am.playSound(explosionSound, /*go*/Instantiate(explosionPrefab, transform.position, transform.rotation));
        //destroys the fake game object
        if (GameManager.gm.playerInfo.lessSuicide) gameObject.GetComponent<move_projectile>().destroyFakeTarget();
        //Destroy(gameObject);
        StartCoroutine(removeThenDelete());
    }

}
