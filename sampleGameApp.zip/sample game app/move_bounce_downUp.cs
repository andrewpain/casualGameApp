﻿using UnityEngine;
//using System.Collections;

public class move_bounce_downUp: bounce
{
    public override void Start()
    {
        base.Start();
        wall = "ground";
        exitWall = "roof";
    }
    public override void startPoints()
    {
        Vector3 minrange = GameManager.gm.MinRange;
        Vector3 maxrange = GameManager.gm.MaxRange;

        //STATICLY MADE SO THAT OBJECT APPEARS IN THE MIDDLE OF X AXIS
        float randomx = Random.Range(minrange.x + (transform.lossyScale.x / 2), maxrange.x - (transform.lossyScale.x / 2));
        float randomy = 4.5f;//(maxrange.y + minrange.y) / 2; 
        float randomz = Random.Range(minrange.z + (transform.lossyScale.z / 2), maxrange.z - (transform.lossyScale.z / 2));
		if (minrange.z==maxrange.z) randomz =  maxrange.z;//TESTING FOR 2D GAME - (transform.lossyScale.z / 2);


        transform.position = new Vector3(randomx, randomy, randomz);
    }

    protected override void calMove()
    {
        if (!turn) gameObject.transform.Translate(Vector3.down * Time.deltaTime * speed);

        else gameObject.transform.Translate(Vector3.up * Time.deltaTime * speed);
    }

    protected override bool ifBeyondBorders()
    {
        return transform.position.y + (transform.lossyScale.y / 2) >= GameManager.gm.MaxRange.y;
    }
}
