﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class move_projectile_laserBombMaker : move_projectile {
    //public GameObject caution;
    //private Material myMaterial;
    //private bool isEmitting = false;
    //public GameObject laserBeam;
    public float blinkingSpeed = 1f;
    public float waitingTime = 5f;
    private float waiting = 0f;
    private float increaseSpeedTime;
    //private bool readyToDestroy = false;
    public float timeTillDestroy = 1.5f;
    private bool done = false;
    private float waitingCap;

    //these are used to draw the laser line from the object to the player
    //public Transform startPoint;
    //public Transform endPoint;
    public GameObject laser_line;
    //this is the rotating part of the rotating enemy where we get the start point of the laser
	public Rotate rotator;
	public GameObject muzzleFlash;
	
    // Use this for initialization
    public override void Start() {

        base.Start();
        startPoints();

        //if (GameManager.gm) endPoint = GameManager.gm.player.transform;
        //player's position
        gameObject.transform.LookAt(target);
        //makes sure the emission is black /off so that animation shows properly
        //myMaterial = gameObject.GetComponent<Renderer>().material;
        //myMaterial.SetColor("_Color", Color.white);

        increaseSpeedTime = Time.time + (waitingTime - 1.5f);// .705f is the length of the sound
        waiting = Time.time + blinkingSpeed;
        waitingCap = Time.time + waitingTime;
        //rotator = gameObject.GetComponent<Rotate>();
    }
    LineRenderer laser;
	
    void createLaserThenDestroy()
    {
        //if (!isEmitting) switchEmission();

        //increasing the rotation speed more
        rotator.speed += 150;
		
		muzzleFlash = Instantiate(muzzleFlash, rotator.gameObject.transform.position + rotator.gameObject.transform.forward, transform.rotation);
        muzzleFlash.transform.parent = transform;
		GameObject laserLine = Instantiate(laser_line) as GameObject;//<LineRenderer>();
        laserLine.transform.parent = transform;
        laser = laserLine.GetComponent<LineRenderer>();

        laser.SetPosition(0, rotator.gameObject.transform.position + rotator.gameObject.transform.forward);
        laser.SetPosition(1, target.position);

        AudioManager.am.playSound("laser",laserLine);
        //takes life from player, once player has the health component, else an error will occur
        if ((GameManager.gm && GameManager.gm.playerHealth) && 
            (!GameManager.gm.playerInfo.lessSuicide || !fakeTarget))
            GameManager.gm.playerHealth.ApplyDamage(1);
        //slows down in 1 second since laser disappears in one second

        Invoke("slowRotate", 1.5f);
    }

    void slowRotate()
    {
		ParticleSystem.MainModule mm = muzzleFlash.GetComponent<ParticleSystem>().main;
		mm.loop = false;
        rotator.speed -= 250;
        Invoke("timeToGo",timeTillDestroy);
    }

    void timeToGo()
    {
        Animator a = gameObject.GetComponent<Animator>();
        if (a != null) a.SetTrigger("exit");
        else Destroy(gameObject);
    }
    protected override void OnTriggerEnter(Collider other){}
    protected override void OnTriggerStay(Collider other){}
    //void switchEmission()
    //{
    //    //if (!readyToDestroy)
    //    {
    //        if (isEmitting)
    //        {
    //            myMaterial.SetColor("_Color", Color.white);
    //            isEmitting = false;
    //        }
    //        else
    //        {
    //            myMaterial.SetColor("_Color", Color.red);
    //            isEmitting = true;
    //        }
    //    }
    //}

    public override void startPoints()
    {
        Vector3 minrange = GameManager.gm.MinRange;
        Vector3 maxrange = GameManager.gm.MaxRange;

        float randomx = 0;
        float randomy = 0;
        float randomz = Random.Range(minrange.z, maxrange.z-1f);
		if (minrange.z==maxrange.z) randomz = minrange.z-1f;


        int rn = Random.Range(0, 3);

        switch (rn)
        {
            case 0://on the top of the screen
                randomx = Random.Range(minrange.x + 1f, maxrange.x - 1f);
                randomy = maxrange.y - 1.1f;// highest visible point in the screen; (maxrange.y - 1.1f)
                break;
            case 1://on the left of the screen
                randomx = minrange.x + 1f;
                randomy = Random.Range(minrange.y + 2f, maxrange.y - 1.1f);
                break;
            case 2://on the right on of the screen
                randomx = maxrange.x - 1f;
                randomy = Random.Range(minrange.y + 2f, maxrange.y - 1.1f);
                break;

        }

        transform.position = new Vector3(randomx, randomy, randomz);
    }
    [HideInInspector]
    public bool rotated = false;
    protected override void calMove()
    {
        transform.LookAt(target);
		//transform.Rotate(Vector3.forward * Time.deltaTime * speed);

        //this is suppose to rotate the gameobject towards the player
        //Vector3 relPos = target.position - transform.position;
        //Quaternion tarRot = Quaternion.LookRotation(relPos);
        //transform.rotation = Quaternion.Lerp(transform.rotation, tarRot, Time.unscaledDeltaTime);
        //transform.rotation = Quaternion.Slerp(transform.rotation, tarRot, .5f);
        if (Time.time > waiting && Time.time < waitingCap && !done)
        {
            //switchEmission();

            if (Time.time < increaseSpeedTime)
                waiting = Time.time + blinkingSpeed;
            else
            {
                waiting = Time.time + blinkingSpeed / 5;
                //increases the rotation speed
                if (!rotated)
                {
                    rotated = true;
                    AudioManager.am.playSound("missileWarning", gameObject);
                    rotator.speed += 100;

                }
            }
        }
        else if (Time.time >= waitingCap && !done)
        {
            createLaserThenDestroy();
            done = true;
        }
        else if (done && laser)
        {
            laser.SetPosition(0, rotator.gameObject.transform.position + rotator.gameObject.transform.forward);
            laser.SetPosition(1, target.position);
        }
    }
}
