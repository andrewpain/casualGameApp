﻿using UnityEngine;
using System.Collections;

public abstract class Health : MonoBehaviour
{
    [HideInInspector]
    public bool isAlive = true;
    public GameObject explosionPrefab;
    public string explosionSound;

    // Use this for initialization
    public virtual void Start(){}

    //public virtual void Update() { }
    //make sure to change isAlive to false and destroy gameobject
    public abstract void ApplyDamage(float amount);

    public virtual void activateExplosion()
    {
        //if (explosionPrefab)
        //transform.position = GameManager.explosionLocation(transform.position);
        GameObject go = Instantiate(explosionPrefab, GameManager.explosionLocation(transform.position), explosionPrefab.transform.rotation);
        if (explosionSound!=null && explosionSound!="")AudioManager.am.playSound(explosionSound,go);
        //if (gameObject)Destroy(gameObject);
        StartCoroutine(removeThenDelete());
    }
    //this is so that the projectile particle effect will collide with the object then it gets destroyed
    protected virtual IEnumerator removeThenDelete()
    {
        //setting the trigger to false so that it can wait for the impact from the projectile
        //done because the enemies block the projectile even though the player wasnt aimed at that particular enemy
        Collider bc = GetComponent<Collider>();
        if (bc) bc.isTrigger = false;
        
        MeshRenderer mr = gameObject.GetComponent<MeshRenderer>();
        if (!mr)
        {
            int tc = transform.childCount;
            for (int i = 0; i < tc; i++)
            {
                mr = transform.GetChild(i).gameObject.GetComponent<MeshRenderer>();
                if (mr) mr.enabled = false;
            }
        }
        else mr.enabled = false;
        transform.parent = null;
        gameObject.tag = "Untagged";
        yield return new WaitForSecondsRealtime(.2f);
        if (gameObject) Destroy(gameObject);

    }
    //METHOD WAS PLACED HERE SINCE MOVEMENT SCRIPT IS ADDED TO OBJECT IN RUN TIME
    //THIS IS TRIGGERED BY THE EXIT ANIMATION IN ENEMY GAMEOBJECTS
    public void byeBye()
    {
        if (gameObject)
		{ 
			if(tag=="Enemy")GameManager.gm.spawn.addToMiss();
			Destroy(gameObject);
        }
	}

}
