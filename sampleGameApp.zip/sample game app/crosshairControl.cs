﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class crosshairControl : MonoBehaviour {

    public float visibleTime = 1.5f;
    Coroutine waiting;

    public void enableCrosshair(Vector3 pos, bool ifAuto)
    {
        transform.position = pos;
        if (!gameObject.activeSelf) gameObject.SetActive(true);

        if (!ifAuto)
        {
            if (waiting != null) StopCoroutine(waiting);
            if (gameObject.activeInHierarchy)waiting = StartCoroutine(disablingNow());
        }
    }

#if UNITY_WSA
    readonly float sWidth = Screen.width;
    readonly float sHeight = Screen.height;
    //in the event that the player is using gamePad/xBox controller
    public void setCrossHair(Vector3 pos)
    {
        transform.position += pos;
        if (!gameObject.activeSelf) gameObject.SetActive(true);

        if (transform.position.x > sWidth) transform.position = new Vector3(sWidth, transform.position.y,transform.position.z);
        else if (transform.position.x < 0) transform.position = new Vector3(0, transform.position.y, transform.position.z);
        if (transform.position.y > sHeight) transform.position = new Vector3(transform.position.x, sHeight, transform.position.z);
        else if (transform.position.y < 0) transform.position = new Vector3(transform.position.x, 0, transform.position.z);

    }
#endif

    public void disableCrosshair()
    {
        if (!gameObject.activeSelf) return;
        //if (IsInvoking("disablingCrosshair")) CancelInvoke("disablingCrosshair");
        //Invoke("disablingCrosshair", visibleTime);
        if (waiting != null) StopCoroutine(waiting);
        waiting = StartCoroutine(disablingNow());
    }

    IEnumerator disablingNow()
    {
        yield return new WaitForSeconds(visibleTime);
        gameObject.SetActive(false);
    }

	//public void disablingCrosshair()
	//{
	//	gameObject.SetActive(false);
	//}
    //private void OnEnable()
    //{
    //    //if(GameManager.powerActive != powerUp.powerType.auto)
    //    Invoke("disableCrosshair", visibleTime);
    //}




}
