﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
//using UnityEngine.Purchasing;
//using Azure.AppServices;
using RESTClient;
//using Microsoft.WindowsAzure.MobileServices;
public class ItemManager : MonoBehaviour {

    //public bool deleteMemory = false;
    public Button rentBuyButton;
    public Button permanentBuyButton;
    public Button watchAdButton;

    public Text i_name;
    public Text i_desc;
    public Text i_price;
    public Text i_pPrice;
    //to show time remaining where applicable
    public Text i_time;
    private infoItem chosenItem;
    private DateTime timeStarted;

    private GameObject[] allItems;
    private int index = 0;
    private int indexL;
    private int indexR;
    private int indexL2;
    private int indexR2;

    //rotation speed;
    private float rs = 40f;

    public GameObject CoinSelectionPanel;
    public GameObject mainPanel;
    public GameObject mainPanelContents;
    public GameObject leftRightAni;
    //public GameObject IAP;
    public GameObject moreCoinsButton;
    public GameObject typePanel;
    public Animator typeAni;
    public Text typeTitle;
    //public Image typeImage;
    public Text typeDesc;
    public float otherItemDistance = 1f;
    private readonly Vector3 centerPos = new Vector3(0, GameManager.playerYPos, GameManager.playerZPos);
    private Vector3 rightPos;
    private Vector3 rightPos2;
    private Vector3 leftPos;
    private Vector3 leftPos2;
    //public Camera itemMenuCam;

    // Use this for initialization
    //GameObject rotateObject;
    
    private bool sceneLoaded = false;

    public GameObject loading;
    private GameObject loadingNow;
    public GameObject boughtAnimation;

    public GameObject power;
    public GameObject dual;
    public GameObject spread;
    public GameObject auto;

    public GameObject life;
    public GameObject powerUp;
    public GameObject bomb;
    public GameObject coin;
    public GameObject missile;

    public GameObject defTypeButton, defCoinButton;

    public static bool playingAD = false;


    char gs;
    //Image adImage;
    void Start()
    {
//#if UNITY_EDITOR
        //SETS THE BUTTON TO GET MORE COINS TO BE ACTIVE ONLY FOR TESTING
//        moreCoinsButton.SetActive(true);
        //CoinSelectionPanel.SetActive(true);

//#endif
        rightPos = new Vector3(otherItemDistance, GameManager.playerYPos, GameManager.playerZPos);
        leftPos = new Vector3(-otherItemDistance, GameManager.playerYPos, GameManager.playerZPos);
        rightPos2 = new Vector3(otherItemDistance * 2, GameManager.playerYPos, GameManager.playerZPos);
        leftPos2 = new Vector3(-otherItemDistance * 2, GameManager.playerYPos, GameManager.playerZPos);


        if (i_time) i_time.text = "";

        //to make sure buttons pushed doesnt initiate both scripts but only the active ones (weapon/avatar)
        if (gameObject.name.Contains("weapon")) gs = 'w';
        else gs = 'a';

        //if (gameObject.name.Contains("weapon")) allItems = new GameObject[Enum.GetValues(typeof(GameManager.weapons)).Length];
        StartCoroutine(itemCheckSet());

    }
    //first check for the status of items in the game
    public IEnumerator itemCheckSet()
    {
        string[] itemNames;
        int iMax;
        string fn;
        if (gs == 'w')
        {
            fn = "weapons/";
            iMax = Enum.GetValues(typeof(GameManager.weapons)).Length;
            itemNames = new string[iMax];
            for (int o = 0; o < iMax; o++) itemNames[o] = Enum.GetValues(typeof(GameManager.weapons)).GetValue(o).ToString();
        }
        else
        {
            fn = "avatars/";
            iMax = Enum.GetValues(typeof(GameManager.avatars)).Length;
            itemNames = new string[iMax];
            for (int o = 0; o < iMax; o++) itemNames[o] = Enum.GetValues(typeof(GameManager.avatars)).GetValue(o).ToString();
        }
        allItems = new GameObject[iMax];
        //sceneLoaded = true;
        //StartCoroutine(deductSynchCount(true));
        //wait unitil the saved file is loaded
        yield return new WaitUntil(() => GameManager.gamePlayer!=null && GameManager.gameChosen != null && GameManager.client!=null);
        for (int i = 0; i < iMax; i++)
        {
            try
            {
                GameObject go = Instantiate(Resources.Load(fn + itemNames[i], typeof(GameObject))) as GameObject;
                go.transform.rotation = new Quaternion(0, 180, 0, 0);
                if (go.name.Contains("avatar")) Destroy(go.GetComponent<Animator>());//animator stops the scaling of charater
                go.transform.localScale = smallSize;
                //to get rid of the '(clone)' in name, which is 7 characters
                go.name = go.name.Substring(0, go.name.Length - 7);
                go.transform.parent = gameObject.transform;
                go.SetActive(false);
                allItems[i] = go;
            } catch (Exception e)
            {
                print("Cant spawn item: " + fn + itemNames[i]);
                print("Reason is: " + e.Message);

            }
            yield return null;
            //this is to check if the item is purchased
            chosenItem = allItems[i].GetComponent<infoItem>();
            //if the key exists, then the item is saved
            if (!chosenItem.isPurchased)
            {
                //-1 MEANS NOT BOUGHT, 0 MEANS BOUGHT, 1 means permenantly bought
                //NOTE: -1,0 and 1 no longer used since using data files
                chosenItem.isPurchased = GameManager.gameItems.itemNames.Contains(allItems[i].name);// num > -1;
                //setting if it was permenantly bought
                if (chosenItem.isPurchased && chosenItem.permanent) chosenItem.isPermanent = GameManager.gameItems.itemPerms[GameManager.gameItems.itemNames.IndexOf(allItems[i].name)];//num;
            }
            //if item is currently chosen
            if (allItems[i].name.Contains("weapon") && allItems[i].name == GameManager.gameChosen.chosenWeapon) index = i;
            else if (allItems[i].name.Contains("avatar") && allItems[i].name == GameManager.gameChosen.chosenAvatar) index = i;

            string iSaved = allItems[i].name;
            //if the item is currently purchased by the player
            // if time is over for item
            if (iSaved != GameManager.defWeapon && iSaved != GameManager.defAvatar && chosenItem.isPurchased && !chosenItem.isPermanent)
            {
                timeStarted = DateTime.Parse(GameManager.gameItems.itemTimes[GameManager.gameItems.itemNames.IndexOf(chosenItem.gameObject.name)]);
                timeUpCheck();
            }
            //if the player key exists and the item is not synched but is purchased
            if (GameManager.gamePlayer.id!="" && GameManager.gamePlayer.id!=null)synchedCheck(i);
            //this is to check is the weapons are dual or not, makes it rotate and makes it inactive
            addCenter(i);
            allItems[i].SetActive(false);
        }
        sceneLoaded = true;
        if (!isSynching && synchCount <=0)StartCoroutine(deductSynchCount(true));
    }
    //check to synch, and is called from the start() method ALONE
    private void synchedCheck(int i)
    {
        bool sync = GameManager.gameItems.itemNames.Contains(allItems[i].name);
        bool synch2 = true;
        if (sync)
        {
            synch2 = GameManager.gameItems.itemSynched[GameManager.gameItems.itemNames.IndexOf(allItems[i].name)];
        }
        //player is not created or the item is not synched as yet
        if (synch2) return;
        if (!isSynching) isSynching = true;
        synchCount += 1;
        print("synch count appended: " + synchCount);
        StartCoroutine(synchItem(i, true, true));

    }
    //to indicate if is synching before the item choosing screen is active
    bool isSynching = false;
    int synchCount = 0;
    //Coroutine synchingCo;
    IEnumerator synchItem(int i, bool findTime, bool iandt)
    {
        if (!GameManager.sceneLoaded)yield return new WaitUntil(() => GameManager.sceneLoaded);

        string pid = GameManager.gamePlayer.id;
        if (pid != null && pid != "")
        {
            
            playerItem pi = new playerItem
            {
                playerid = pid,
                itemid = allItems[i].name,
                boughtAt = DateTime.UtcNow.ToString(),
                perm = GameManager.gameItems.itemPerms[GameManager.gameItems.itemNames.IndexOf(allItems[i].name)],//PlayerPrefs.GetInt(chosenItem.gameObject.name,-1) == 1,
                ifNew = iandt//true if adding to player into and appending the count, false if just appending count
            };
            //if synching a time that was already saved
            if (findTime)
            {
                DateTime curtime = DateTime.Parse(GameManager.gameItems.itemTimes[GameManager.gameItems.itemNames.IndexOf(allItems[i].name)]);
                pi.boughtAt = curtime.ToString();
            }
            //gets how much to add
            //pi.count =PlayerPrefs.GetInt(chosenItem.gameObject.name + itemsSynchedKey, 1);
            pi.count = GameManager.gameItems.itemSynchCount[GameManager.gameItems.itemNames.IndexOf(allItems[i].name)];
            //waiting for two seconds to make sure connection is made (conMade)
            if (isSynching) yield return new WaitForSeconds(2);

            if (GameManager.conMade)
            {
                Coroutine s = StartCoroutine(GameManager.client.InvokeApi<playerItem, Message>("appendItem", Method.POST, pi, OnCustomApiCompleted));
                //Invoke("timeUp", 5);

                itemsSynching.Add(new customCoroutine(s, null));

                Coroutine t = StartCoroutine(timeUp(s,itemsSynching.Count-1));

                itemsSynching[itemsSynching.Count - 1].waitRoutine = t;


                StartCoroutine(waitingForTimeUp(itemsSynching.Count - 1));
            }
            else if (isSynching) StartCoroutine(deductSynchCount(false));

            else if (!isSynching) finishBuyingAnimations();
        }
        else if (GameManager.sceneLoaded)
        {
            finishBuyingAnimations();
        }
        yield return null;
    }

    IEnumerator waitingForTimeUp(int cci)
    {
        yield return new WaitForSeconds(5);
        if (itemsSynching[cci].isRunning)
        {
            StopCoroutine(itemsSynching[cci].syncRoutine);
            StopCoroutine(itemsSynching[cci].waitRoutine);
            //print("WaitingForTimeUp executed here");
            if (isSynching) StartCoroutine(deductSynchCount(false));
            else if (!isSynching) finishBuyingAnimations();
        }
    }
    List<customCoroutine> itemsSynching = new List<customCoroutine>();
    IEnumerator timeUp(Coroutine s, int cci)
    {
        yield return s;
        itemsSynching[cci].isRunning = false;
        //print("timeUp executed here");
        if (isSynching) StartCoroutine(deductSynchCount(false));
        else if (!isSynching) finishBuyingAnimations();
    }

    IEnumerator deductSynchCount(bool b)
    {
        if (synchCount > 0 && !b)
        {
            synchCount -= 1;
            print("synch count deducted: " + synchCount);
        }
        if (synchCount <= 0)
        {
            isSynching = false;
            yield return new WaitUntil(() => GameManager.sceneLoaded && sceneLoaded);
			GameManager.gm.checkLoad();
        }
		yield return null;
    }
    //when items has synched with the server
    private void OnCustomApiCompleted(IRestResponse<Message> response)
    {
        //synchingCo = null;
        //CancelInvoke("timeUp");
        if (!response.IsError)
        {
            //if (IsInvoking("cancelApi")) CancelInvoke ("cancelApi");
            if (isSynching) StartCoroutine(deductSynchCount(false));
            Debug.Log("On Custom Api Completed data: " + response.Content);
            //message returned is string of weapon
            Message message = response.Data;
            //Debug.Log("Result: " + message.message);
            //gets the weapon/avatar's name from the returned string
            string wan = message.message.Substring(0, message.message.Length - 6);
            //if synching saved items THUS must have key 
            //if (PlayerPrefs.HasKey(wan + itemsSynchedKey))PlayerPrefs.DeleteKey(wan + itemsSynchedKey);
            GameManager.gameItems.itemSynched[GameManager.gameItems.itemNames.IndexOf(wan)] = true;
            dataControl.saveItems(GameManager.gameItems);
        }
        else
        {
            Debug.Log("Api Error Status:" + response.StatusCode + " Url: " + response.Url);
        }
        //sCount = 0;
        //print("on custom api completed");
        finishBuyingAnimations();
    }

    private void finishBuyingAnimations()
    {
        /*if (loadingNow) */GameManager.gm.toggleLoading(false); //Destroy(loadingNow);
        mainPanelContents.SetActive(true);

        if (isFirstSynch)
        {
            resetTypeDisplay(true);
            //if (chosenItem.gameObject.name.Contains("weapon")) setItemTypeDisplay('w');
            //else setItemTypeDisplay('a');

            Instantiate(boughtAnimation);
            AudioManager.am.playSound("bought");
        }
        //if (!isSynching)Instantiate(boughtAnimation);

    }
    //used to distinguesh between synching at start of scene and when player first buys an item in scene
    bool isFirstSynch = false;
    //CHANGE TO 4 HOURS WHEN IN FINAL PRODUCTION 
    public static readonly TimeSpan itemTimeCap = new TimeSpan(0, 4, 0, 0, 0);
    bool showInfo = false;
    float swipePos = 0f;
    void Update()
    {
        if (activeCheck()) return;

        if (sceneLoaded && chosenItem.isPurchased && !chosenItem.isPermanent)
        {
            TimeSpan wRemain = itemTimeCap - (DateTime.UtcNow - timeStarted);
            i_time.text = "" + wRemain.Hours + ":" + wRemain.Minutes + ":" + wRemain.Seconds;
            timeUpCheck();
        }
    }
    public void showTypeInfo(typeInfo ti)
    {
        if (activeCheck()|| showInfo || showCoins) return;
        print("show type now");
        resetTypeDisplay(false);//turns off display of types
        typePanel.SetActive(true);
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(defTypeButton);
#endif
        mainPanel.SetActive(false);
        showInfo = true;
        typeTitle.text = ti.typeTitle;
        typeDesc.text = ti.typeDesc;
        typeAni.SetTrigger(ti.typeAni);//sets the type animation eg. dual, more coins
    }
    

    public void closeInfoPanel()
    {
        if (activeCheck()) return;
        //Animator a = GameManager.gm.itemContainer.GetComponent<Animator>();
        //a.SetFloat("direct", -1);
        //a.SetTrigger("info");
        typePanel.SetActive(false);
        mainPanel.SetActive(true);
#if UNITY_WSA
        if(GameManager.ifJoyStick)itemBuyAffordUnlockable(true);
#endif
        //turns on display of types 
        resetTypeDisplay(true);
        //if (chosenItem.gameObject.name.Contains("weapon")) setItemTypeDisplay('w');
        //else setItemTypeDisplay('a');
        //mainPanel.SetActive(true);
        showInfo = false;
    }

    
    //if the time for the item to be unlocked is up
    void timeUpCheck()
    {
        TimeSpan wRemain = DateTime.UtcNow - timeStarted;
        //TO CHANGE TO HOURS WHEN IN FINAL PRODUCTION
        if (wRemain >= itemTimeCap)
        {
            i_time.text = "";
            //PlayerPrefs.DeleteKey(chosenItem.gameObject.name);
            //PlayerPrefs.DeleteKey(chosenItem.gameObject.name + startTimeKey);
            int ci = GameManager.gameItems.itemNames.IndexOf(chosenItem.gameObject.name);
            if (GameManager.gameItems.itemSynched[ci]) deleteItem(ci);
            //resetItem();
            chosenItem.isPurchased = false;
            itemPurchasedButtonNotUsable(true);
        }
    }
    public static void deleteItem(int index)
    {
        GameManager.gameItems.itemNames.RemoveAt(index);
        GameManager.gameItems.itemTimes.RemoveAt(index);
        GameManager.gameItems.itemPerms.RemoveAt(index);
        GameManager.gameItems.itemSynched.RemoveAt(index);
        GameManager.gameItems.itemSynchCount.RemoveAt(index);
        dataControl.saveItems(GameManager.gameItems);
        //print("Item Names         : " + GameManager.gameItems.itemNames.Count);
        //print("Item Times         : " + GameManager.gameItems.itemTimes.Count);
        //print("Item ItemSynched   : " + GameManager.gameItems.itemSynched.Count);
        //print("Item ItemPerms     : " + GameManager.gameItems.itemPerms.Count);
        //print("Item ItemSynchCount: " + GameManager.gameItems.itemSynchCount.Count);
    }
    public static void addItem(string newName,string temptime, bool perm, bool synched)
    {
		//if no record then create the new record
        if (!GameManager.gameItems.itemNames.Contains(newName))
        {
            GameManager.gameItems.itemNames.Add(newName);
            GameManager.gameItems.itemTimes.Add(temptime.ToString());
            GameManager.gameItems.itemSynched.Add(synched);
            GameManager.gameItems.itemPerms.Add(perm);
            GameManager.gameItems.itemSynchCount.Add(1);
        }
		//if it already contains a record of that name
        else
        {
            int i = GameManager.gameItems.itemNames.IndexOf(newName);
            GameManager.gameItems.itemTimes[i] = temptime.ToString();
            //if the item bought isnt permenant
            if (!GameManager.gameItems.itemPerms[i]) GameManager.gameItems.itemPerms[i] = perm;
            //if synched then setting it back to one
            if (GameManager.gameItems.itemSynched[i]) GameManager.gameItems.itemSynchCount[i] = 1;
            //else 1 will be added to next synch
            else GameManager.gameItems.itemSynchCount[i] += 1;
            GameManager.gameItems.itemSynched[i] = false;
        }
        dataControl.saveItems(GameManager.gameItems);

    }
    //moves non dual weapons to look more visually pleasing when rotatiing
    void addCenter(int i)
    {
        //to avoid error if dealing with avatars
        if (allItems[i].transform.childCount > 0)
        {
            Vector3 ip = allItems[i].transform.GetChild(0).gameObject.transform.position;
            if (allItems[i].transform.childCount == 1)
            {
                allItems[i].transform.GetChild(0).gameObject.transform.position = new Vector3(0, ip.y, -7);
            }
        }
        //allItems[i].AddComponent<Rotate>().speed = rs;


    }
    readonly Vector3 smallSize = new Vector3(.4f, .4f, .4f);
    void turnOffItems(bool ifAll)
    {
        allItems[index].transform.localScale = smallSize;
        //print("suppose to be making smaller in size");
        setIndexes();

        //setting center, right and left items off
        if (ifAll)
        {
            allItems[index].SetActive(false);
            allItems[indexR].SetActive(false);
            allItems[indexL].SetActive(false);
            allItems[indexR2].SetActive(false);
            allItems[indexL2].SetActive(false);
        }
        else
        {
            allItems[index].transform.localPosition = centerPos;
            allItems[indexR].transform.localPosition = rightPos;
            allItems[indexL].transform.localPosition = leftPos;
            allItems[indexR2].transform.localPosition = rightPos2;
            allItems[indexL2].transform.localPosition = leftPos2;

            allItems[indexR2].SetActive(false);
            allItems[indexL2].SetActive(false);

        }
        Destroy(allItems[index].GetComponent<Rotate>());
    }
    Coroutine changingItem;
    public IEnumerator setViewedItem(/*bool onOff,*/ bool ifAll, bool right, bool setDefButton = false)
    {
        setIndexes();
        allItems[index].transform.localScale = new Vector3(1, 1, 1);

        //if off then others are off as well and all must be turned on 
        if (ifAll)
        {
            allItems[index].SetActive(/*onOff*/true);
            allItems[indexR].SetActive(/*onOff*/true);
            allItems[indexL].SetActive(/*onOff*/true);
            allItems[indexR2].SetActive(/*onOff*/true);
            allItems[indexL2].SetActive(/*onOff*/true);

            allItems[index].transform.localPosition = centerPos;
            allItems[indexR].transform.localPosition = rightPos;
            allItems[indexL].transform.localPosition = leftPos;
            allItems[indexR2].transform.localPosition = rightPos2;
            allItems[indexL2].transform.localPosition = leftPos2;
        }
        else
        {

            if (right)

            {
                allItems[indexR].SetActive(true);
                allItems[indexR].transform.localPosition = rightPos2;
            }
            else
            {
                allItems[indexL].SetActive(true);
                allItems[indexL].transform.localPosition = leftPos2;
            }

            Transform t = allItems[index].transform;
            Transform rt = allItems[indexR].transform;
            Transform lt = allItems[indexL].transform;
            Transform rt2 = allItems[indexR2].transform;
            Transform lt2 = allItems[indexL2].transform;
            float speed = .1f;
            do
            {

                t.localPosition = Vector3.MoveTowards(t.localPosition, centerPos, speed);
                rt.localPosition = Vector3.MoveTowards(rt.localPosition, rightPos, speed);
                lt.localPosition = Vector3.MoveTowards(lt.localPosition, leftPos, speed);
                rt2.localPosition = Vector3.MoveTowards(rt2.localPosition, rightPos2, speed);
                lt2.localPosition = Vector3.MoveTowards(lt2.localPosition, leftPos2, speed);
                yield return null;
            }
            while (t.localPosition != centerPos);
        }
        if (i_time.text != "") i_time.text = "";
        chosenItem = allItems[index].GetComponent<infoItem>();
        i_name.text = chosenItem.iName;
        i_desc.text = chosenItem.iDesc;
        //if not default items
        if (chosenItem.isPurchased && !chosenItem.isPermanent)
        {
            //string unlocked = PlayerPrefs.GetString(allItems[index].name + startTimeKey, "none");
            string unlocked = GameManager.gameItems.itemTimes[GameManager.gameItems.itemNames.IndexOf(allItems[index].name)];
            if (unlocked != "none" && unlocked != "") timeStarted = DateTime.Parse(unlocked);
        }
        //check if item is not bought yet
        itemBuyAffordUnlockable(setDefButton);
        allItems[index].AddComponent<Rotate>().speed = rs;
        if (chosenItem.gameObject.name.Contains("weapon")) setItemTypeDisplay('w');
        else setItemTypeDisplay('a');
        //}
        changingItem = null;
    }
    //setting the types that the weapon has (automatic, power, spread/spray, dual)
    //alo setting the types of avatars that exist (life,powerup,bomb,coins,missile)
    public void resetTypeDisplay(bool onOff)
    {
        power.transform.parent.gameObject.SetActive(onOff);
        //power.SetActive(false);
        //auto.SetActive(false);
        //spread.SetActive(false);
        //dual.SetActive(false);

        //life.SetActive(false);
        //powerUp.SetActive(false);
        //bomb.SetActive(false);
        //coin.SetActive(false);
        //missile.SetActive(false);
    }
    void setItemTypeDisplay(char it)
    {
        power.SetActive(false);
        auto.SetActive(false);
        spread.SetActive(false);
        dual.SetActive(false);

        life.SetActive(false);
        powerUp.SetActive(false);
        bomb.SetActive(false);
        coin.SetActive(false);
        missile.SetActive(false);

        List<GameObject> t = new List<GameObject>();
        if (it == 'w')
        {

            //int count = 0;
            //List<GameObject> t = new List<GameObject>();
            if (((infoWeapon)chosenItem).isDamage) t.Add(power);
            if (((infoWeapon)chosenItem).isAuto) t.Add(auto);
            if (((infoWeapon)chosenItem).isDual) t.Add(dual);
            if (((infoWeapon)chosenItem).isSpray) t.Add(spread);
        }
        else
        {


            //int count = 0;
            //List<GameObject> t = new List<GameObject>();
            if (((infoAvatar)chosenItem).moreLife) t.Add(life);
            if (((infoAvatar)chosenItem).morePowerUps) t.Add(powerUp);
            if (((infoAvatar)chosenItem).moreCoins) t.Add(coin);
            if (((infoAvatar)chosenItem).lessBombs) t.Add(bomb);
            if (((infoAvatar)chosenItem).lessSuicide) t.Add(missile);
        }
        //foreach (GameObject go in types)
        for (int i = 0; i < t.Count; i++)
        {
            //go.SetActive(true);
            t[i].SetActive(true);

            if (t.Count == 1 || t.Count == 3|| t.Count ==5)
            {
                if (i == 0) t[i].transform.position = new Vector3(0f, t[i].transform.position.y, t[i].transform.position.z);
                else if (i == 1) t[i].transform.position = new Vector3(-.5f, t[i].transform.position.y, t[i].transform.position.z);
                else if (i == 2) t[i].transform.position = new Vector3(.5f, t[i].transform.position.y, t[i].transform.position.z);
                else if (i == 3) t[i].transform.position = new Vector3(-1f, t[i].transform.position.y, t[i].transform.position.z);
                else if (i == 4) t[i].transform.position = new Vector3(1f, t[i].transform.position.y, t[i].transform.position.z);

            }
            else if (t.Count == 2 || t.Count == 4)
            {
                if (i == 0) t[i].transform.position = new Vector3(-.25f, t[i].transform.position.y, t[i].transform.position.z);
                else if (i == 1) t[i].transform.position = new Vector3(.25f, t[i].transform.position.y, t[i].transform.position.z);
                else if (i == 2) t[i].transform.position = new Vector3(-.75f, t[i].transform.position.y, t[i].transform.position.z);
                else if (i == 3) t[i].transform.position = new Vector3(.75f, t[i].transform.position.y, t[i].transform.position.z);
            }
        }
    }

    //checks if the item is bought or not/affortable
    private void itemBuyAffordUnlockable(bool setDefButton)
    {
        if (!chosenItem.isPurchased)
            itemPurchasedButtonNotUsable(setDefButton);

        else itemPurchasedButtonUsable(setDefButton);
    }

    private void itemPurchasedButtonNotUsable(bool setDefButton)
    {
        int cc = GameManager.gamePlayer.coins;//PlayerPrefs.GetInt(GameManager.playerCoinsKey, 0);
        int r = chosenItem.calRent();

        permanentCheck(cc);
        //setting the rent button
        if (r > cc) rentBuyButton.interactable = false;
        else rentBuyButton.interactable = true;
        //setting the ad button
        if (chosenItem.unlockableWithAd) setAdButton(true);//watchAdButton.interactable = true;
        else setAdButton(false); //watchAdButton.interactable = false;
#if UNITY_WSA
        if (GameManager.ifJoyStick && setDefButton)
        {
            //setting the preseleted button
            if (watchAdButton.interactable) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(watchAdButton.gameObject);
            else if (rentBuyButton.interactable) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(rentBuyButton.gameObject);
        }
#endif
        //setting the prices' info display
        i_price.text = "" + r;
    }
    //does the check for the permanent buy button
    void permanentCheck(int cc)
    {
        int p = chosenItem.calCost();
        //setting the permenant button
        if (chosenItem.permanent)
        {
            //print("item is permanent");
            if (chosenItem.isPermanent)
            {
                //print("item is permanently bought");
                permanentBuyButton.interactable = false;
                i_pPrice.text = "✔";
            }
            else
            {
                //print("item is not permanently bought");
                if (p > cc || chosenItem.isPurchased) permanentBuyButton.interactable = false;
                else permanentBuyButton.interactable = true;
                i_pPrice.text = "" + p;
            }
        }
        else
        {
            //print("item is not permanent");
            permanentBuyButton.interactable = false;
            i_pPrice.text = "✖";
        }
    }
    //this function is in seperate method since both switching between items and purchasing them uses the same function
    //NOTE: when game auto goes back to home/game scene, move code in this method back to setItemViewed() 
    private void itemPurchasedButtonUsable(bool setDefButton) {
        permanentCheck(GameManager.gamePlayer.coins);
        //permanentBuyButton.interactable = false;
        setAdButton(false); //watchAdButton.interactable = false;
        rentBuyButton.interactable = true;

#if UNITY_WSA
        if (GameManager.ifJoyStick && setDefButton)
            UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(rentBuyButton.gameObject);
#endif
        i_price.text = "✔";
    }

    public void leftRightButtonPushed(bool b)
    {
        if (activeCheck()) return;

        if (changingItem != null) return;
        //print("SUPPOSE TO MOVE NOW");

        turnOffItems(false);
        Vector3 oldPos =  leftRightAni.transform.localPosition;
        Vector3 eulerAng = leftRightAni.transform.localEulerAngles;
        if (b) { index++; oldPos.x = GameManager.gm.MaxRange.x; eulerAng.y = -90;}
        else { index--; oldPos.x = GameManager.gm.MinRange.x; eulerAng.y = 90;}
        leftRightAni.transform.localPosition = oldPos;
        leftRightAni.transform.localEulerAngles = eulerAng;
        if (index < 0) index = allItems.Length - 1;
        else if (index >= allItems.Length) index = 0;
        leftRightAni.SetActive(true);
        /*if (changingItem == null)*/
        changingItem = StartCoroutine(setViewedItem(false, b));

        AudioManager.am.playSound("nextItem");
        //TAKE THIS OUT IN FINAL PRODUCTION
        //if ((allItems[index].name == "weapon_dev_defence" || allItems[index].name == "avatar_SWAT") && !unlocked) rightButtonPushed();
    }

    void setIndexes()
    {
        indexR = index + 1;
        indexL = index - 1;
        indexR2 = indexR + 1;
        indexL2 = indexL -1;

        if (indexR < 0) indexR = allItems.Length + indexR;
        else if (indexR >= allItems.Length) indexR = indexR - allItems.Length;

        if (indexL < 0) indexL = allItems.Length + indexL;
        else if (indexL >= allItems.Length) indexL = indexL - allItems.Length;

        if (indexR2 < 0) indexR2 = allItems.Length + indexR2;
        else if (indexR2 >= allItems.Length) indexR2 = indexR2 - allItems.Length;

        if (indexL2 < 0) indexL2 = allItems.Length + indexL2;
        else if (indexL2 >= allItems.Length) indexL2 = indexL2 - allItems.Length;

    }

    bool activeCheck()
    {
        return !GameManager.gm ||( GameManager.gm.gameState == GameManager.gameStates.PrePlay || 
            (GameManager.gm.gameState == GameManager.gameStates.avatarMenu && gs == 'w' ||
                GameManager.gm.gameState == GameManager.gameStates.weaponMenu && gs == 'a'));
    }


    public void buyEquip(bool p)
    {
        if (activeCheck()) return;

        if (!chosenItem.isPurchased)
        {
            int coinNum = GameManager.gamePlayer.coins;
            int r = chosenItem.calRent();
            int co = chosenItem.calCost();
            if (!p && coinNum >= r) coinNum -= r;               
            else if (p && coinNum >= co) coinNum -= co;
            GameManager.gamePlayer.coins = coinNum;
            dataControl.savePlayer(GameManager.gamePlayer);
            PlayerPrefs.SetInt(GameManager.playerCoinsUnsynchedKey, 0);
            GameManager.gm.coinDisplay.text = "" + coinNum;
            //setting item purchased
            //print("buy equip item not purchased");
            setPurchasedItem(p);

        }
        //if weapon already purchased
        else if (chosenItem.isPurchased)
        {
            //print("buy equip item is purchased");
            //char c;
            if (allItems[index].name.Contains("weapon"))
                GameManager.gameChosen.chosenWeapon = allItems[index].name;

            else GameManager.gameChosen.chosenAvatar = allItems[index].name;

            dataControl.saveChosen(GameManager.gameChosen);

            backToMenu();

        }
    }
    //goes back to main menu tp start playing
    public void backToMenu()
    {
        if (activeCheck()) return;
        turnOffItems(true);
        resetTypeDisplay(false);

        //GameManager.gm.gameState = GameManager.gameStates.PrePlay;
        GameManager.gm.setPlayerAndWeapon();
        GameManager.gm.setHighCoins();

        //GameManager.gm.gameContainer.SetActive(true);
        Animator a = GameManager.gm.itemContainer.GetComponent<Animator>();
        a.SetFloat("direct", -1);
        a.SetTrigger("items");

        //animation to move camera back to game
        Animator ca = Camera.main.gameObject.GetComponent<Animator>();
        ca.SetFloat("direct", -1);
        ca.SetTrigger("toItems");

        //animation to move item choosing meny back to main game
        //Animator ani = GameManager.gm.gameContainer.GetComponent<Animator>();
        /*ani*/GameManager.gm.prePlayController.prePlayAnimator.SetFloat("direct", 1);
        /*ani*/GameManager.gm.prePlayController.prePlayAnimator.SetTrigger("enter");

        GameManager.gm.loadingLogo.SetFloat("direct", -1f);
        GameManager.gm.loadingLogo.SetTrigger("move");

        //ani.Play("enterButtons");
        if (GameManager.gm.currentMission && GameManager.gm.gameMissionControl)
            GameManager.gm.gameMissionControl.toggleMissionVisibility(true);
        Invoke("enableCam", .75f);
    }
    void enableCam()
    {
        GameManager.gm.gameState = GameManager.gameStates.PrePlay;
        GameManager.gm.setCamManualMove(true);
    }
    //method to accomodate when item is purchased with coins, or with Ad
    void setAdButton(bool b)
    {
        watchAdButton.interactable = b;

    }
    //p stands for permenant
    public void setPurchasedItem(bool p)
    {
		//in the event that the player watched an ad
		//AudioManager.am.togglePauseMusic(false);
		if(playingAD)playingAD = false;
		
        chosenItem.isPurchased = true;
        setAdButton(false);
        DateTime temptime = new DateTime();
        if (!p)
        {
            temptime = DateTime.UtcNow;
            timeStarted = temptime;
        }
        else
        {
            if (chosenItem.permanent) chosenItem.isPermanent = p;
        }
        addItem(chosenItem.gameObject.name,temptime.ToString(),p, false);
        print("Item Names         : " + GameManager.gameItems.itemNames.Count);
        print("Item Times         : " + GameManager.gameItems.itemTimes.Count);
        print("Item ItemSynched   : " + GameManager.gameItems.itemSynched.Count);
        print("Item ItemPerms     : " + GameManager.gameItems.itemPerms.Count);
        print("Item ItemSynchCount: " + GameManager.gameItems.itemSynchCount.Count);

        //Debug.Log("name:" + chosenItem.gameObject.name);
        itemPurchasedButtonUsable(true);
        //sets the item purchased

		GameManager.gm.toggleLoading(true,true);
		
        mainPanelContents.SetActive(false);
        resetTypeDisplay(false);//turns off display of types
        //synching if player is created
        isFirstSynch = true;
        //if (isFirstSynch)
        //adds more to the count if a count already exists, for first attempt of synch for the scene
        //PlayerPrefs.SetInt(chosenItem.gameObject.name + itemsSynchedKey,
        //    PlayerPrefs.GetInt(chosenItem.gameObject.name + itemsSynchedKey, 0) + 1);
        StartCoroutine(synchItem(index,false,true));
    }

    public void viewAd()
    {
        if (activeCheck()) return;
        GameManager.gm.toggleLoading(true, true);
        mainPanelContents.SetActive(false);
        resetTypeDisplay(false);//turns off display of types
        //Debug.Log("ad is to be viewed here");
        //adControl ac = new adControl(/*adControl.rewardVid*/adControl.vidType.must,false, this/*, false*/);
		adsControl ac;
        if (GameManager.gm.ad != null)
		{
			ac = GameManager.gm.ad;
			ac.loadScene = false;
            ac.rewardItems = this;
		}
		else
		{
			ac = gameObject.AddComponent<adsControl>();
			ac.adControlStart(adsControl.vidType.must, false, this);
        }
		StartCoroutine(waitForAd(ac));
    }

	IEnumerator waitForAd(adsControl ac)
	{
		float t = Time.time;
		//bool ready = false;
        yield return StartCoroutine(ac.longRewardCheck());
        if (ac.videoReady) 
		{
			//AudioManager.am.togglePauseMusic(true);
			playingAD = true;
			ac.rewardAdNow();
        }
		//(if UWP)returns  game manager's ad back to normal in calse ad is eventually ready when the player plays and dies
		else if(GameManager.gm.ad)
		{
			ac.loadScene = true;
            ac.rewardItems = null;
			adViewFail();
		}
		else 
		{
			if (ac!=null)Destroy(ac);
			adViewFail();
		}
		//while ((Time.time - t)<5 && !ready)
		//{
		//	if(ac.rewardCheck())
		//	{
		//		ready = true; 
		//		ac.rewardShow();
		//	}
		//	yield return null;
		//}
		
		//if (!ready) adViewFail();
	}
    public void adViewFail()
    {
		//AudioManager.am.togglePauseMusic(false);
		playingAD = false;
        GameManager.gm.toggleLoading(false);
        mainPanelContents.SetActive(true);
        resetTypeDisplay(true);
        //if (chosenItem.gameObject.name.Contains("weapon")) setItemTypeDisplay('w');
        //else setItemTypeDisplay('a');
        Debug.Log("unlocking item failed, ad wasn't viewed");
        GameManager.gm.timedMsg("Ad couldn't be viewed, try again later");
    }
    
    bool showCoins = false;
    public void openOptionPanel()
    {
        if (activeCheck()) return;
        showCoins = true;
        mainPanel.SetActive(false);
        //Animator a = GameManager.gm.itemContainer.GetComponent<Animator>();
        //a.SetFloat("direct", 1);
        //a.SetTrigger("coins");
        resetTypeDisplay(false);//turns off display of types
        CoinSelectionPanel.SetActive(true);
#if UNITY_WSA
        if (GameManager.ifJoyStick)UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(defCoinButton);
#endif
    }

    public void closeOptionPanel()
    {
        if (activeCheck()) return;
        //CoinSelectionPanel.SetActive(false);
        //Animator a = GameManager.gm.itemContainer.GetComponent<Animator>();
        //a.SetFloat("direct", -1);
        //a.SetTrigger("coins");
        resetTypeDisplay(true);//turns off display of types
        CoinSelectionPanel.SetActive(false);
        mainPanel.SetActive(true);
#if UNITY_WSA
        if (GameManager.ifJoyStick) itemBuyAffordUnlockable(true);
#endif
        showCoins = false;

    }

    //when option to purchase coins is chosen
    public void optionChosen1(Transform spawnPos)
    {
        if (activeCheck()) return;
        StartCoroutine(processingPurchase(1, spawnPos.position));
    }
    public void optionChosen2(Transform spawnPos)
    {
        if (activeCheck()) return;
        StartCoroutine(processingPurchase(2, spawnPos.position));
    }
    public void optionChosen3(Transform spawnPos)
    {
        if (activeCheck()) return;
        StartCoroutine(processingPurchase(3, spawnPos.position));
    }
    public void optionChosen4(Transform spawnPos)
    {
        if (activeCheck()) return;
        StartCoroutine(processingPurchase(4, spawnPos.position));
    }

    IEnumerator processingPurchase(int optionNo, Vector3 sp)
    {
        GameManager.gm.toggleLoading(true, true);
        CoinSelectionPanel.SetActive(false);
        IAPParent.instance.BuyGold(optionNo,sp);
        yield return new WaitWhile (()=> IAPParent.processing);
        closeOptionPanel();
        //here to check if item is affordable after coins bought/not bought
        itemBuyAffordUnlockable(true);
        GameManager.gm.toggleLoading(false, true);

    }

}
