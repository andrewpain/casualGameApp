﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
//using System;
//using Microsoft.Windo
//TO DO: HAVE RANGES FOR DAY AND NIGHT SET, SO THAT MAIN DIRECTIONAL LIGHT CAN BE TURNED OFF WHEN IT'S NIGHT
//USE MATHF.CLAMP
public class Spawner : MonoBehaviour
{
    // public variables where the objects would spawn in world
    //public float secondsBetweenSpawning = 0.1f;
    //private float nextSpawnTime;


    //what prefabs to spawn
    public GameObject[] easyEnemies; //public movement[] easyDirections;
    public GameObject[] mediumEnemies;
    public GameObject[] suicideEnemies;
    public GameObject[] bossEnemies;
    public GameObject gift;
    public GameObject coinParticle;//coin aure that is emitted by enemy if carrying coin
    public GameObject coinCollected;//coin particle effect when player shoots said enemy
    public GameObject bomb;//bomb with takes player's life points



    //how many enemies at a time to appear as game progresses
    private int enemiesShown = 1;
    //cap to indicate when to raise the enemiesShown variable
    private int hitsTillRaise;
    //[HideInInspector]
    private const int startHitCap = 20;
    //[HideInInspector]
    private int countHitsTillRaise = 0, missesInRow =0;
    [HideInInspector]
    public int wave = 1, waveHits = 0;
    [HideInInspector]
    public bool bombUsed = false, giftUsed = false, suicideUsed = false, coinUsed = false;
    [HideInInspector]
    int bombCount = 0, giftCount = 0, suicideCount = 0, easyCount = 0, mediumCount = 0, coinCount = 0;
    //[HideInInspector]
    public int enemiesPerBomb, enemiesPerGift, enemiesPerSuicide, enemiesPerCoin;
    [HideInInspector]
    //if there is currently a bomb / gift on screen
    public bool bombCurrent = false, giftCurrent = false;
    //this is so that player doesnt somehow shoot enemy even though player wasnt aiming at it/them
    //private readonly Vector3 defLocation = new Vector3(0, 8, GameManager.gm.MaxRange.z);
    // Use this for initialization
    void Start ()
	{
        levelBanner.GetComponent<Canvas>().worldCamera = Camera.main;
        bossBanner.GetComponent<Canvas>().worldCamera = Camera.main;
        levelText = levelBanner.transform.GetChild(1).gameObject.GetComponent<Text>();
        skyRen/*.material*/.mainTextureOffset = new Vector2(Random.Range(0f,.15f), 0);
        //.mainTextureScale = new Vector2(.5f, 1);
        //float tp = GameManager.gm.totalprogress;
        //enemiesPerBomb = 10;//(int)(tp / 16);//10 if tp is 160
        //enemiesPerGift = 40;//(int)(tp / 8);//40
        //enemiesPerSuicide = 40;//(int)(tp / 4);//40
        //enemiesPerCoin = 50;
        hitsTillRaise = startHitCap;
        // determine when to spawn the next object
        //nextSpawnTime = Time.time+secondsBetweenSpawning;
    }
    
    private void FixedUpdate()
    {
        // exit if there is a game manager and the game is over
        if (GameManager.gm && GameManager.gm.gameState != GameManager.gameStates.Playing) return;

        // Spawn the game object through function below
        if (transform.childCount < enemiesShown && GameManager.gm && GameManager.gm.ifSpawnAnything())
            spawnEnemy();
        //spawn the boss
        else if (GameManager.gm && GameManager.gm.bossLoading && transform.childCount == 0)
           if (nBoss==null)nBoss = StartCoroutine(spawnBoss());
    
        

    }
    Coroutine nBoss;
    

    void spawnEnemy()
    {
        //to determine if to add coins to the enemy
        bool timeForCoins = false;
        float type = Random.value;//generates a random value between 0.0 and 1.0 up to SEVEN decimal places
        //Debug.Log("type: " + type);
        //creation of COIN
        if (type < .05f/*.99f*/ && !coinUsed)
        {
            timeForCoins = true;
            coinUsed = true;
        }
        if (coinCount >= enemiesPerCoin)
        {
            coinCount = 0;
            if (!coinUsed)
            {
                //GameObject treasure = Instantiate(coin) as GameObject;
                //moveSpiral(treasure);
                timeForCoins = true;
                //Debug.Log("gift forced");
            }
            else coinUsed = false;
        }
        type = Random.value;

        //creation of GIFT 
        if (type < .05f/*.99f*/ && !giftUsed && !giftCurrent)
        {
            GameObject present = Instantiate(gift) as GameObject;
            moveSpiral(present);
            giftCurrent = giftUsed = true;
        }
        if (giftCount >= enemiesPerGift && !giftCurrent)
        {
            giftCount = 0;
            if (!giftUsed)
            {
                GameObject present = Instantiate(gift) as GameObject;
                moveSpiral(present);
                giftCurrent = true;
                //Debug.Log("gift forced");
            }
            else giftUsed = false;
        }
        type = Random.value;

        //creating the SUICIDE enemy
        if (type < .025f/*.99f*/ && !suicideUsed && GameManager.gm.score>10)
        {
            Instantiate(suicideEnemies[Random.Range(0, suicideEnemies.Length)]);
            //Debug.Log("suicide");
            suicideUsed = true;
        }
        if (suicideCount >= enemiesPerSuicide)
        {
            suicideCount = 0;
            if (!suicideUsed)
            {
                Instantiate(suicideEnemies[Random.Range(0, suicideEnemies.Length)]);
                //Debug.Log("suicide forced");
            }
            else suicideUsed = false;
        }
        type = Random.value;
        //Bomb Just Created
        bool bjc = false;
        //creating the BOMB
        if (type < .1f && !bombUsed && !bombCurrent)
        {
            GameObject badbomb = Instantiate(bomb) as GameObject;
            int waveRange = wave;
            if (waveRange < 3) waveRange = 2;
            //else if (wave == 3) waveRange = 3;
            //else waveRange = 4;
            switch (Random.Range(0,/*2*/waveRange))
            {
                case 0: moveOneaxis(badbomb);break;
                case 1: movebothAxis(badbomb); break;
                case 2: moveBounce(badbomb); break;
                case 3: moveSpiral(badbomb); break;

            }
            badbomb.transform.parent = this.transform;
            bombUsed = true;
            
            bombCurrent = bjc = true;
        }
        if (bombCount >= enemiesPerBomb && !bombCurrent)
        {
            bombCount = 0;
            if (!bombUsed)
            {
                GameObject badbomb = Instantiate(bomb) as GameObject;
                int waveRange = wave;
                if (waveRange < 3) waveRange = 2;
                //else if (wave == 3) waveRange = 3;
                //else waveRange = 4;
                switch (Random.Range(0, waveRange))
                {
                    case 0: moveOneaxis(badbomb); break;
                    case 1: movebothAxis(badbomb); break;
                    case 2: moveBounce(badbomb); break;
                    case 3: moveSpiral(badbomb); break;
                }
                badbomb.transform.parent = this.transform;
                //Debug.Log("bomb forced");
                bombCurrent = bjc = true;
            }
            else bombUsed = false;
        }
        //if bomb wasn't created then create regular enemy
        if (!bjc)
        {
            GameObject[] chosenEnemies = null;
            type = Random.value;
            switch (wave)
            {
                //wave 1
                case 1: chosenEnemies = decideEnemyType(type, 7f, 3f); break;
                //wave 2
                case 2: chosenEnemies = decideEnemyType(type, 5f, 5f); break;
                //wave 3
                case 3: chosenEnemies = decideEnemyType(type, 4f, 6f); break;
                //wave 4                            
                case 4: chosenEnemies = decideEnemyType(type, 3f, 7f); break;

            }

            int i = Random.Range(0, chosenEnemies.Length);
            // actually spawn the game object
            GameObject so = Instantiate(chosenEnemies[i]) as GameObject;
            //so.transform.position = defLocation;
            //if time for coins has reached
            if (timeForCoins)
            {
                GameObject c = Instantiate(coinParticle, so.transform.position, coinParticle.transform.rotation) as GameObject;
                c.transform.parent = so.transform;
                c.transform.SetSiblingIndex(0);//so that the mouth would not be mixed up
                c.transform.localScale = new Vector3(1, 1, 1);
                Health_Enemy he = so.GetComponent<Health_Enemy>();
                he.carryingCoins = true;
                he.coincollect = coinCollected;
            }

            if (chosenEnemies[i].name.EndsWith("oneaxis")) moveOneaxis(so);
            else if (chosenEnemies[i].name.EndsWith("bothaxis")) movebothAxis(so);
            else if (chosenEnemies[i].name.EndsWith("bounce")) moveBounce(so);

            // make the parent the spawner so hierarchy doesn't get super messy
            so.transform.parent = gameObject.transform;
        }
    }
	Coroutine toKill;
	public void addToMiss()
	{
		missesInRow++;
		//print("MISSES COUNT: "+missesInRow);
		if (missesInRow>wave*4 && toKill==null)toKill = StartCoroutine(spawnSuicideToKill());
	}
	IEnumerator spawnSuicideToKill()
	{
		int count=0;
		do
		{
			count++;
			Instantiate(suicideEnemies[Random.Range(0, suicideEnemies.Length)]).GetComponent<Health_Suicide>().isDestroyable=false;
			yield return new WaitForSecondsRealtime(.125f);
			//print("LASER & ROCKET COUNT:"+count);
		}
		while(GameManager.gm.playerHealth.isAlive && count<15);	
		toKill = null;
	}
    private void moveOneaxis(GameObject go)
    {
        int i = Random.Range(0, 4);
        switch (i)
        {
            case 0: go.AddComponent<move_oneaxis_left_right>();break;
            case 1: go.AddComponent<move_oneaxis_right_left>(); break;
            case 2: go.AddComponent<move_oneaxis_up_down>(); break;
            case 3: go.AddComponent<move_oneaxis_down_up>(); break;

        }
    }
    private void movebothAxis(GameObject go)
    {
        int i = Random.Range(0, 4);
        switch (i)
        {
            case 0: go.AddComponent<move_bothaxis_bottomLeft_topRight>(); break;
            case 1: go.AddComponent<move_bothaxis_topLeft_bottomRight>(); break;
            case 2: go.AddComponent<move_bothaxis_topRight_bottomLeft>(); break;
            case 3: go.AddComponent<move_bothaxis_bottomRight_topLeft>(); break;

        }
    }
    private void moveBounce(GameObject go)
    {
        int i = Random.Range(0, 4);
        switch (i)
        {
            case 0: go.AddComponent<move_bounce_downUp>(); break;
            case 1: go.AddComponent<move_bounce_upDown>(); break;
            case 2: go.AddComponent<move_bounce_rightLeft>(); break;
            case 3: go.AddComponent<move_bounce_leftRight>(); break;

        }
    }
    private void moveSpiral(GameObject go)
    {
        int i = Random.Range(0,2);
        switch (i)
        {
            case 0: go.AddComponent<move_spiral_leftRight>(); break;
            case 1: go.AddComponent<move_spiral_rightLeft>(); break;
        }
    }

    public GameObject bossBanner;
    public GameObject levelBanner;
    Text levelText;
    System.Collections.Generic.List<int> usedBosses = new System.Collections.Generic.List<int>();
    public IEnumerator spawnBoss()
    {
        Invoke("showBossBanner",.75f);
        //AudioManager.am.playMusic("6");
        //showBossBanner();
        int i;
        bool b = true;
        //makes sure the the same boss isn't spawned twice       
        do
        {
            i = Random.Range(0, bossEnemies.Length);
            b = usedBosses.Contains(i);
            if (b && usedBosses.Count == bossEnemies.Length) { usedBosses.Clear(); b = false; }
            yield return new WaitForSecondsRealtime(.01f);

        } while (b);
        usedBosses.Add(i);

        AudioManager.am.playSoundAndMusic("bossEnter", "6");
        GameObject spawnedObject = Instantiate(bossEnemies[i]) as GameObject;
        spawnedObject.transform.parent = transform;

        nBoss = null;
    }

    //called when the boss dies
    public void resetEnemiesShown()
    {
		Invoke("showLvlBanner",.75f);
        //this resets the number of enemies shown at a time
        countHitsTillRaise = 0;
        enemiesShown = 1;
        hitsTillRaise = startHitCap;
        //to avoid playing this when on first level
        if(GameManager.gm.level!=1)AudioManager.am.playMusic("2");
    }

    void showLvlBanner()
	{
		levelText.text = "LEVEL " + GameManager.gm.level;
		Instantiate(levelBanner);
        //if (sky == null) sky = StartCoroutine(changeSky());
        changeTheSky(true);

    }
    void showBossBanner()
	{
		Instantiate(bossBanner);
        //if (sky == null) sky = StartCoroutine(changeSky());
        changeTheSky(true);
    }
    //int songInt = 1;
    public void editWaveHits(int progress)
    {
        waveHits++;
        //this manages the number of hits till number of shown enemies increases
        //NOTE: this is reset when the boss is spawned in spawn boss method
        countHitsTillRaise++;
        if (countHitsTillRaise >= hitsTillRaise)
        {
            countHitsTillRaise = 0;
            if (enemiesShown == 1) { enemiesShown = 2; hitsTillRaise = 30;  }
            else if (enemiesShown == 2) { enemiesShown = 3; hitsTillRaise = 40; }
            else if (enemiesShown == 3) { enemiesShown = 4; hitsTillRaise = 50; }
        }
        //songInt++;
        //add counts here to ensure they appear per enemies hit instead of them being spawned
        //to ensure they only appear when player hits allocated number of enemies
        if (!bombCurrent) bombCount++;
        giftCount++;
        suicideCount++;
        coinCount++;
		if (missesInRow!=0)missesInRow=0;
        if (waveHits >= progress / 4)
        {
            
            switch (wave)
            {
                case 1: wave = 2; break;
                case 2: wave = 3; break;
                case 3: wave = 4; break;
                case 4: wave = 1; break;
            }
            //if (wave > 4) wave = 1;
            waveHits = 0;
            System.GC.Collect();
            //to avoid wave 1 sound when boss has arrived
            if (wave!=1)AudioManager.am.playMusic((wave+1).ToString());
            //if (sky == null) sky = StartCoroutine(changeSky());
            //SWITCH THE COLOUR OF BACKGROUND NOW
		    changeTheSky(true);
        }
    }
    Coroutine sky;
    //Material skyMat;
    public Material skyRen;
    public float skyTotal = .225f;
    public float skyRate = .005f;

    public Light skyLight;
    public float daySkyMax = .2f;
    public float eveningSkyMax = .4f;
    public float nightSkyMax = .6f;
    public float morningSkyMax = .8f;


    public void changeTheSky(bool changeLight)
    {
        if (sky == null && gameObject.activeInHierarchy) sky = StartCoroutine(changeSky(changeLight));
    }
    IEnumerator changeSky(bool cL)
    {
        //print("changing sky started");
        Vector2 sm = skyRen/*.material*/.mainTextureOffset;
        sm.x += skyTotal;
        //to avoid the sky cap from being passed, to stay within range when checking for lighting purposes
        bool reset = false;
        if (sm.x > morningSkyMax) reset = true;// sm.x = Random.Range(0f,.2f);
        while (skyRen/*.material*/.mainTextureOffset.x <= sm.x)
        {
            skyRen/*.material*/.mainTextureOffset = new Vector2((skyRen/*.material*/.mainTextureOffset.x + skyRate), 0);
            yield return null;
        }
        if (reset) skyRen/*.material*/.mainTextureOffset = new Vector2((skyRen/*.material*/.mainTextureOffset.x -1f), 0);
        float litCap;
        float checker = skyRen/*.material*/.mainTextureOffset.x;
        if (cL){
		//does check to change the lighting
        if (checker > daySkyMax && checker < eveningSkyMax) litCap = .5f;
        else if (checker > eveningSkyMax && checker < nightSkyMax) litCap = 0f;
        else if (checker > nightSkyMax && checker < morningSkyMax) litCap = .5f;
        else /*if (checker > morningSkyMax)*/ litCap = 1f;
        //changing the light
        bool moreThan = skyLight.intensity > litCap;
        bool lessThan = skyLight.intensity < litCap;
        while ((moreThan && skyLight.intensity > litCap) || (lessThan && skyLight.intensity < litCap))
        {
            //print("Changing Lighting: " + skyLight.intensity);
            if (moreThan) skyLight.intensity -= skyRate;
            else skyLight.intensity += skyRate;
            yield return null;
        }
		}
        //print("changing sky completed");
        sky = null;

    }
    GameObject[] decideEnemyType(float type, float easyMax, float mediumMax)
    {
        if (GameManager.gm.level == 1) return easyEnemies;

        if (easyCount >= easyMax && mediumCount >= mediumMax)
        {
            easyCount = 0;
            mediumCount = 0;
            //Debug.Log("reset easy and medium");
        }
        type *= 10;
        bool done = false;
                  
        do
        {

            //if easy
            if (type < easyMax)
            {
                if (easyCount < easyMax)
                {
                    easyCount++;
                    done = true;
                    //Debug.Log("easy");
                    return easyEnemies;
                }
                else type = easyMax;
            }
            //if medium
            else if (type < mediumMax + easyMax)
            {
                if (mediumCount < mediumMax)
                {
                    mediumCount++;
                    done = true;
                    //Debug.Log("medium");
                    GameObject[] me;

                    if (GameManager.gm.level < mediumEnemies.Length)
                    {
                            me = new GameObject[GameManager.gm.level - 1];
                            for (int i = 0; i < me.Length; i++) me[i] = mediumEnemies[i];
                    }
                    else me = mediumEnemies;

                    return me;
                    //return mediumEnemies;
                }
                else type = easyMax / 2;//making sure it would be in medium range
            }
        }
        while (!done);

        return null;
    }

}
