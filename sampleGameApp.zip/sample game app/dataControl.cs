﻿using UnityEngine;
using System;
using System.IO;
#if !UNITY_WSA //|| UNITY_EDITOR
using System.Runtime.Serialization.Formatters.Binary;
//#else
//using WSAUnity;
#endif
public static class dataControl {

    const string pName = "playerSave1.bb";
    const string iName = "playerSave2.bb";
    const string iChosen = "playerSave3.bb";
    enum fileType {player,items,chosen}

    public static void deleteAllSavedGameData()
    {
        string path1 = gameOverControl.getPathUri(pName);// Application.persistentDataPath + pName;
        string path2 = gameOverControl.getPathUri(iName);// Application.persistentDataPath + hsName;
        string path3 = gameOverControl.getPathUri(iChosen);// Application.persistentDataPath + mName;
        if (File.Exists(path1))
        {
            File.Delete(path1);
        }
        else
        {
            Debug.LogWarning("save file not found in: " + path1);
        }
        if (File.Exists(path2))
        {
            File.Delete(path2);
        }
        else
        {
            Debug.LogWarning("save file not found in: " + path2);
        }
        if (File.Exists(path3))
        {
            File.Delete(path3);
        }

    }
    static readonly string itemCountKey = "itemCountKey";
    //jointSynch player, itemData id,chosenItems ci
    static void saveFile(/*Type cType,*/object obj, string name )
    {
        string path = gameOverControl.getPathUri(name);//Application.persistentDataPath + pName;
#if !UNITY_WSA //|| UNITY_EDITOR
        BinaryFormatter formatter = new BinaryFormatter();
        FileStream stream = new FileStream(path, FileMode.Create);
        formatter.Serialize(stream, obj);
        stream.Close();
#else
        using (MemoryStream m = new MemoryStream())
        {
            using (BinaryWriter writer = new BinaryWriter(m))
            {
                if (obj.GetType() == typeof(jointSynch))
                {
                    jointSynch js = (jointSynch)obj;
                    writer.Write(js.id);
                    writer.Write(js.mi);
                    writer.Write(js.playerId);
                    writer.Write(js.coins);
                    writer.Write(js.buy);
                    //score
                    writer.Write(js.weaponId);
                    writer.Write(js.score);
                    //mission
                    writer.Write(js.mname);
                    //mission
                    writer.Write(js.curcount);
                    writer.Write(js.maxcount);
                    writer.Write(js.missionDate);
                    writer.Write(js.daily);
                    writer.Write(js.hourly);
                    writer.Write(js.misc);
                }
                else if (obj.GetType() == typeof(itemData))
                {
                    itemData id = (itemData)obj;
                    for (int i = 0; i < id.itemNames.Count; i++)
                    {
                        writer.Write(id.itemNames[i]);
                        writer.Write(id.itemTimes[i]);
                        writer.Write(id.itemPerms[i]);
                        writer.Write(id.itemSynched[i]);
                        writer.Write(id.itemSynchCount[i]);

                    }
                    PlayerPrefs.SetInt(itemCountKey, id.itemNames.Count);
                }
                else if (obj.GetType() == typeof(chosenItems))
                {
                    chosenItems ci = (chosenItems)obj;
                    writer.Write(ci.chosenAvatar);
                    writer.Write(ci.chosenWeapon);
                }

            }
            //m.ToArray();
            //TextUtils.WriteAllBytes(name, m.ToArray());
            File.WriteAllBytes(path,m.ToArray());
        }
        //Debug.Log("SAVE DATA: " + (byte[])obj);
        //TextUtils.WriteAllBytes(name, (byte[])obj);
#endif

    }
    static object loadFile(Type cType, string name)
    {
        string path = gameOverControl.getPathUri(name);//Application.persistentDataPath + pName;
        if (File.Exists(path))
        {
#if !UNITY_WSA //|| UNITY_EDITOR
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);
            object data = formatter.Deserialize(stream);// as typeof(cType);// jointSynch;
            stream.Close();
            return data;
#else
            //using (MemoryStream m = new MemoryStream())
            //{

            //    using (BinaryReader reader = new BinaryReader(m))
            //    {

            //    }
            //}
            //MarshalByRefObject h;
            //byte[] data = TextUtils.ReadAllBytes(path);
            byte[] data = File.ReadAllBytes(path);

            object obj = null;
            using (MemoryStream m = new MemoryStream(data))
            {
                using (BinaryReader reader = new BinaryReader(m))
                {
                    if (cType == typeof(jointSynch))
                    {
                        jointSynch js = new jointSynch();
                        js.id = reader.ReadString();
                        js.mi = reader.ReadString();
                        js.playerId = reader.ReadString();
                        js.coins = reader.ReadInt32();
                        js.buy = reader.ReadBoolean();
                        //score
                        js.weaponId = reader.ReadString();
                        js.score = reader.ReadInt32();
                        //mission
                        js.mname = reader.ReadString();
                        //mission
                        js.curcount = reader.ReadInt32();
                        js.maxcount = reader.ReadInt32();
                        js.missionDate = reader.ReadString();
                        js.daily = reader.ReadString();
                        js.hourly = reader.ReadString();
                        js.misc = reader.ReadString();
                        obj = js;
                    }
                    else if (cType == typeof(itemData))
                    {
                        itemData id = new itemData();
                        int count = PlayerPrefs.GetInt(itemCountKey, 0);
                        for (int i = 0; i < count; i++)
                        {
                            id.itemNames.Add(reader.ReadString());
                            id.itemTimes.Add(reader.ReadString());
                            id.itemPerms.Add(reader.ReadBoolean());
                            id.itemSynched.Add(reader.ReadBoolean());
                            id.itemSynchCount.Add(reader.ReadInt32());
                        }
                        obj = id;

                    }
                    else if (cType == typeof(chosenItems))
                    {
                        chosenItems ci = new chosenItems();
                        ci.chosenAvatar = reader.ReadString();
                        ci.chosenWeapon = reader.ReadString();
                        obj = ci;
                    }

                }
            }
            return obj;
#endif
        }
        else
        {
            Debug.LogWarning("save file not found in: " + path);
            return null;
        }
    }
    public static void savePlayer(jointSynch player)
    {
        saveFile(player,pName);
    }
    
    public static jointSynch loadPlayer()
    {
        jointSynch data = (jointSynch)loadFile(typeof(jointSynch),pName);
        Debug.Log("got player info");
        if (data != null) return data;
        else return new jointSynch();
    }


    public static void saveItems(itemData items)
    {
        saveFile(items,iName);
    }

    public static itemData loadItems()
    {
        itemData data = (itemData)loadFile(typeof(itemData),iName);
        Debug.Log("got item info");
        if (data != null) return data;
        else return new itemData();
    }

    public static void saveChosen(chosenItems chosen)
    {
        saveFile(chosen,iChosen);
    }

    public static chosenItems loadChosen()
    {
        chosenItems data = (chosenItems)loadFile(typeof(chosenItems),iChosen);
        Debug.Log("got chosen items");
        if (data != null) return data;
        else return new chosenItems();
    }
}
