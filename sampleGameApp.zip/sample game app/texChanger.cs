﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class texChanger : MonoBehaviour {

    private LineRenderer laser;
    //private float offSetCount = Mathf.Infinity;
    //private Renderer activeRend;
    private Material activeMat;
    public bool offSetTexture = true;
    [Tooltip("if true then rotates on y axis")]
    public bool rotateXY = true;

    [Tooltip("if changing colours of object")]
    public bool changingColors = false;
    public Color[]chosenColours;
    public float secsBetweenSwitch=1;
    private int i = 0;
    // Use this for initialization
    void Start () {
        //if line renderer
        if (GetComponent<LineRenderer>())
            activeMat = GetComponent<LineRenderer>().GetComponent<Renderer>().material;
        //if projectile
        else activeMat = GetComponent<Renderer>().material;

    }

    // Update is called once per frame
    void Update () {
        {
            //offSetCount-=.00000000001f;
            //this rotates the line to make it animated
            //offSetRend.material.mainTextureOffset.Set(0, offSetCount);// new Vector2(0, Time.time);
            //THIS ROTATES THE LASER SO THAT IT LOOKS BETTER YOU CAN SAY
            if (offSetTexture)
            {
                if (rotateXY) activeMat.SetTextureOffset("_MainTex", new Vector2(0, Time.time));
                else activeMat.SetTextureOffset("_MainTex", new Vector2(-Time.time * 7.5f, 0));
            }

            if (changingColors)
            {
                int j = i + 1;
                //if next colour doesnt exist, then start over
                if (j >= chosenColours.Length) j = 0;
                Color c = Color.Lerp(chosenColours[i],chosenColours[j],Mathf.PingPong(Time.time,secsBetweenSwitch));
                activeMat.SetColor("_Color", c);
                //if colour has been atained
                if (c == chosenColours[j])
                {
                    print("colour attained");
                    i += 1;
                    //if colour array has been fully traversed
                    if (i >= chosenColours.Length) i = 0;
                }
            }

        }
    }
}
