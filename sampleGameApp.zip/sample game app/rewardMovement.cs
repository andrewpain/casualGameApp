﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class rewardMovement : MonoBehaviour {

    Transform target;
    public float speed;
    public float disFrom = .5f;
    bool move = true;
    int coinReward;
    GameObject power;
    float waitTime = 1;
    ParticleSystem.MainModule pm;
    public enum rewardType {coin,power,heart};
    public rewardType reward;
    bool safety = false;
    // Use this for initialization
    //void Start()
    //{
    //    //target = GameObject.Find("coin").transform;
    //    target = GameManager.gm.coinGraphic.gameObject.transform;
    //    pm = gameObject.GetComponent<ParticleSystem>().main;
    //    ranDir = Time.time;
    //    ranPos = new Vector3(
    //    Random.Range(transform.position.x - 3, transform.position.x + 1),
    //    Random.Range(transform.position.y - 2, transform.position.y + 2),
    //    Random.Range(transform.position.z - 2, transform.position.z + 2));
    //    transform.LookAt(ranPos);

    //}

    public void setStart(float waitSecs, int coinAmount, GameObject powerUp= null, bool safe= false)
    {
        waitTime = waitSecs;
        safety = safe;
        switch (reward)
        {
            case rewardType.coin:
                coinReward = coinAmount;
                target = GameManager.gm.coinGraphic.gameObject.transform;
                ranPos = new Vector3(
                    Random.Range(transform.position.x - 3, transform.position.x + 1),
                    Random.Range(transform.position.y - 2, transform.position.y + 2),
                    Random.Range(transform.position.z - 2, transform.position.z + 2));
                //reduces the scale for the item menu
                if (safety && (GameManager.gm.gameState == GameManager.gameStates.avatarMenu || GameManager.gm.gameState == GameManager.gameStates.weaponMenu))
                {
                    transform.localScale = new Vector3(.25f, .25f, .25f);
                    waitTime /= 4f;
                    speed /= 4f;
                    disFrom /= 4f;
                }
                    break;
            case rewardType.power:
                power = powerUp;
                target = GameManager.gm.power1Button.gameObject.transform;
                ranPos = new Vector3(
                     Random.Range(transform.position.x - 1, transform.position.x + 1),
                     Random.Range(transform.position.y - 1, transform.position.y + 1),
                     Random.Range(transform.position.z - 1, transform.position.z + 1));
                break;
            case rewardType.heart:
                target = GameManager.gm.player.transform;
                ranPos = new Vector3(
                     Random.Range(transform.position.x - 2, transform.position.x + 2),
                     Random.Range(transform.position.y - 3, transform.position.y),
                     transform.position.z);
                break;
        }
        pm = gameObject.GetComponent<ParticleSystem>().main;
        ranDir = Time.time;
        
        transform.LookAt(ranPos);
    }
    Vector3 ranPos;
    float ranDir = 0;
	public float rotateSpeed = 10;
    bool turnFinish = false;//avoid crash when coin moves with camera 
    // Update is called once per frame
    void Update () {

        if (!move) return;
        //moving towards target
        if ((Time.time - ranDir) < waitTime)
        {
            //transform.rotation = Quaternion.Euler(ranPos);
            //transform.Translate(ranPos * Time.deltaTime);
			gameObject.transform.Translate(Vector3.forward * Time.deltaTime * speed);
        }
        else
        {
            //transform.LookAt(target);
			Vector3 relPos = target.position - transform.position;
            Quaternion tarRot = Quaternion.LookRotation(relPos);
            transform.rotation = Quaternion.RotateTowards(transform.rotation, tarRot, rotateSpeed * Time.deltaTime);

            
            //moves towards
            if (tarRot == transform.rotation || turnFinish)
            {
                if (!turnFinish) turnFinish = true;
                gameObject.transform.position = Vector3.MoveTowards(transform.position, target.position, Time.deltaTime * speed);
                // to ensure that speed only increases when reward is facing the target
                speed += (speed * .05f);
            }
            //moves forward
            else gameObject.transform.Translate(Vector3.forward * Time.deltaTime * speed);
        }
        //increases speed as it moves
        //if close enough then object will eventually disable then loop is turned off
        if (Vector3.Distance(target.position, transform.position) < disFrom)
        {
            switch (reward)
            {
                case rewardType.coin: GameManager.gm.Collect(coinReward,safety);break;
                case rewardType.power: GameManager.gm.addPowerUps(power);break;
                case rewardType.heart: GameManager.gm.playerHealth.ApplyHeal(1);break;
            }
            move = false;
            pm.loop = false;
        }
    }
}
