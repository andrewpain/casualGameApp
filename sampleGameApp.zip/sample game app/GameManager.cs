﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
//using UnityEngine.SocialPlatforms;
//using UnityEngine.Purchasing;
using System;
//using System.Collections.Generic;
//using System.Net.Http;
//using Microsoft.WindowsAzure.MobileServices;
using Azure.AppServices;
//using System.Xml;
using RESTClient;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    public static GameManager gm;
    public bool deleteMemory = false;
    public static readonly string defWeapon = weapons.weapon_revolver.ToString(), defAvatar = avatars.avatar_playerDefault.ToString();
    public static readonly float playerYPos = 1f,playerZPos = -7f;
    public static AppServiceClient client = AppServiceClient.Create("sampleGameApp");
    public static Coroutine fundaCheck;
    [HideInInspector]
    public GameObject player, weapon;
    [HideInInspector]
    public Health_Player playerHealth;
    [HideInInspector]
    public infoAvatar playerInfo;

    public enum gameStates { PrePlay, Playing, Pause, Death, GameOver, newName, weaponMenu, avatarMenu };
    public gameStates gameState;

    [HideInInspector]
    public int level = 1, score = 0, coinAmount = 0, totalprogress = 160, enemySpeed = 1, proSpeed = 1;

    public GameObject playingPanel, pausePanel, continuePanel;
    public prePlayControl prePlayController;
    public crosshairControl crossHair, crossHair2;
    [HideInInspector]
    public mission currentMission;
    public missionControl gameMissionControl;
    public Text scoreDisplay, coinDisplay;
    public Animator coinGraphic;
    public Image progressbar;
    [HideInInspector]
    public GameObject[] powerUps = new GameObject[3];
    public Button power1Button;
    public Image[] powerImages = new Image[3];

    public Vector3 MinRange, MaxRange;
    //if is for when the bomb animation is being played. turns on when bomb explosion starts, turns off when it's destroyed both by the bomb
    [HideInInspector]
    public bool bombMode = false, bannerMode = false, jumping = false, bossLoading = false, 
        bossMode = false, tutorialMode = false, showAd = false;
    [HideInInspector]
    public float totalBossLife = 120;
	private float currentBossLife;
    private int hitsTillBoss = 0;
    public Spawner spawn;
    public static powerUp.powerType powerActive = powerUp.powerType.none;
    [HideInInspector]
    public float border = 0f;

    public static jointSynch gamePlayer;
    public static itemData gameItems;
    public static chosenItems gameChosen;

    public static readonly string 
	playerCoinsUnsynchedKey = "playerCoinsSynched", playerScoreUnsynchedKey = "playerScoreSynched",
	playerPlatformUnsynchedKey = "playerPlatformScore", worldKey = "defIsland", missionUnsynchedKey = "missionUnSynched", 
	missionUnRewardedKey = "missionUnRewarded", borderLengthKey = "borderLength", tutorialKey = "tutorial",playerLiveAd = "livingShow";
    //strings of status msgs shown to player
    List<string> msgs = new List<string>();

#if UNITY_WSA
   public static WSAPlay WSAPlayer;
    public static bool ifJoyStick = false;
    public static int joyStickNo = 0;
#endif

    public GameObject unPauseButton, watchAdButton;
    //this checks if spawner is alowed to spawn anything
    public bool ifSpawnAnything()
    {
        return (!bossMode && !bossLoading && !bombMode);
    }
    //edits the count of projectiles
    public void editProjectileCount(bool b)
    {
        if (!b && currentMission && currentMission.missionAlias2 == mission.missionType2.notShotAt)
            currentMission.progressMission(-1, Vector3.zero, Quaternion.identity);
    }
    int projectileMax = 4;
    //if enemy is allowed to spawn projectiles
    public bool ifCreateProjectiles(float yPos)
    {
        return transform.childCount < projectileMax && gameState == gameStates.Playing && yPos >= MinRange.y && !bombMode && !bannerMode && !tutorialMode && !jumping;
    }

    public GameObject loadAnimation;
    private GameObject loading;
    bool loadingNow = false;
    public void toggleLoading(bool b, bool makeSmall = false)
    {
        if (b && !loadingNow)
        {
            loadingNow = true;
            if (loading) Destroy(loading);
            if (makeSmall)
            {
                loading = Instantiate(loadAnimation, new Vector3(0, 1, -16), loadAnimation.transform.rotation) as GameObject;
                loading.transform.localScale = new Vector3(.25f, .25f, .25f);
            }
            else loading = Instantiate(loadAnimation);
        }
        else if (!b && loading && loadingNow)
        {
            loadingNow = false;
            ParticleSystem ps = loading.GetComponent<ParticleSystem>();
            ParticleSystem.MainModule psm = ps.main;
            psm.loop = false;
        }
    }

    public Text statusMsg;

    public static bool conMade = false, sceneLoaded = false;//,
    public bool readyToPlay = false;

    public void onMakeConComplete(IRestResponse<Message> res)
    {
        if (!res.IsError)
        {
            if (gameState == gameStates.PrePlay) conMade = true;
            print("CONNECTION MADE: " + res.Content);

            //doing checks for profile related tasks
            //checks if player is created yet
            if (gamePlayer.id == "" && fundaCheck == null)
            {
                string idName;
#if UNITY_ANDROID && !UNITY_EDITOR
                idName = "play" + Guid.NewGuid().ToString();
#elif UNITY_WSA && !UNITY_EDITOR
                idName = "uwpp" + Guid.NewGuid().ToString();
#else
                idName = "test" + Guid.NewGuid().ToString();
#endif
                jointSynch fs = new jointSynch
                {
                    playerId = idName,
                    coins = gamePlayer.coins,
                    weaponId = defWeapon,
                    score = gamePlayer.score,
                };
                print("TEMP ID= " + fs.playerId);
                PlayerPrefs.SetString("tempName", fs.playerId);
                fundaCheck = StartCoroutine(client.InvokeApi<jointSynch, jointSynch>("sampleFirstSync", Method.POST, fs, playerFundaComplete));
            }
            //update check for profile
            else if (PlayerPrefs.HasKey(platformPlay.newIdKey) && fundaCheck == null)
            {
                Message m;
#if UNITY_ANDROID
                m = Message.Create(gamePlayer.go, gamePlayer.id, "go");
#elif UNITY_WSA
                m = Message.Create(gamePlayer.mi, gamePlayer.id, "mi");
#endif
                fundaCheck = StartCoroutine(client.InvokeApi<Message, Message>
                    ("sampleFirstUpdate", Method.POST,m,playerUpdateComplete));
            }
            //checks if there is and old account id to delete
            else if (PlayerPrefs.HasKey(restoreManager.idDeleteKey))
                removeRecordNow(PlayerPrefs.GetString(restoreManager.idDeleteKey));
        }
        else
        {
            Debug.Log("Make Error Status:" + res.StatusCode + " Url: " + res.Url);
            Debug.Log("Detail Status:" + res.ErrorMessage + " Url: " + res.Url);
        }
    }
    public void removeRecordNow(string rid)
    {
        print("deleting player: " + rid);
        StartCoroutine(client.InvokeApi<Message, Message>("sampleDeletePlayer", Method.POST, Message.Create(rid), removePlayerComplete));
    }

    void removePlayerComplete(IRestResponse<Message> response)
    {
        if (response.IsError)
        {
            Debug.Log("coundn't remove unwanted record" + response.ErrorMessage);
            fundaCheck = null;

            return;
        }
        Debug.Log("On deleting Player Complete: " + response.Url + " data: " + response.Content);

        if (PlayerPrefs.HasKey(restoreManager.idDeleteKey)) PlayerPrefs.DeleteKey(restoreManager.idDeleteKey);
        fundaCheck = null;
    }

    public static void playerFundaComplete(IRestResponse<jointSynch[]> response)
    {
        if (response.IsError)
        {
            Debug.Log("player error in creating/updating player fundamentals: " + response.ErrorMessage);
            fundaCheck = null;

            return;
        }
        Debug.Log("On creating Player Complete: " + response.Url + " data: " + response.Content);
        jointSynch[] js = response.Data;

        //if new id
        if (gamePlayer.id == "" && js[0].playerId != null && js[0].playerId != "" && js[0].playerId != PlayerPrefs.GetString("tempName"))
        {
            gamePlayer.id = js[0].playerId;
            gamePlayer.playerId = "";// PlayerPrefs.GetString("tempName");
        }
        dataControl.savePlayer(gamePlayer);
        PlayerPrefs.DeleteKey("tempName");

        dataControl.savePlayer(gamePlayer);
        fundaCheck = null;
    }
    public static void playerUpdateComplete(IRestResponse<Message> response)
    {
        if (response.IsError)
        {
            Debug.Log("player error in creating/updating player fundamentals: " + response.ErrorMessage);
            fundaCheck = null;
            return;
        }

        if (PlayerPrefs.HasKey(androidPlay.newIdKey))
        {
            print("updating player complete");
            PlayerPrefs.DeleteKey(androidPlay.newIdKey);
        }
        dataControl.savePlayer(gamePlayer);
        fundaCheck = null;
    }

    public void timedMsg(string msg)
    {
        //statusMsg.text = msg;
        toggleLoading(false);
        msgs.Add(msg);
        if (msgShow == null) msgShow = StartCoroutine(showingMsg());
    }
    Coroutine msgShow;
    IEnumerator showingMsg()
    {
        do
        {
            statusMsg.text = msgs[0];
            yield return new WaitForSecondsRealtime(5);
            msgs.RemoveAt(0);
        }
        while (msgs.Count>0);
        statusMsg.text = "";
        msgShow = null;
    }

    void Start()
    {
#if UNITY_EDITOR
        //TEST WHAT HAPPENS WHEN DELETED IS UPDATED TO TRUE IN DATABASE
        if (deleteMemory)
        {
            PlayerPrefs.DeleteAll();
            dataControl.deleteAllSavedGameData();
        }
#endif
        //setting the game manager
        if (gm == null) gm = gameObject.GetComponent<GameManager>();

        //makes sure the games doesnt sleep to avoid gm returning null!
        Screen.sleepTimeout = SleepTimeout.NeverSleep;

        //loading the saved information
        gamePlayer = dataControl.loadPlayer();
        gameItems = dataControl.loadItems();
        gameChosen = dataControl.loadChosen();


        //load tutorial gameobject if tutorial hasnt been done before
        if (!PlayerPrefs.HasKey(tutorialKey)) Instantiate(Resources.Load("begin/tutorial", typeof(GameObject)));// as GameObject;

        gameAni = gameContainer.GetComponent<Animator>();
        //attempts connecting with server to make synching throughout the run of the game faaster
        StartCoroutine(client.InvokeApi<Message>("sampleConnectionMaker", Method.GET, onMakeConComplete));

        //sets the highscore and the coins
        setHighCoins();
        //setting the player and the player health
        setPlayerAndWeapon();
        //setting the power up button
        power1Button.interactable = false;

        curIsland = Instantiate(islands[PlayerPrefs.GetInt(worldKey, defWorldKey)]);

        explosionZPos = Camera.main.gameObject.transform.position.z;
        //to make sure the game logo is shown for a reasonable amount of time
        Invoke("checkLoad", 4);

        //deletes screenshot! since it wont be used after this
        string ssPath = gameOverControl.getPathUri(gameOverControl.getScreenShotName(false));
        if (System.IO.File.Exists(ssPath)) System.IO.File.Delete(ssPath);
        ///PUT THIS EVERYWHERE AVATAR/WEAPON ENUMS ARE USED!!!!
        //print("name of avatars: " + Enum.GetValues(typeof(avatars)).GetValue(i));
#if UNITY_ANDROID //|| UNITY_EDITOR
        Instantiate(Resources.Load("platformServices/googlePlay",typeof(GameObject)));
        Instantiate(Resources.Load("IAP", typeof(GameObject)));

        //#elif UNITY_IOS

#elif UNITY_WSA
        //put the xbox live code here as well
        Instantiate(Resources.Load("platformServices/XboxLiveServices", typeof(GameObject)));
        GameObject paXbox = Instantiate(Resources.Load("platformServices/PlayerAuthenticationXbox", typeof(GameObject))) as GameObject;
		paXbox.GetComponent<Canvas>().worldCamera = Camera.main;
        Instantiate(Resources.Load("IAP_UWP", typeof(GameObject)));
        //this is placed here since a 30-60 sec wait time is required in order to play microsoft ads
        //hopefully player plays for at leasst 30-60 secs
        int cAdCount = PlayerPrefs.GetInt(adCountKey, 5) + 1;
        if ((!IAPParent.ifDoneIt() && cAdCount >= 5) || PlayerPrefs.HasKey(playerLiveAd))
        {
            showAd = true;
            ad = gameObject.AddComponent<adsControl>();
            ad.adControlStart(adsControl.vidType.optional,true,null);
            //show ad here if game is played 5 or more times
            
        }
        //if joystick is configured 
        string []j = Input.GetJoystickNames();
		
		if(j!=null)
		{
			for (int i = 0; i < j.Length; i++)
			{
				print("JOYSTICK?!: "+ ifJoyStick);
                print("j: "+ i + " name: "+j[i].ToString());
                if (j[i] != null && j[i].Length > 5)
                {
                    ifJoyStick = true;
                    joyStickNo = i + 1;
                    break;
                }
                else ifJoyStick = false;
            
            }
		}
		else ifJoyStick = false;
#endif
        //to let the itemManagers know that this scene is finished loading
        sceneLoaded = true;

    }
    //public GameObject IAP;
    public static readonly int defWorldKey = 0;

    //public static bool sceneLoaded = false;
    //counts loading
    int loadCount = 0;
    public Animator loadingBackdrop;
    public Animator loadingLogo;
    //method which keeps track of the synching before the scene loads
    public void checkLoad()
    {
        loadCount += 1;
        //print("loadcount: " + loadCount);
        if (loadCount == 5)
        {
            //do animation that reveals the game screen here
            //Animator a = gameContainer.GetComponent<Animator>();
            //gameContainer.SetActive(true);
            /*gameAni*/prePlayController.prePlayAnimator.SetFloat("direct", 1);
            /*gameAni*/prePlayController.prePlayAnimator.SetTrigger("enter");
            loadingBackdrop.SetTrigger("reveal");
            loadingLogo.SetTrigger(/*"move"*/"ready");
            //print("finished loading");
            Invoke("readyPlay", 2f);
            //plays theme music
            AudioManager.am.playMusic("theme");
            setCamManualMove(true);
        }
    }

    public void setCamManualMove(bool onOff)
    {
        if (onOff)
        {
            if (cameraMove != null) StopCoroutine(cameraMove);
            cameraMove = StartCoroutine(camMove());
        }
        else
        {
            if (cameraMove != null) StopCoroutine(cameraMove);
            Animator a = Camera.main.gameObject.GetComponent<Animator>();
            if (a) a.enabled = true;
        }
    }
    public void setCamManualMove(float newRange, float newSpeed,float totalTimeSecs)
    {

        if (cameraMove != null) StopCoroutine(cameraMove);
        cameraMove = StartCoroutine(camMove(newRange, newSpeed,totalTimeSecs));
    }
    Coroutine cameraMove;

    //range for camera to move within
    public float range = .1f;
    public float camSpeed = 1f;
    IEnumerator camMove()
    {
        Animator a = Camera.main.gameObject.GetComponent<Animator>();
        if (a) a.enabled = false;        //float range = .1f;
        Vector3 cHome = new Vector3(0, 4.5f, -20f);//Camera.main.transform.position;
        Transform cT = Camera.main.transform;
		yield return new WaitUntil (() =>PlayerPrefs.HasKey(borderLengthKey));
        do
        {
            Vector3 nPos = new Vector3(UnityEngine.Random.Range(cHome.x - range, cHome.x + range), UnityEngine.Random.Range(cHome.y - range, cHome.y + range), cHome.z);
            do
            {
                cT.position = Vector3.MoveTowards(cT.position, nPos, camSpeed * Time.deltaTime);
                yield return null;
            }
            while (cT.position != nPos);

        }
        while (true);
        //cameraMove = null;
    }
    IEnumerator camMove(float newRange, float newSpeed, float timeSecs)
    {
        //Animator a = Camera.main.gameObject.GetComponent<Animator>();
        //if (a) a.enabled = false;
        //float range = .1f;
        Vector3 cHome = new Vector3(0, 4.5f, -20f);//Camera.main.transform.position;
        Transform cT = Camera.main.transform;
        float totalTime = Time.time + timeSecs;
        do
        {
            Vector3 nPos = new Vector3(UnityEngine.Random.Range(cHome.x - newRange, cHome.x + newRange), UnityEngine.Random.Range(cHome.y - newRange, cHome.y + newRange), cHome.z);
            do
            {
                cT.position = Vector3.MoveTowards(cT.position, nPos, newSpeed * Time.deltaTime);
                yield return null;
            }
            while (cT.position != nPos);
            /*if (Time.time > totalTime)*/ newRange -= .01f;
        }
        while (Time.time < totalTime);
        cameraMove = null;
        setCamManualMove(true);
    }
    //for when in case the restore manager has data to show
    void readyPlay()
    {
        readyToPlay = true;
    }


    public void setPlayerAndWeapon()
    {
        Destroy(player);
        if (weapon)Destroy(weapon);
        playerHealth = null;
        playerInfo = null;

        string aSaved = gameChosen.chosenAvatar;//PlayerPrefs.GetString(chosenAvatarKey, defAvatar);
        //if weapon saved is not default and is not a permenant
        if (aSaved != defAvatar && gameItems.itemNames.Contains(aSaved) && !gameItems.itemPerms[gameItems.itemNames.IndexOf(aSaved)]/*PlayerPrefs.GetInt(aSaved, 0) != 1*/)
        {
            //calculating if the weapon's time is still valid
            //DateTime wStart = DateTime.Parse(PlayerPrefs.GetString(aSaved + startTimeKey, "" + new DateTime(2018, 1, 1, 1, 1, 1)));
            DateTime wStart = DateTime.Parse(gameItems.itemTimes[gameItems.itemNames.IndexOf(aSaved)]);
            TimeSpan wRemain = DateTime.UtcNow - wStart;
            //TO CHANGE TO 4 HOURS WHEN IN FINAL PRODUCTION
            if (wRemain >= ItemManager.itemTimeCap)
            {
                aSaved = defAvatar;
            }
        }
        else if (!gameItems.itemNames.Contains(aSaved))
        {
            aSaved = defAvatar;
        }
        player = Instantiate(Resources.Load("avatars/" + aSaved, typeof(GameObject))) as GameObject;
        playerHealth = player.GetComponent<Health_Player>();
        playerInfo = player.GetComponent<infoAvatar>();
        player.SetActive(true);
        //checking if the weapon saved still has time on it
        string wSaved = gameChosen.chosenWeapon;//PlayerPrefs.GetString(chosenWeaponKey, defWeapon);
        if (wSaved != defWeapon && gameItems.itemNames.Contains(wSaved) && !gameItems.itemPerms[gameItems.itemNames.IndexOf(wSaved)]/*PlayerPrefs.GetInt(wSaved,0)!=1*/)
        {
            //calculating if the weapon's time is still valid
            //DateTime wStart = DateTime.Parse(PlayerPrefs.GetString(wSaved + startTimeKey, "" + new DateTime(2018, 1, 1, 1, 1, 1)));
            DateTime wStart = DateTime.Parse(gameItems.itemTimes[gameItems.itemNames.IndexOf(wSaved)]);
            TimeSpan wRemain = DateTime.UtcNow - wStart;
            //TO CHANGE TO 4 HOURS WHEN IN FINAL PRODUCTION
            if (wRemain >= ItemManager.itemTimeCap)
            {
                wSaved = defWeapon;
            }
        }
        else if (!gameItems.itemNames.Contains(wSaved))
        {
            wSaved = defWeapon;
        }
        //setting the player's weapon
        weapon = Instantiate(Resources.Load("weapons/" + wSaved, typeof(GameObject))) as GameObject;
        weapon.SetActive(true);
        weapon.transform.parent = player.transform;
        //setting the location of the player to some random position off screen
        player.transform.position = new Vector3(15, 0, 0);
        //if mission is to get a score with a weapon
        // if (currentMission && currentMission.missionAlias == mission.missionType.hitEnemy && currentMission.missionAlias2 == mission.missionType2.useWeapon)
        // ((mission_scoreWithWeapon)(currentMission)).ifUsingRightWeapon();
    }
    static float explosionZPos;
    public static Vector3 explosionLocation(Vector3 pos)
    {
        return new Vector3(pos.x, pos.y, explosionZPos);
    }
#if UNITY_WSA
    private void Update()
    {
        if (ifJoyStick)
        {
            if (gameState == gameStates.Playing || gameState == gameStates.Pause)
            {
                //if (gameState == gameStates.Playing)
                //{
                if (Input.GetButtonDown("Fire2") && power1Button.interactable) activatePower();
                //}
                //else if (gameState == gameStates.Pause)
                //{
                if (Input.GetButtonDown("Start")) togglePauseMenu(!isPause);

                //}
            }
            if (sceneLoaded && Input.GetButtonDown("Fire3") && !WSAPlayer)
                GameObject.FindObjectOfType<Microsoft.Xbox.Services.Client.PlayerAuthentication>().SignIn();//.Find("PlayerAuthenticationXbox").GetComponent<Microsoft.Xbox.Services.Client.PlayerAuthentication> ().SignIn();

        }
    }
#endif
    private float curSlow = -1;
    Animator gameAni;
    bool isPause = false;
    public void togglePauseMenu(bool onOff)
    {
        if (onOff)
        {
            //function for dont miss, to patch glitch
            if (currentMission && currentMission.missionAlias2 == mission.missionType2.dontMiss)
                ((mission_dontMiss)currentMission).pausePowerFun();

            if (Time.timeScale != 1) curSlow = Time.timeScale;
#if UNITY_WSA
            if (ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(unPauseButton);
#endif
            Time.timeScale = 0f;
            gameState = gameStates.Pause;
            AudioManager.am.togglePauseMusic(true);
            //pausePanel.SetActive(onOff);
            gameAni.SetFloat("direct", 1);
            gameAni.SetTrigger("pause");
            playingPanel.SetActive(!onOff);
            //if mission exists, shot current information/status of mission
            if (currentMission && !currentMission.complete)
            {
                gameMissionControl.toggleMissionVisibility(true);
            }

        }
        else
        {
            // turns off the mission's stats before returning to the game play
            //if (missionPanel.activeSelf) missionPanel.SetActive(false);
            if (currentMission) gameMissionControl.toggleMissionVisibility(false);
            playingPanel.SetActive(!onOff);
#if UNITY_WSA
            if (ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(null);
#endif
            gameAni.SetFloat("direct", -1);
            gameAni.SetTrigger("pause");
            //pausePanel.SetActive(onOff);
            AudioManager.am.togglePauseMusic(false);

            if (curSlow == -1) Time.timeScale = 1f;
            else { Time.timeScale = curSlow; curSlow = -1; }
            gameState = gameStates.Playing;

        }
        isPause = onOff;
    }

    public GameObject itemContainer;
    //public GameObject avatarContainer;
    public GameObject gameContainer;
    //if the player opts to continue playing, ad will be shown at the end of the game
    public adsControl ad;
    public void loadGameScene()
    {
        //to compensate for if game quits from pause menu
        if (Time.timeScale != 1f)
        {
            Time.timeScale = 1f;
            Time.fixedDeltaTime = Time.timeScale * .02f;
            pausePanel.SetActive(false);
        }
        int cAdCount = PlayerPrefs.GetInt(adCountKey, 5) + 1;
        PlayerPrefs.SetInt(adCountKey, cAdCount);
        if ((!IAPParent.ifDoneIt() && cAdCount >= 5) || showAd)
        {
            //if  opted to show ad in order to continue playing
            if (showAd && ad && ad.RewardCheck()) ad.rewardAdNow();
            //show ad here if game is played 5 or more times
            //if ad is not ready but it is time for ad, then that means that it is not windows
            else
            {

                ad = gameObject.AddComponent<adsControl>();
                ad.adControlStart(adsControl.vidType.optional, true, null);
                ad.rewardAdNow();
            }
        }
        //loads scene regular
        else aboutToEndScene();
    }
    bool scnFin = false;
    public void aboutToEndScene()
    {
        if (scnFin) return;
        scnFin = true;
        StartCoroutine(endingScene());
    }
    IEnumerator endingScene()
    {
        if (loadingLogo && loadingLogo.gameObject) Destroy(loadingLogo.gameObject);
        loadingBackdrop.gameObject.transform.parent.GetComponent<Canvas>().sortingOrder = 1;
        loadingBackdrop.SetTrigger("hide");
        yield return new WaitForSeconds(.75f);
        SceneManager.LoadScene(0);
    }
    //Continue timer for the continue pop up
    private int timeLeft = 10;
    public Text ctime;
    public Text continueCostText;
    //player loses life, and prompt to continue playing is shown
    public void playerDying()
    {
        // update gameState
        gameState = gameStates.Death;
        setHighCoins();
        AudioManager.am.togglePauseMusic(true);
        // int cost = ((int)((progressbar.fillAmount * 100) / 1.7));
        int cost = (int)(score / 1.7);

        if (cost < 5) cost = 5;
        continueCostText.text = cost.ToString();
        // switch which GUI is showing	
        playingPanel.SetActive(false);
        continuePanel.SetActive(true);
#if UNITY_WSA
        if (ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(watchAdButton);
#endif
        gameAni.SetTrigger("tick");
        ctime.text = "" + timeLeft;
        InvokeRepeating("hastenCountDown", .5f, .5f);
    }
    //ticks the countdown by 1 second 
    public void hastenCountDown()
    {
        timeLeft -= 1;
        ctime.text = "" + timeLeft;
        AudioManager.am.playSound("tick");
        if (timeLeft < 1)
        {
            CancelInvoke("hastenCountDown");
            continuePanel.SetActive(false);
            playerDies();

        }
    }
    public static readonly string adCountKey = "adCount";
    //when player chooses to continue playing with ad
    public void playerMayLiveAd(/*GameObject conPanel*/)
    {
        Debug.Log("player may live with AD");
        StartCoroutine(playerMayLiveAdCheck());
    }
    IEnumerator playerMayLiveAdCheck()
    {
        if (!ad)
        {
            ad = gameObject.AddComponent<adsControl>();
            ad.adControlStart(adsControl.vidType.must, true, null);
        }
        toggleLoading(true);
        CancelInvoke("hastenCountDown");
        continuePanel.SetActive(false);
        yield return StartCoroutine(ad.longRewardCheck());
        if (ad.videoReady)
        {
            PlayerPrefs.SetInt(playerLiveAd,0);
            showAd = true;
            //this adds to the ad view count in case player decides to quit game before it finished, in an atempt to escape viewing the ad
            int cAdCount = PlayerPrefs.GetInt(adCountKey, 5) + 1;
            PlayerPrefs.SetInt(adCountKey, cAdCount);
            playerLiveCal();
            toggleLoading(false);
        }
        //ad = new adControl(/*adControl.rewardVid*/adControl.vidType.must, true, null, false);
        //if ( ad.rewardCheck())
        //{
        //    showAd = true;
        //    //this adds to the ad view count in case player decides to quit game before it finished, in an atempt to escape viewing the ad
        //    int cAdCount = PlayerPrefs.GetInt(adCountKey, 5) + 1;
        //    PlayerPrefs.SetInt(adCountKey, cAdCount);
        //    playerLiveCal();
        //    //Destroy(conPanel);
        //}
        
        else
        {
            if (ad)Destroy(ad);
            continuePanel.SetActive(true);
            InvokeRepeating("hastenCountDown", .5f, .5f);
            timedMsg("No Ads are available right now :(");
            Debug.Log("AD not working, player still dying");
        }
    }
    //when player chooses to continue playing by paying
    public void playerMayLivePay()
    {
        Debug.Log("player may live with PAY");
        //in final code, edit so that it would add saved coins + current coins gained from game
        int cost = Convert.ToInt32(continueCostText.text);//100;

        int tc = gamePlayer.coins;//PlayerPrefs.GetInt(playerCoinsKey, 0);
        if (tc >= cost)
        {
            //PlayerPrefs.SetInt(playerCoinsKey, (tc - cost));
            gamePlayer.coins = tc - cost;
            dataControl.savePlayer(gamePlayer);
            playerLiveCal();
            //Destroy(conPanel);
        }
    }

    //calculations/functions done to facilitate the player being respawned
    private void playerLiveCal()
    {
        CancelInvoke("hastenCountDown");

        scoreDisplay.text = "" + score;
        coinDisplay.text = "" + coinAmount;
        playerHealth.respawn();
        continuePanel.SetActive(false);
#if UNITY_WSA
        if (ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(null);
#endif
        Destroy(continuePanel);
        playingPanel.SetActive(true);
        gameState = gameStates.Playing;
        AudioManager.am.togglePauseMusic(false);

        //deletes screenshot! since it wont be used after this
        System.IO.File.Delete(gameOverControl.getPathUri(gameOverControl.getScreenShotName(false)));

        GameObject[] e = GameObject.FindGameObjectsWithTag("Enemy");
        GameObject[] p = GameObject.FindGameObjectsWithTag("Enemy_projectile");

        foreach (GameObject enemy_pro in p)
        {
            // if the hit object has the Health script on it, deal damage
            Health h = enemy_pro.GetComponent<Health>();
            if (h) enemy_pro.GetComponent<Health>().activateExplosion();
        }

        foreach (GameObject enemy in e)
        {
            // if the hit object has the Health script on it, deal damage
            Health h = enemy.GetComponent<Health>();
            if (h && !enemy.name.Contains("Boss")) enemy.GetComponent<Health>().activateExplosion();
        }
    }
    public GameObject gameOverCanvas;
    public void playerDies()
    {
        gameState = gameStates.GameOver;
        if (currentMission) gameMissionControl.gameOverMission();
        else gamePlayer.ifMission = false;
        playingPanel.SetActive(false);
        AudioManager.am.togglePauseMusic(true);
        AudioManager.am.playSound("lose");
        GameObject g = Instantiate(gameOverCanvas);
        Canvas c = g.GetComponent<Canvas>();


        //string s = PlayGamesPlatform.Instance.localUser.id;
        //timedMsg("Google Play ID: " +PlayGamesPlatform.Instance.localUser.id);
        //set manually because gameovercanvas is prefab and camera is not
        c.worldCamera = Camera.main;
        c.planeDistance = 8f;
        setCamManualMove(false);
        GC.Collect();

    }

    //sets the highscore and coins on home screen
    public void setHighCoins()
    {
        scoreDisplay.text = "TOP:" + gamePlayer.score;
        coinDisplay.text = "" + gamePlayer.coins;
    }

    //when collecting money / coins  
    //safety in case player goes back to main meny and plays while collecting bought coins, and has coin doubler character
    public void Collect(int amount, bool safety)
    {
        //visual and audio effects
        AudioManager.am.playSound("collect");
        if (!coinGraphic.GetCurrentAnimatorStateInfo(0).IsName("coin_collected")) coinGraphic.SetTrigger("collected");


        if (gameState == gameStates.Playing)
        {
            if (!safety)
            {
                if (playerInfo.moreCoins) amount *= 2;
                coinAmount += amount;
                coinDisplay.text = "" + coinAmount;

            }
        }

        //if came has finished, assume player is recieving coins from completed mission or hourly gift
        else if (gameState == gameStates.GameOver)
        {
            if (!safety)
            {
                if (playerInfo.moreCoins) amount *= 2;
                gamePlayer.coins += amount;
                dataControl.savePlayer(gamePlayer);
                coinDisplay.text = "" + gamePlayer.coins;
            }
        }
        else if (gameState != gameStates.Pause && (gameState == gameStates.avatarMenu || gameState == gameStates.weaponMenu || gameState == gameStates.PrePlay))
        {
            int coinDis = Int32.Parse(coinDisplay.text);
            coinDis += amount;
            coinDisplay.text = "" + coinDis;
        }

    }
    public GameObject[] islands;
    GameObject curIsland;
    //called when the boss dies

    public void initiateBossDeath()
    {
        level++;
        if (level % 2 == 0) enemySpeed++;
        if (level % 3 == 0) proSpeed++;
        //print("initiatingBossDeath");
        //initiates the loading of the new WORLD if enough levels have bee passed
        if (level % 2 == 0)//SUPPOSE TO BE level % 4 == 0 MEANING EVERY 4 LEVELS (if levels are saved)
        {
            jumping = true;
            //GameObject newWorld = Instantiate(islands[rem], new Vector3(4, 5, 7), Quaternion.identity);
            int newI = PlayerPrefs.GetInt(worldKey, defWorldKey) + 1;
            if (newI >= islands.Length) newI = 0;
            PlayerPrefs.SetInt(worldKey, newI);
            GameObject newWorld = Instantiate(islands[newI], new Vector3(7, 7, 0), Quaternion.identity);
            newWorld.transform.localScale = new Vector3(0, 0, 0);
            newWorld.transform.eulerAngles = new Vector3(-30, 0, 0);
            //move_player mp = player.GetComponent<move_player>();
            StartCoroutine(newWorldMove(curIsland.transform, newWorld.transform));
        }
        else finishBossDeath();
    }
    void finishBossDeath()
    {
        projectileMax = 4;
        spawn.resetEnemiesShown();
        //playerHealth.ApplyHeal(1);  //moved to heart reward when boss is defeated
        progressbar.fillAmount = 0f;
        hitsTillBoss = 0;
        bossMode = false;
        progressbar.color = Color.green;
    }
    public IEnumerator newWorldMove(Transform ow, Transform nw)
    {
        Vector3 center = new Vector3(0, 4.5f, playerZPos);
        Vector3 land = new Vector3(0, 0, 0);
        Vector3 fSize = new Vector3(1, 1, 1);
        //Vector3 view3D = new Vector3(-30, 0, 0);
        //Vector3 flyPos = new Vector3(30, 0, 0);

        float speed = 10;
        float nSpeed = 150f;
        do
        {
            //jumping player and rotating
            player.transform.Rotate(Vector3.down * Time.deltaTime * nSpeed);
            player.transform.position = Vector3.MoveTowards(player.transform.position, center, 9 * Time.deltaTime);

            //old world being removed
            ow.Translate((Vector3.left + Vector3.down) * (speed / 1.5f) * Time.deltaTime);
            float t = (.9f * Time.deltaTime);
            float t2 = (.75f * Time.deltaTime);
            ow.localScale = new Vector3(Mathf.Clamp(ow.localScale.x - t, 0, 1), Mathf.Clamp(ow.localScale.y - t, 0, 1), Mathf.Clamp(ow.localScale.z - t, 0, 1));
            ow.rotation = Quaternion.RotateTowards(ow.rotation, nw.rotation, nSpeed * Time.deltaTime * .5f);

            //new world being brought in
            nw.position = Vector3.MoveTowards(nw.position, land, speed * Time.deltaTime);
            nw.localScale = new Vector3(Mathf.Clamp(nw.localScale.x + t2, 0, 1), Mathf.Clamp(nw.localScale.y + t2, 0, 1), Mathf.Clamp(nw.localScale.z + t2, 0, 1));
            yield return null;
        }
        while (nw.position != land || nw.localScale != fSize);
        //rotating the player back to face forward
        //Vector3 relPos = Vector3.zero;
        Quaternion tarRot = Quaternion.identity;
        float ti = Time.time;
        do
        {
            //relPos = //c.position - c.position;
            //tarRot = Quaternion.LookRotation(relPos);
            player.transform.rotation = Quaternion.RotateTowards(player.transform.rotation, tarRot, nSpeed * Time.deltaTime);
            nw.rotation = Quaternion.RotateTowards(nw.rotation, tarRot, nSpeed * Time.deltaTime);
            yield return null;
        } while ((player.transform.rotation != tarRot || nw.rotation != tarRot) && Time.time - ti < 2f);
        player.transform.rotation = Quaternion.identity;
        nw.rotation = tarRot;
        //GameManager.gm.jumpedToNewWorld(nw.gameObject);
        Destroy(curIsland);
        curIsland = nw.gameObject;
        //PlayerPrefs.SetString(worldKey, curIsland.name.Substring(0, curIsland.name.Length - 7));
        finishBossDeath();

        //finishBossDeath();
        jumping = false;
    }
    //adjusting the progress bar to suit
    public void change_progress(bool isBoss, float p)
    {
        if (isBoss)
        {
            if (progressbar.fillAmount > 0) progressbar.fillAmount = p / currentBossLife;
        }
        else
        {
            hitsTillBoss++;
            if (progressbar.fillAmount < 1) progressbar.fillAmount = ((float)hitsTillBoss / (float)totalprogress);
            spawn.editWaveHits(totalprogress);
            score += (int)p;
            scoreDisplay.text = score.ToString();
            if (progressbar.fillAmount >= 1 || hitsTillBoss >= totalprogress)
            {
                //done so that boss wont be loaded while other pojectiles are on the screen
                if (!bossLoading) bossLoading = true;
            }
        }

    }
    //call moved to health_boss class since boss's life may be different to others
    public float prepareForBoss(bool ifSpray, bool ifAuto)
    {
        currentBossLife = totalBossLife;
        if (ifSpray) currentBossLife *= 9;
        if (ifAuto) currentBossLife *= 7;
        projectileMax = 8;
        bossMode = true;
        bossLoading = false;
        progressbar.fillAmount = 1f;
        progressbar.color = Color.red;
        return currentBossLife;
    }
    public GameObject newPowerAnimation;
    //adding powerups to the queue
    public void addPowerUps(GameObject powerUp)
    {
        //if the power ups queue is full
        if (powerUps[2] != null) return;
        //RaycastHit hit;
        // GameObject go = null;
        //checking if power up hasn't been destroyed

        if (powerUp)
        {
            bool found = false;
            for (int i = 0; i < powerUps.Length && !found; i++)
            {
                if (powerUps[i] == null && powerUp)
                {
                    found = true;
                    powerUps[i] = powerUp;
                    if (i == 0) power1Button.interactable = true;
                    powerImages[i].sprite = powerUp.GetComponent<powerUp>().powerUpSprite;
                    powerImages[i].enabled = true;
                    //if canvas is overlay
                    //Physics.Raycast(Camera.main.ScreenPointToRay(powerImages[i - 1].transform.position), out hit);
                    //go = Instantiate(newPowerAnimation, hit.point, Camera.main.transform.rotation) as GameObject;
                    //if canvas is set to camera
                    //go = 
                    Instantiate(newPowerAnimation, powerImages[i].transform.position, newPowerAnimation.transform.rotation);
                    AudioManager.am.playSound("power");
                }
            }
        }
    }
    //activating the power up
    [HideInInspector]
    public powerUp activePowerUp;
    public void activatePower()
    {
        if (power1Button.interactable)
        {
            power1Button.interactable = false;

            GameObject g = Instantiate(powerUps[0]) as GameObject;

            activePowerUp = g.GetComponent<powerUp>();

            activePowerUp.activeOn();

            powerActive = activePowerUp.powerName;


            //if there is a mission that involves powerups
            if (currentMission)
            {
                if (currentMission.missionAlias == mission.missionType.usePowerUp)
                    currentMission.progressMission(1, Vector3.zero, Quaternion.identity);

                else if (currentMission.missionAlias2 == mission.missionType2.usePowerUp)
                    currentMission.progressMission(-1, Vector3.zero, Quaternion.identity);

                //function for dont miss, to patch glitch
                else if (currentMission.missionAlias2 == mission.missionType2.dontMiss)
                    ((mission_dontMiss)currentMission).pausePowerFun();
            }
        }
    }
    //end and discarding of the used powerup
    public void deactivatePower()
    {
        //changes the power back to nothing
        powerActive = powerUp.powerType.none;// poweruptypes.none;
        activePowerUp = null;

        int i = 0;
        //bool con = true;
        do
        {
            if (i == 0) powerImages[i].fillAmount = 1;//
            //assumes that there are more power ups since it loops past first time
            else
            {
                int j = i - 1;
                powerUps[j] = powerUps[i];
                powerImages[j].sprite = powerUps[j].GetComponent<powerUp>().powerUpSprite;
                powerImages[j].enabled = true;
                if (i == 1) power1Button.interactable = true;
            }

            powerUps[i] = null;
            powerImages[i].sprite = null;
            powerImages[i].enabled = false;
            i += 1;
            //if (powerUps[i] == null) con = false;
        }
        while (i < powerUps.Length && powerUps[i] != null);
    }

    public void OnApplicationQuit()
    {
#if UNITY_WSA
        androidPlay.
#endif
    }

    ///STATICLY SETS AVATARS NAMES, IF NEW AVATARS ARE ADDED, ADD NAMES HERE
    public enum avatars { avatar_playerDefault, avatar_fighter, avatar_nimbleFighter, avatar_ninja, avatar_riotCop, avatar_samurai, avatar_soldier }

    ///STATICLY SETS WEAPONS NAMES, IF NEW WEAPONS ARE ADDED, ADD NAMES HERE
    public enum weapons
    {
        weapon_revolver, weapon_pistols, weapon_shotgun, weapon_smg,
        weapon_biggerRevolver, /*weapon_biggerShotgun,*/weapon_dualShotgun, weapon_semiAutoPistols, 
        weapon_flameGun,/* weapon_freezeGun,*/ weapon_handCannons, weapon_laserGun,
        /*weapon_lighteningGun,*/
        weapon_soundGun, /*weapon_electroArms, weapon_blueFlame,*/
        //weapon_dev_defence
    };

}
