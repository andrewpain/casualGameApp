﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class move_boss3_dash : move_boss
{

    //private bool turn = false;
    // Use this for initialization
    //public override void Start () {
    bool visible = true;
    bool dashing = false;
    public float dashTime = 4f;
    float timeStart = 0;
    public bool shooting = true;


    //MeshRenderer mr;
    BoxCollider bc;
    Animator an;
    Vector3 tPos;
    Vector3 minRange;
    Vector3 maxRange;
    //}
    public override void startPoints()
    {
        //mr = gameObject.GetComponent<MeshRenderer>();
        bc = gameObject.GetComponent<BoxCollider>();
        an = gameObject.GetComponent<Animator>();

        minRange = GameManager.gm.MinRange;
        maxRange = GameManager.gm.MaxRange;

        //randomPos();
        float randomx = UnityEngine.Random.Range(minRange.x +1 + (transform.lossyScale.x / 2), maxRange.x -1- (transform.lossyScale.x / 2));//middle
        float randomy = UnityEngine.Random.Range(minRange.y /*+ 2*/ + (transform.lossyScale.y / 2), maxRange.y -1- (transform.lossyScale.y / 2));//middle
                                                                                                                                                 //float randomz = /*maxRange.z - 1;*/ 0f;// closer to player than where enemies usually spawn

        //TESTING FOR 3D GAME
        //float randomz = minRange.z;
        float randomz = minRange.z - (transform.lossyScale.z / 2);

        transform.position = new Vector3(randomx, randomy, randomz);

        timeStart = Time.time;
    }
    void randomPos()
    {
        float randomx = UnityEngine.Random.Range(minRange.x + (transform.lossyScale.x / 2)+.5f, maxRange.x - (transform.lossyScale.x / 2)-.5f);//middle
        float randomy = UnityEngine.Random.Range(minRange.y + 2 + (transform.lossyScale.y / 2), maxRange.y - (transform.lossyScale.y / 2)-.75f);//middle
        //float randomz = maxRange.z - 1; //0f;// closer to player than where enemies usually spawn

        //transform.position = new Vector3(randomx, randomy, randomz);
        tPos = new Vector3(randomx, randomy, transform.position.z);
    }
    void dashNow()
    {
        visible = false;
        //QUEUE DISAPPEAR ANIMATION
        //mr.enabled = false;
        bc.enabled = false;
    }

    protected override void calMove()
    {
        //if boss is visible and shooting and time for shoting is not up
        if (visible && shooting && (Time.time - timeStart) >= 15f)
        {
            //if (shooting && !IsInvoking("disappearNow"))
            //{
			an.SetTrigger("idle");
            shooting = false;
            timeStart = Time.time;
            //print("shooting stopped");
            //Invoke("disappearNow", 5);
            //}
        }
        //visible but not shooting and not dashing about yet but time for dashing has begun
        else if (visible && !shooting && !dashing && (Time.time - timeStart) >= 5f)
        {
            an.SetTrigger("dash");
            randomPos();
            timeStart = Time.time;
            dashing = true;
            //QUEUE ANIMATION WHICH THEN TRIGGERS THE DISAPPEARNOW METHOD
            //print("darting");
        }
        //if mini sized and dshing now
        else if (dashing)
        {
            transform.position = Vector3.MoveTowards(transform.position, tPos, Time.deltaTime * speed);
            if (Vector3.Distance(transform.position,tPos)<.5f) randomPos();//TO TEST
            if ((Time.time - timeStart) >= dashTime)
            {
                an.SetTrigger("stay");
                dashing = false;
                visible = true;
                shooting = true;
                timeStart = Time.time;
                bc.enabled = true;
            }
        }


    }
}
