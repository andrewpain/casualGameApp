﻿//using System.Collections;
//using System.Collections.Generic;
//using System;
using UnityEngine;
// #if !UNITY_WSA// || UNITY_EDITOR
// using UnityEngine.Purchasing;
// #endif

public class IAPManager : IAPParent
// #if !UNITY_WSA
    // , IStoreListener
// #endif
{

// #if !UNITY_WSA// || UNITY_EDITOR    
    // private static IStoreController m_StoreController;          // The Unity Purchasing system.
    // private static IExtensionProvider m_StoreExtensionProvider; // The store-specific Purchasing subsystems.
// #endif

    // // specific mapping to Unity Purchasing's AddProduct, below.

    // // Apple App Store-specific product identifier for the subscription product.
    // //private static string kProductNameAppleSubscription = "com.unity3d.subscription.new";

    // // Google Play Store-specific product identifier subscription product.
    // //private static string kProductNameGooglePlaySubscription = "com.unity3d.subscription.original";

    // public override void Start()
    // {
        // base.Start();


// #if !UNITY_WSA
        // // If we haven't set up the Unity Purchasing reference
        // if (m_StoreController == null)
        // {
            // // Begin to configure our connection to Purchasing
            // InitializePurchasing();
        // }
// #endif
    // }

    public override void InitializePurchasing()
    {
        // If we have already connected to Purchasing ...
        // if (IsInitialized())
        // {
            // // ... we are done here.
            // return;
        // }
// #if !UNITY_WSA// || UNITY_EDITOR
        // // Create a builder, first passing in a suite of Unity provided stores.
        // var builder = ConfigurationBuilder.Instance(StandardPurchasingModule.Instance());

        // ///ONLY FOR TESTING, REMOVE FOR FINAL PRODUCTION
        // //builder.Configure<IMicrosoftConfiguration>().useMockBillingSystem = true;

        // builder.AddProduct(product_250_Gold, ProductType.Consumable);
        // builder.AddProduct(product_1000_Gold, ProductType.Consumable);
        // builder.AddProduct(product_5000_Gold, ProductType.Consumable);
        // builder.AddProduct(product_20000_Gold, ProductType.Consumable);

        // // And finish adding the subscription product. Notice this uses store-specific IDs, illustrating
        // // if the Product ID was configured differently between Apple and Google stores. Also note that
        // // one uses the general kProductIDSubscription handle inside the game - the store-specific IDs 
        // // must only be referenced here. 
        // //builder.AddProduct("testingProduct", ProductType.Subscription, new IDs(){
        // //{ "testProductWindows", GooglePlay.Name },
        // //{ "testingProductGoogle", WindowsStore.Name },
        // //});

        // // Kick off the remainder of the set-up with an asynchrounous call, passing the configuration 
        // // and this class' instance. Expect a response either in OnInitialized or OnInitializeFailed.
        // UnityPurchasing.Initialize(this, builder);
// #endif
    }


    public override bool IsInitialized()
    {
// #if !UNITY_WSA// || UNITY_EDITOR
        // // Only say we are initialized if both the Purchasing references are set.
        // return m_StoreController != null && m_StoreExtensionProvider != null;
// #else
        // return false;
// #endif
return false;
    }

    



    public override void BuyProductID(string productId)
    {
        // If Purchasing has been initialized ...
        // if (IsInitialized())
        // {
            // // ... look up the Product reference with the general product identifier and the Purchasing 
            // // system's products collection.
// #if !UNITY_WSA// || UNITY_EDITOR
            // Product product = m_StoreController.products.WithID(productId);

            // // If the look up found a product for this device's store and that product is ready to be sold ... 
            // if (product != null && product.availableToPurchase)
            // {
                // Debug.Log(string.Format("Purchasing product asychronously: '{0}'", product.definition.id));
                // // ... buy the product. Expect a response either through ProcessPurchase or OnPurchaseFailed 
                // // asynchronously.
                // m_StoreController.InitiatePurchase(product);
            // }
            // // Otherwise ...
            // else
            // {
                // // ... report the product look-up failure situation  
                // Debug.Log("BuyProductID: FAIL. Not purchasing product, either is not found or is not available for purchase");
				// processing = false;
				// GameManager.gm.timedMsg("BuyProductID: FAIL. Not purchasing product, either is not found or is not available for purchase");
            // }
// #endif
        // }
        // // Otherwise ...
        // else
        // {
            // // ... report the fact Purchasing has not succeeded initializing yet. Consider waiting longer or 
            // // retrying initiailization.
			// processing = false;

            // Debug.Log("BuyProductID FAIL. Not initialized.");
			// GameManager.gm.timedMsg("Buy Product FAIL. Not initialized.");
        // }
    }


    // Restore purchases previously made by this customer. Some platforms automatically restore purchases, like Google. 
    // Apple currently requires explicit purchase restoration for IAP, conditionally displaying a password prompt.
    //public void RestorePurchases()
    //{
    //    // If Purchasing has not yet been set up ...
    //    if (!IsInitialized())
    //    {
    //        // ... report the situation and stop restoring. Consider either waiting longer, or retrying initialization.
    //        Debug.Log("RestorePurchases FAIL. Not initialized.");
    //        return;
    //    }

    //    // If we are running on an Apple device ... 
    //    if (Application.platform == RuntimePlatform.IPhonePlayer ||
    //        Application.platform == RuntimePlatform.OSXPlayer)
    //    {
    //        // ... begin restoring purchases
    //        Debug.Log("RestorePurchases started ...");

    //        // Fetch the Apple store-specific subsystem.
    //        var apple = m_StoreExtensionProvider.GetExtension<IAppleExtensions>();
    //        // Begin the asynchronous process of restoring purchases. Expect a confirmation response in 
    //        // the Action<bool> below, and ProcessPurchase if there are previously purchased products to restore.
    //        apple.RestoreTransactions((result) => {
    //            // The first phase of restoration. If no more responses are received on ProcessPurchase then 
    //            // no purchases are available to be restored.
    //            Debug.Log("RestorePurchases continuing: " + result + ". If no further messages, no purchases available to restore.");
    //        });
    //    }
    //    // Otherwise ...
    //    else
    //    {
    //        // We are not running on an Apple device. No work is necessary to restore purchases.
    //        Debug.Log("RestorePurchases FAIL. Not supported on this platform. Current = " + Application.platform);
    //    }
    //}

// #if !UNITY_WSA// || UNITY_EDITOR
    // public void OnInitialized(IStoreController controller, IExtensionProvider extensions)
    // {
        // // Purchasing has succeeded initializing. Collect our Purchasing references.
        // Debug.Log("OnInitialized: PASS");

        // // Overall Purchasing system, configured with products for this application.
        // m_StoreController = controller;
        // // Store specific subsystem, for accessing device-specific store features.
        // m_StoreExtensionProvider = extensions;
        // initialized = true;
    // }


    // public void OnInitializeFailed(InitializationFailureReason error)
    // {
        // // Purchasing set-up has not succeeded. Check error for reason. Consider sharing this reason with the user.
        // Debug.Log("OnInitializeFailed InitializationFailureReason:" + error);
    // }


    // public PurchaseProcessingResult ProcessPurchase(PurchaseEventArgs args)
    // {
        // bool done = false;
        // int collect = 0;
        // if (String.Equals(args.purchasedProduct.definition.id, product_250_Gold, StringComparison.Ordinal))
        // {
            // Debug.Log(string.Format("ProcessPurchase: PASS. Product: '{0}'", args.purchasedProduct.definition.id));
            // collect = 250;
            // done = true;
        // }
         // else if (String.Equals(args.purchasedProduct.definition.id, product_1000_Gold, StringComparison.Ordinal))
         // {
             // Debug.Log(string.Format("ProcessPurchase: PASS. Product: '{0}'", args.purchasedProduct.definition.id));
             // collect = 1000;
             // done = true;
         // }
         // else if (String.Equals(args.purchasedProduct.definition.id, product_5000_Gold, StringComparison.Ordinal))
         // {
             // Debug.Log(string.Format("ProcessPurchase: PASS. Product: '{0}'", args.purchasedProduct.definition.id));
             // collect = 5000;
             // done = true;
         // }
         // else if (String.Equals(args.purchasedProduct.definition.id, product_20000_Gold, StringComparison.Ordinal))
         // {
             // Debug.Log(string.Format("ProcessPurchase: PASS. Product: '{0}'", args.purchasedProduct.definition.id));
             // collect = 20000;
             // done = true;
         // }
        // // Or ... an unknown product has been purchased by this user. Fill in additional products here....
        // else 
		// {
			// GameManager.gm.timedMsg(string.Format("ProcessPurchase: FAIL. Unrecognized product: '{0}'", args.purchasedProduct.definition.id));
			// Debug.Log(string.Format("ProcessPurchase: FAIL. Unrecognized product: '{0}'", args.purchasedProduct.definition.id));
		// }

        // finishPurchase(done,collect);
        
        
        // // Return a flag indicating whether this product has completely been received, or if the application needs 
        // // to be reminded of this purchase at next app launch. Use PurchaseProcessingResult.Pending when still 
        // // saving purchased products to the cloud, and when that save is delayed. 
        // return PurchaseProcessingResult.Complete;
    // }


    // public void OnPurchaseFailed(Product product, PurchaseFailureReason failureReason)
    // {
        // // A product purchase attempt did not succeed. Check failureReason for more detail. Consider sharing 
        // // this reason with the user to guide their troubleshooting actions.
        // Debug.Log(string.Format("OnPurchaseFailed: FAIL. Product: '{0}', PurchaseFailureReason: {1}", product.definition.storeSpecificId, failureReason));
        // GameManager.gm.timedMsg(string.Format("Purchase of product failed because {0}", /*product.definition.storeSpecificId,*/ failureReason));
        // processing = false;

    // }
// #endif

}

