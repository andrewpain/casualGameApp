﻿//using UnityEngine;
//using System.Collections;
using System;

public class Health_Suicide : Health
{
    //for exclaim mark that is not destroyable
    public bool isDestroyable = true;
    public override void ApplyDamage(float amount)
    {
        if (isAlive && isDestroyable)
        {
            isAlive = false;
            //if mission exists
            if (GameManager.gm && GameManager.gm.currentMission && GameManager.gm.currentMission.missionAlias == mission.missionType.hitLaser)
            {
                move_projectile_laserBombMaker r = gameObject.GetComponent<move_projectile_laserBombMaker>();
                //this determines if the laser was increased in rotating, thus about to shoot
                if (r && r.rotated) GameManager.gm.currentMission.progressMission(1, transform.position, transform.rotation);
            }
            //AudioManager.am.stopSound("missileWarning");

                activateExplosion();
        }
    }

}
