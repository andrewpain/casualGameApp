﻿using UnityEngine;
//using System.Collections;

public class move_bothaxis_topLeft_bottomRight : movement
{

    public override void startPoints()
    {
        Vector3 minrange = GameManager.gm.MinRange;
        Vector3 maxrange = GameManager.gm.MaxRange;
        
        float randomx = minrange.x + (transform.lossyScale.x / 2);
        float randomy = maxrange.y - (transform.lossyScale.y / 2);
        float randomz = Random.Range(minrange.z + (transform.lossyScale.z / 2), maxrange.z - (transform.lossyScale.z / 2));
		if (minrange.z==maxrange.z) randomz =  maxrange.z;//TESTING FOR 2D GAME - (transform.lossyScale.z / 2);

        transform.position = new Vector3(randomx, randomy, randomz);
    }

    protected override void calMove()
    {
        gameObject.transform.Translate(transform.right * Time.deltaTime * speed);
        gameObject.transform.Translate(Vector3.down * Time.deltaTime * (speed / 2));
    }

    protected override bool ifBeyondBorders()
    {
        return
            transform.position.x + (transform.lossyScale.x / 2) >= GameManager.gm.MaxRange.x ||
            transform.position.y - (transform.lossyScale.y / 2) <= .5f;
    }
}
