﻿using UnityEngine;
//using System.Collections;

public class powerup_slowMotion : powerUp {

    public float reduceTo = .3f;
    public GameObject slowAnimation;
    private GameObject[] allenemies;
    private GameObject[] allprojectiles;
	private ParticleSystem ps;

    public override void activeOn()
    {
        GameObject sa = Instantiate(slowAnimation) as GameObject;
		ps = sa.GetComponent<ParticleSystem>();
        ParticleSystem.ShapeModule sm = ps.shape;
        sm.scale = new Vector3(GameManager.gm.border*2, sm.scale.y, sm.scale.z);
        timeActive = timeActive * reduceTo;
        Time.timeScale = reduceTo;
        Time.fixedDeltaTime = Time.timeScale * .02f;
        AudioManager.am.slowDownAudio();
        //AudioManager.am.
        base.activeOn();        
    }

    public override void activeOff()
    {
        Time.timeScale = 1f;
        Time.fixedDeltaTime = Time.timeScale * .02f;
        AudioManager.am.slowDownAudio();
        ParticleSystem.MainModule psm = ps.main;
        psm.loop = false;
        base.activeOff();
    }

}
