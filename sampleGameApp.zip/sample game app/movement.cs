﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public abstract class movement : MonoBehaviour
{
    //DIFFERENT WAYS TO MOVE
    //transform.position += Vector3.up/*transform.forward*/ * speed * Time.deltaTime;
    //gameObject.transform.Translate(Vector3.forward* Time.deltaTime* speed);
    public float speed = 0f;
    
    [HideInInspector]
    public bool leaving = false;
    // Use this for initialization
    public virtual void Start()
    {
        if (GameManager.gm)
        {
            //TESTING FOR 2D GAME
            //speed = GameManager.gm.enemySpeed + GameManager.gm.spawn.wave * .5f;	
            //random speeds seems to be alright for now

            //if wave and enemy speed numbers are true
            if (GameManager.gm.enemySpeed == GameManager.gm.spawn.wave)
                speed = Random.Range(GameManager.gm.enemySpeed + .25f, GameManager.gm.spawn.wave +.75f);// * .5f;
            //if speed is more than wave
            else if (GameManager.gm.enemySpeed >GameManager.gm.spawn.wave)
                speed = Random.Range((float)GameManager.gm.spawn.wave, GameManager.gm.enemySpeed);// * .5f;
            //if wave is more than speed
            else if (GameManager.gm.spawn.wave > GameManager.gm.enemySpeed)
                speed = Random.Range((float)GameManager.gm.enemySpeed, GameManager.gm.spawn.wave);// * .5f;
            //control for bomb in case it is too slow
            if (gameObject.name.Contains("Bomb") && speed<1.5f) speed = 1.5f;

			//print("SPEED: "+ speed);
            if (speed > 5f) speed = 5f;
            else if (speed < 1) speed = 1f;

           
        }
        //else if (!gameObject.name.Contains("boss")) speed = 3f;
        startPoints();
    }
    //does general movement of almost all objects in game
    protected virtual void FixedUpdate()
    {
        if (GameManager.gm && GameManager.gm.gameState == GameManager.gameStates.Playing) calMove();
        //print("regular move");
    }
    //calculates the particular movement per child class
    protected abstract void calMove();
    public abstract void startPoints();
    protected abstract bool ifBeyondBorders();

    protected virtual void OnTriggerEnter(Collider other)
    {
        doOutsideCheck();
    }
    protected virtual void OnTriggerStay(Collider other)
    {
        doOutsideCheck();
    }
    protected virtual void OnBecameInvisible()
    {
        doOutsideCheck();
    }

    //{
    //    return GameManager.gm && ( pastXBorder() ||
    //transform.position.y + (transform.lossyScale.y / 2) >= GameManager.gm.MaxRange.y ||
    //transform.position.y - (transform.lossyScale.y / 2) <= .5f);
    //}
    //player uses this when moving to determine if borders are met
    //protected virtual bool pastXBorder()
    //{
    //    return
    //        transform.position.x + (transform.lossyScale.x / 2) >= GameManager.gm.MaxRange.x ||
    //        transform.position.x - (transform.lossyScale.x / 2) <= GameManager.gm.MinRange.x;
    //}
    protected void doOutsideCheck()
    {
        if (!leaving && ifBeyondBorders())
        {
            leave();
        }
    }
    //to accomodate move projectile when creating explosion when hitting ground
    protected void leave()
    {
        leaving = true;
        if (GameManager.gm.playerInfo.lessSuicide && tag == "Enemy_projectile")
        {
            try
            {
                move_projectile mp = (move_projectile)this;
                mp.destroyFakeTarget();
            }
            catch (System.InvalidCastException) { }
        }


        Animator a = gameObject.GetComponent<Animator>();
        if (a != null)
        {
            if (!a.GetCurrentAnimatorStateInfo(0).IsName("enemy_exit"))
                a.SetTrigger("exit");
        }
        else if (gameObject)Destroy(gameObject);
    }
}
