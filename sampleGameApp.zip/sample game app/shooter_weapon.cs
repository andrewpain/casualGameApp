﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class shooter_weapon : MonoBehaviour
{

    [Header("General")]
    public GameObject projectile;
    //public GameObject autoAimPro;
    public GameObject hitParticle;
    public GameObject muzzleFlash;
    public Sprite crosshair;
    public bool hasUsedShell = false;

    public AudioSource shotAudioSource;
    //string audioName = "sound effect name here";
    bool isSfxOn = false;

    [Tooltip("Only applies if 'isAuto' is true! This indicates if the weapon's shot audio fades in and out")]
    public bool audioFade = false;

    [HideInInspector]//[Header("Damage")]
    public float damage = 1f;

    [HideInInspector]//[Header("Dual Weapon")]
    public bool isDual = false;
    private int leftRight = 0;

    //if has a spread/spray of projectiles
    [HideInInspector]//[Header("Spray")]
    public bool isSpray = false;
    [HideInInspector]
    public float spray = 1f;

    [HideInInspector]//[Header("Automatic")]
    public bool isAuto = false;

    [HideInInspector]
    public float fireRate = .5f;

    //[Header("Seen Projectile and hit")]
    //public bool isRegPro = false;
    //public bool projectileCausesDamage = false;
    //public float speed = 200f;

    [Header("Particle Projectile")]
    public bool isParticle = false;

    [Header("Line Projectile")]
    public bool isLine = false;
    [Tooltip("isLine variable must be true for this to be checked and validated in code")]
    public bool isLightning = false;

    //public enum projectileType {none, particle, line, regProjectile};
    //public projectileType typeOfProjectile = projectileType.none;
    private bool isTouch;

    GameObject time2;
    GameObject time3;
    GameObject time4;
    GameObject dualHit;

    Vector3 pos = new Vector3();

    weaponProperties[] LOrRWeapons;

    //Quaternion []origRot;
    //public GameObject lineObject;
    //LineRenderer[] lines = new LineRenderer[9];
    // Use this for initialization

    void Start()
    {
        if (!Input.touchSupported) isTouch = false;
        else if (Input.touchSupported && isDual) isTouch = true;

            LOrRWeapons = new weaponProperties[2];
        
        //gets first/right weapon's information
        GameManager.gm.crossHair.gameObject.GetComponent<Image>().sprite = crosshair;
        LOrRWeapons[0] = new weaponProperties();
        LOrRWeapons[0].weaponGameObject = transform.GetChild(0).gameObject;//ASSUMING FIRST GAMEOBJECT IS RIGHT HAND WEAPON
        LOrRWeapons[0].weaponCrosshairControl = GameManager.gm.crossHair.gameObject.GetComponent<crosshairControl>();
        if (isAuto) LOrRWeapons[0].fireRate = fireRate;
        //LOrRWeapons[0].shotSFX = transform.GetChild(0).GetComponent<AudioSource>();
        //gets left weapon's information
        if (isDual && GameManager.gm.crossHair2)
        {
            GameManager.gm.crossHair2.gameObject.GetComponent<Image>().sprite = crosshair;
            LOrRWeapons[1] = new weaponProperties();
            LOrRWeapons[1].weaponGameObject = transform.GetChild(1).gameObject;//ASSUMING SECOND GAMEOBJECT IS LEFT HAND WEAPON
            LOrRWeapons[1].weaponCrosshairControl = GameManager.gm.crossHair2.gameObject.GetComponent<crosshairControl>();
            if (isAuto) LOrRWeapons[1].fireRate = fireRate;
            //LOrRWeapons[1].shotSFX = transform.GetChild(1).GetComponent<AudioSource>();

        }

        time2 = Resources.Load("multi/times2Particle", typeof(GameObject)) as GameObject;
        time3 = Resources.Load("multi/times3Particle", typeof(GameObject)) as GameObject;
        time4 = Resources.Load("multi/times4Particle", typeof(GameObject)) as GameObject;
        dualHit = Resources.Load("multi/dualHitParticle", typeof(GameObject)) as GameObject;

        //origRot = LOrRWeapons[0].weaponGameObject.transform.rotation;
        //StartCoroutine(createLines());
    }
    //called when player is jumping to new world
    //public void jumpReady()
    //{

    //}

    //IEnumerator createLines()
    //{
    //    for (int i = 0; i < 9; i++)
    //    {
    //        GameObject l = Instantiate(lineObject);
    //        lines[i] = l.GetComponent<LineRenderer>();
    //        yield return null;
    //    }
    //    print("lines created");
    //}
    public void setMuzzleFlash()
    {
        if (isTouch) Input.multiTouchEnabled = true;
        int lrw = LOrRWeapons.Length;

        //use this or put in code that checks if audio is set to on and use audio like it currently is
        //shotAudioSource = gameObject.GetComponent<AudioSource>();
        if (shotAudioSource && AudioManager.sfxEnabled) isSfxOn = true;
		else if (shotAudioSource) Destroy(shotAudioSource);

        //foreach (weaponProperties wp in LOrRWeapons)
        for (int i =0;i<lrw;i++)
        {
            weaponProperties wp = LOrRWeapons[i];
            if (wp != null)
            {
                //create new muzzle flash 
                if (muzzleFlash)
                {
                    wp.weaponMuzzleFlash = Instantiate(muzzleFlash);
                    //making the muzzle flash a child
                    wp.weaponMuzzleFlash.transform.parent = wp.weaponGameObject.gameObject.transform;
                    wp.weaponMuzzleFlash.transform.localScale = new Vector3(1, 1, 1);
                    //setting the muzzle flash position + rotation
                    wp.weaponMuzzleFlash.transform.position = wp.weaponGameObject.transform.position + wp.weaponGameObject.transform.forward;
                    wp.weaponMuzzleFlash.transform.rotation = wp.weaponGameObject.transform.rotation;
                }
                //get muzzle flash if already exists
                else wp.weaponMuzzleFlash = gameObject.transform.GetChild(i).GetChild(1).gameObject;
                wp.weaponMuzzleFlash.SetActive(false);
                wp.muzzleAni = wp.weaponMuzzleFlash.GetComponent<ParticleSystem>().main;

                //if there is the shell animation
                if (hasUsedShell/*gameObject.transform.GetChild(0).childCount>1*/)
                {
                    //STATIC location of particle system
                    wp.weaponUsedShell = gameObject.transform.GetChild(i).GetChild(0).gameObject;
                    wp.usedShell = wp.weaponUsedShell.GetComponent<ParticleSystem>().main;
                }
                //setting the hit particles
                int hitNo;
                if (isSpray) hitNo = 9;
                else hitNo = 1;
                wp.setHitParticles(hitNo, hitParticle);

            }

        }
        if (isParticle)
        {
            int p = 0;
            foreach (weaponProperties wp in LOrRWeapons)
            {
                if (wp != null)
                {
                    wp.weaponProjectile = Instantiate(projectile);
                    wp.weaponProjectile.transform.position = transform.GetChild(p).position + transform.GetChild(p).forward;
                    wp.weaponProjectile.transform.rotation = transform.GetChild(p).rotation;
                    wp.weaponProjectile.transform.parent = transform.GetChild(p);
                    wp.weaponProjectile.transform.localScale = new Vector3(1, 1, 1);

                    wp.weaponProjectile.SetActive(false);
                    wp.weaponPsm = wp.weaponProjectile.GetComponent<ParticleSystem>().main;
                    p++;
                }
            }
        }
        else if (isLine)
        {
            int q = 0;
            foreach (weaponProperties wp in LOrRWeapons)
            {
                if (wp != null)
                {
                    wp.weaponProjectile = Instantiate(projectile);
                    wp.weaponProjectile.transform.position = transform.GetChild(q).position + transform.GetChild(q).forward;
                    wp.weaponProjectile.transform.rotation = transform.GetChild(q).rotation;
                    if (!isLightning)
                    {
                        wp.weaponProjectile.SetActive(false);
                        wp.weaponLr = wp.weaponProjectile.GetComponent<LineRenderer>();
                    }
                    else wp.weaponLb = wp.weaponProjectile.GetComponent<lightningBolt>();
                    wp.weaponProjectile.transform.parent = transform.GetChild(q);
                    wp.weaponProjectile.transform.localScale = new Vector3(1, 1, 1);

                    q++;
                }
            }
        }
        //else if (isRegPro)
        //{
        //    foreach (weaponProperties wp in LOrRWeapons)
        //        if (wp != null) wp.weaponProjectile = projectile;
        //}
    }
    private void Update()
    {
        if (GameManager.gm && GameManager.gm.gameState == GameManager.gameStates.Playing)
        {

            if ((Input.GetButtonDown("Fire1")
#if UNITY_WSA
                || (Input.GetAxis("Fire1") > 0/*|| Input.GetAxis("Fire2") > 0*/)
#endif
                )
                && busy == null)
            {
                busy = StartCoroutine(busyShooting());
            }
            Cursor c = new Cursor();

#if UNITY_WSA
            if (GameManager.ifJoyStick)
            {
                if (Input.GetAxis("MouseX") != 0f || Input.GetAxis("MouseY") != 0f)
                {
                    Vector3 cursorPos = new Vector3();
                    cursorPos.x = Input.GetAxis("MouseX") * Time.unscaledDeltaTime * 700;
                    cursorPos.y = -Input.GetAxis("MouseY") * Time.unscaledDeltaTime * 700;
                    //put crosshair info here
                    LOrRWeapons[leftRight].weaponCrosshairControl.setCrossHair(cursorPos);

                }
                //if ( isDual && ( Input.GetAxis("MouseDX") != 0f || Input.GetAxis("MouseDY") != 0f))
                //{
                //    Vector3 cursorPos = new Vector3();
                //    cursorPos.x = Input.GetAxis("MouseDX") * Time.unscaledDeltaTime * 600;
                //    cursorPos.y = Input.GetAxis("MouseDY") * Time.unscaledDeltaTime * 600;
                //    //put crosshair info here
                //    LOrRWeapons[1].weaponCrosshairControl.setCrossHair(cursorPos);

                //}

            }
#endif
        }

        //to avoid shooting when returning from the pause state
        else if (LOrRWeapons != null && GameManager.gm && GameManager.gm.gameState != GameManager.gameStates.PrePlay && GameManager.gm.gameState != GameManager.gameStates.GameOver)
        {
            endShooting(0);
            if (isDual) endShooting(1);
        }


        
    }
    Coroutine busy;
    IEnumerator busyShooting()
    {

        LOrRWeapons[0].shooting = true;
        if (isDual) LOrRWeapons[1].shooting = true;
        //bool oneTime = true;
        //does while the user is pressing on the screenn/clicking
        do
        {
            int tTotal = 0;
            if (isTouch) tTotal = Input.touchCount;
            int tCount = 0;
            int dHit = 0;
            //do while is dual weapon and more than one touch exists
            do
            {
                
                //print("do while less than 2 shots if dual shot");
                Vector3 loc;
                if (isTouch) loc = Input.GetTouch(tCount).position;
#if UNITY_WSA
                else if (GameManager.ifJoyStick) loc = LOrRWeapons[leftRight].weaponCrosshairControl.transform.position;
#endif
                else loc = Input.mousePosition;

                //Here is a check which detects the position of the click/touch, and tests if on the left or right of the screen
                //This is done if the weapon is dual, and shoots if poistion if left/right and weapon is weilded on the left/right

                if (isDual)
                {
                    //STATICALLY PROGRAMMED IN THE POSITION OF THE CENTER OF THE SCREEN
                    //if right side of screen
                    //if (loc.x >= Screen.width / 2)
                    if (Camera.main.ScreenToWorldPoint(loc).x >= transform.position.x)
                    {
                        leftRight = 0;// true;
                        if (isAuto)
                        {
                            LOrRWeapons[leftRight].shooting = true;
                            if (LOrRWeapons[1].muzzleAni.loop) LOrRWeapons[1].stopMuzzleFlash();
                            LOrRWeapons[1].setHitPosOff();
                        }
                        if (tTotal < 2 && (isLine || isParticle) && LOrRWeapons[1].weaponProjectile.activeSelf) endShooting(1);
                    }
                    //if left side of the screen
                    else// if (loc.x < Screen.width / 2)
                    {
                        leftRight = 1;//true;
                        if (isAuto)
                        {
                            LOrRWeapons[leftRight].shooting = true;
                            if (LOrRWeapons[0].muzzleAni.loop) LOrRWeapons[0].stopMuzzleFlash();
                            LOrRWeapons[0].setHitPosOff();
                        }
                        if (tTotal < 2 && (isLine || isParticle) && LOrRWeapons[0].weaponProjectile.activeSelf) endShooting(0);
                    }
                }

                if (isAuto && GameManager.powerActive != powerUp.powerType.auto)
                {
#if !UNITY_WSA
                    LOrRWeapons[leftRight].weaponCrosshairControl.enableCrosshair(loc, isAuto);
#else
                    if(GameManager.ifJoyStick) LOrRWeapons[leftRight].weaponCrosshairControl.enableCrosshair(loc, isAuto);
#endif
                }
                //checking for if the shooting in auto is valid and the dual weapons are valid as well 
                if (isAuto && LOrRWeapons[leftRight].shooting && (LOrRWeapons[leftRight].timePast() && GameManager.powerActive != powerUp.powerType.auto || GameManager.powerActive == powerUp.powerType.auto && ((powerup_rapidRage)GameManager.gm.activePowerUp).timePast()) || !isAuto && LOrRWeapons[leftRight].shooting)
                {

                    if (!isAuto)
                    {
                        //to accomodate dual touches
                        LOrRWeapons[leftRight].shooting = false;
                        if (GameManager.powerActive != powerUp.powerType.auto)
                        {
#if !UNITY_WSA
                            LOrRWeapons[leftRight].weaponCrosshairControl.enableCrosshair(loc, isAuto);
#else
                            if (GameManager.ifJoyStick)LOrRWeapons[leftRight].weaponCrosshairControl.enableCrosshair(loc, isAuto);
#endif
                        }
                        if (isSfxOn)
                        {
                            if (shotAudioSource.isPlaying) shotAudioSource.Stop();
                            shotAudioSource.Play();
                        }
                    }
                    else if (isSfxOn && !shotAudioSource.loop)
                    {
                        shotAudioSource.loop = true;
                        shotAudioSource.Play();
                        if (audioFade)
                        {
                            if (fadeNow!=null)StopCoroutine(fadeNow);
                            fadeNow = StartCoroutine(fadeInOutAudio(true));
                        }
                    }
                    //calculates where the pointer has clicked
                    Ray ray = Camera.main.ScreenPointToRay(loc);
                    //IT WORKS, BUT TO FIX CURRENT ISSUE, WOULD HAVE TO MOVE TO POSITION WHERE I CHECK FOR WEAPON BEING LEFT/RIGHT, POS1
                    RaycastHit hit;
                    //if projectile isn't null and pointer has a point clicked at
                    if (Physics.Raycast(ray, out hit))
                    {
                        if (hit.transform.gameObject.tag == "Player")  break;

                        LOrRWeapons[leftRight].weaponGameObject.transform.LookAt(hit.point);
                        LOrRWeapons[leftRight].setMuzzlePosition(isAuto);

                        //created for the sake of the dont miss mission
                        int mHit = 0;
                        bool mIfHit = false;
                        if (GameManager.powerActive != powerUp.powerType.auto && hit.transform)
                        {
                            //if (!isRegPro && !projectileCausesDamage)
                            //{
                            //lines[0].SetPosition(0, (LOrRWeapons[leftRight].weaponGameObject.transform.position +
                            //    LOrRWeapons[leftRight].weaponGameObject.transform.forward));//LINE TEST HERE
                            //lines[0].SetPosition(1, hit.point);
                            Health h = hit.transform.gameObject.GetComponent<Health>();
                            if (hit.transform && h)
                            {
                                //Instantiate(hitParticle, hit.point, Quaternion.LookRotation(hit.normal));
                                LOrRWeapons[leftRight].setHitPosOn(0, hit.point, Quaternion.LookRotation(hit.normal),isAuto);
                                if (h.isAlive)
                                {
                                    try
                                    {
                                        pos = hit.point;
                                        Health_Enemy he = (Health_Enemy)h;
                                        he.ApplyDamage(damage);
                                        mHit += 1;
                                    }
                                    catch (System.InvalidCastException)
                                    {
                                        h.ApplyDamage(damage);
                                    };
                                    mIfHit = true;
                                }
                            }
                            //if didnt hit anything, thus should turn off the looping in hit particle
                            else LOrRWeapons[leftRight].setHitPosOff();
                            //}
                            setProjectile(hit.point);

                        }
                        else if (GameManager.powerActive == powerUp.powerType.auto)
                            ((powerup_rapidRage)GameManager.gm.activePowerUp).
                            takeShot(LOrRWeapons[leftRight].weaponGameObject.transform.position +
                            LOrRWeapons[leftRight].weaponGameObject.transform.forward,
                            LOrRWeapons[leftRight].weaponGameObject.transform.rotation);

                        if (isSpray)
                        {
                            RaycastHit hit2;
                            //nps = new GameObject[8];
                            if (GameManager.powerActive != powerUp.powerType.auto)
                            {
                                for (int i = 0; i < 8; i++)
                                {
                                    //angle/direction the shot will be rotated at
                                    Vector3 v = new Vector3();
                                    switch (i)
                                    {
                                        //case 0: v = Quaternion.Euler((-spray / 3) * 2, (-spray / 3) * 2, 0f) * LOrRWeapons[leftRight].weaponGameObject.transform.forward; break;//top left
                                        //case 1: v = Quaternion.Euler(-spray, 0f, 0f) * LOrRWeapons[leftRight].weaponGameObject.transform.forward; break;//top center
                                        //case 2: v = Quaternion.Euler((-spray / 3) * 2, (spray / 3) * 2, 0f) * LOrRWeapons[leftRight].weaponGameObject.transform.forward; break;//top right
                                        //case 3: v = Quaternion.Euler(0f, -spray, 0f) * LOrRWeapons[leftRight].weaponGameObject.transform.forward; break;//middle left
                                        //case 4: v = Quaternion.Euler(0f, spray, 0f) * LOrRWeapons[leftRight].weaponGameObject.transform.forward; break;//middle right
                                        //case 5: v = Quaternion.Euler((spray / 3) * 2, (-spray / 3) * 2, 0f) * LOrRWeapons[leftRight].weaponGameObject.transform.forward; break;//bottom left
                                        //case 6: v = Quaternion.Euler(spray, 0f, 0f) * LOrRWeapons[leftRight].weaponGameObject.transform.forward; break;//bottom center
                                        //case 7: v = Quaternion.Euler((spray / 3) * 2, (spray / 3) * 2, 0f) * LOrRWeapons[leftRight].weaponGameObject.transform.forward; break;//botton right
                                        case 0: v = Camera.main.WorldToScreenPoint(new Vector3(hit.point.x - spray, hit.point.y + spray, hit.point.z));break;//top left
                                        case 1: v = Camera.main.WorldToScreenPoint(new Vector3(hit.point.x, hit.point.y + spray, hit.point.z));break;//top center
                                        case 2: v = Camera.main.WorldToScreenPoint(new Vector3(hit.point.x + spray, hit.point.y + spray, hit.point.z)); break;//top right
                                        case 3: v = Camera.main.WorldToScreenPoint(new Vector3(hit.point.x - spray, hit.point.y, hit.point.z)); break;//middle left
                                        case 4: v = Camera.main.WorldToScreenPoint(new Vector3(hit.point.x + spray, hit.point.y, hit.point.z)); break;//middle right
                                        case 5: v = Camera.main.WorldToScreenPoint(new Vector3(hit.point.x - spray, hit.point.y - spray, hit.point.z)); break;//bottom left
                                        case 6: v = Camera.main.WorldToScreenPoint(new Vector3(hit.point.x, hit.point.y - spray, hit.point.z)); break;//bottom center
                                        case 7: v = Camera.main.WorldToScreenPoint(new Vector3(hit.point.x + spray, hit.point.y - spray, hit.point.z)); break;//botton right

                                    }
                                    //COMMENTED OUT FOR 2D PURPOSES
                                    //Physics.Raycast(transform.position + transform.forward, v, out hit);
                                    Ray nRay = Camera.main.ScreenPointToRay(v);
                                    Physics.Raycast(nRay, out hit2);

                                    if (hit2.transform && hit2.transform.gameObject.tag != "Player")
                                    {
                                            //lines[i+1].SetPosition(0, (LOrRWeapons[leftRight].weaponGameObject.transform.position +
                                            //    LOrRWeapons[leftRight].weaponGameObject.transform.forward));//LINE TEST HERE
                                            //lines[i+1].SetPosition(1, hit2.point);
                                        Health h = hit2.transform.gameObject.GetComponent<Health>();

                                        if (h && hit2.transform)
                                        {
                                            //Instantiate(hitParticle, hit2.point, Quaternion.LookRotation(hit2.normal));
                                            LOrRWeapons[leftRight].setHitPosOn(i+1, hit2.point, Quaternion.LookRotation(hit2.normal), isAuto);
                                            if (h.isAlive)
                                            {
                                                try
                                                {
                                                    pos = hit2.point;
                                                    Health_Enemy he = (Health_Enemy)h;
                                                    he.ApplyDamage(damage);
                                                    mHit += 1;
                                                }
                                                catch (System.InvalidCastException)
                                                {
                                                    h.ApplyDamage(damage);
                                                }
                                                mIfHit = true;
                                            }
                                        }
                                        //if didnt hit anything, thus should turn off the looping in hit particle
                                        else LOrRWeapons[leftRight].setHitPosOff();
                                    }
                                     
                                }
                            }
                        }
                        if (!GameManager.gm.bossMode)
                        {
                            //checking the multiplier
                            if (mHit > 1)
                            {
                                if (mHit == 2) Instantiate(time2, pos, time2.transform.rotation);
                                else if (mHit == 3) Instantiate(time3, pos, time3.transform.rotation);
                                else if (mHit == 4) Instantiate(time4, pos, time4.transform.rotation);
                                //GameManager.gm.change_progress(false, mHit);
                                //GameManager.gm.Collect(mHit);
                            }
                            //checking if dual hit occured
                            if (isTouch && mHit > 0)
                            {
                                dHit += 1;
                                if (dHit > 1)
                                {
                                    //if (GameManager.gm.gameMission && GameManager.gm.gameMission.missionAlias.makeDualHit) ;
                                    Instantiate(dualHit);
                                    //GameManager.gm.Collect(2);
                                }
                            }
                        }

                        if (!mIfHit && GameManager.gm.currentMission && GameManager.gm.currentMission.missionAlias2 == mission.missionType2.dontMiss)
                            GameManager.gm.currentMission.progressMission(-1, transform.position, transform.rotation);
                      
                    }
                    
                }
                tCount++;
            } while (tCount < 2 && tCount < tTotal);

            if (!isAuto) endShooting(leftRight);
            yield return null;

        } while (Input.GetButton("Fire1")
#if UNITY_WSA
                ||( Input.GetAxis("Fire1")>0 /*|| Input.GetAxis("Fire2")>0*/)
#endif
                );//end of if fire1 loop


        endShooting(0);
        if (isDual) endShooting(1);
        busy = null;
    }
    Coroutine fadeNow;
    IEnumerator fadeInOutAudio(bool b)
    {
        //fades in
        if (b)
        {

            while (shotAudioSource.volume != 1)
            {
                shotAudioSource.volume += .1f;
                yield return null;
            }
        }
        //fades out
        else
        {
            while (shotAudioSource.volume != 0)
            {
                shotAudioSource.volume -= .1f;
                yield return null;
            }
            shotAudioSource.loop = false;
            shotAudioSource.Stop();
        }
        //yield return null;
        fadeNow = null;
    }

    void endShooting(int lr)
    {
        //if (LOrRWeapons != null)
        //{
        if (isSfxOn && isAuto  && shotAudioSource.isPlaying)
        {
            if (!audioFade)
            {
                shotAudioSource.loop = false;
                shotAudioSource.Stop();
            }
            else
            {
                if (fadeNow != null) StopCoroutine(fadeNow);
                fadeNow = StartCoroutine(fadeInOutAudio(false));
            }
        }
        LOrRWeapons[lr].shooting = false;
        if (isAuto)
        {
            LOrRWeapons[lr].stopMuzzleFlash();
            //stops the crosshair from being shown
#if !UNITY_WSA
            LOrRWeapons[lr].weaponCrosshairControl.disableCrosshair();
#else
            if(GameManager.ifJoyStick) LOrRWeapons[lr].weaponCrosshairControl.disableCrosshair();
#endif
            //turns of the loop of hit particle effect
            LOrRWeapons[lr].setHitPosOff();
        }
        if (isParticle && LOrRWeapons[lr].weaponPsm.loop) LOrRWeapons[lr].weaponPsm.loop = false;
        else if (isLine && LOrRWeapons[lr].weaponProjectile && LOrRWeapons[lr].weaponProjectile.activeSelf)
        {
            //this stops the lightning from being shown
            if (isLightning) LOrRWeapons[lr].weaponLb.boltActive = false;
            LOrRWeapons[lr].weaponProjectile.SetActive(false);

        }
        //}
    }
    //if is line or particle, then it is assumed that the isauto is also true!
    void setProjectile(Vector3 pos)
    {
        //if there is no projectile(s) to spawn
        if (!isLine/* && !isRegPro*/ && !isParticle) return;
        //if current porjectile doesn't exist
        // currPro = Instantiate(projectile, transform.position + transform.forward, transform.rotation) as GameObject;
        else if (isLine)
        {
            //print("setting laser position now!");
            if (!LOrRWeapons[leftRight].weaponProjectile.activeSelf)
            {
                LOrRWeapons[leftRight].weaponProjectile.SetActive(true);
            }
            //starting position
            Vector3 sp = LOrRWeapons[leftRight].weaponGameObject.transform.position + LOrRWeapons[leftRight].weaponGameObject.transform.forward;

            if (!isLightning)
            {
                LOrRWeapons[leftRight].weaponLr.SetPosition(0, sp);
                LOrRWeapons[leftRight].weaponLr.SetPosition(1, pos);
            }
            else
            {
                LOrRWeapons[leftRight].weaponLb.setBoltPos(sp,pos);
            }
        }
        //if is a particle effect
        else if (isParticle)
        {
            if (!LOrRWeapons[leftRight].weaponPsm.loop || !LOrRWeapons[leftRight].weaponProjectile.activeSelf)
            {
                //looping is dependant on whether or not weapon is an automatic
                LOrRWeapons[leftRight].weaponPsm.loop = isAuto;// true;
                LOrRWeapons[leftRight].weaponProjectile.SetActive(true);
            }
            LOrRWeapons[leftRight].weaponProjectile.transform.position = LOrRWeapons[leftRight].weaponGameObject.transform.position + LOrRWeapons[leftRight].weaponGameObject.transform.forward;
            LOrRWeapons[leftRight].weaponProjectile.transform.rotation = LOrRWeapons[leftRight].weaponGameObject.transform.rotation;
            

        }
        //if regular projectile that simply moves forward
        //else if (isRegPro)
        //{
        //    //GameObject go = 
        //    Instantiate(LOrRWeapons[leftRight].weaponProjectile, LOrRWeapons[leftRight].weaponGameObject.transform.position + LOrRWeapons[leftRight].weaponGameObject.transform.forward, LOrRWeapons[leftRight].weaponGameObject.transform.rotation);
        //    //go.GetComponent<Rigidbody>().AddForce(transform.forward * speed, ForceMode.VelocityChange);
        //}
    }




}
