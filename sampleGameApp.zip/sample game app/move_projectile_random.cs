﻿using UnityEngine;
//using System.Collections;

public class move_projectile_random : move_projectile
{
    //HARD CODED THE POSION OF PLAYER, SINCE RIGHT NOW PLAYER DOESNT MOVE FOR FINAL PRODUCT OF GAME
    //protected float yPos = 1;
    //protected float zPos = -7;

    public float rotateMax = 20f;
    // Use this for initialization
    public override void Start()
    {
        base.Start();
        //this rotates the projectile towards direction of player on only one axis
        float deltaZ = GameManager.playerZPos /*zPos */- gameObject.transform.position.z;
        float deltaY = GameManager.playerYPos/*yPos*/ - gameObject.transform.position.y;
        float angle = (Mathf.Atan2(deltaY, deltaZ) * Mathf.Rad2Deg) - 180;

        //rotates at at random angles for y but fixed on x and z
        gameObject.transform.Rotate(angle, Random.Range(-rotateMax, rotateMax), 0f);

        //rotates 90 degrees facing "downwards" to make room for material animation
        gameObject.transform.Rotate(90f, 0, 0);

    }


    protected override void calMove()
    {
        gameObject.transform.Translate(Vector3.up * Time.deltaTime * speed);
    }
}
