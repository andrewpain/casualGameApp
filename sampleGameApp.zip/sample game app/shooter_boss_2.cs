﻿//using UnityEngine;
//using System.Collections;

public class shooter_boss_2 : shooter_boss
{
    move_boss2_teleport_rotate tr;
    protected override void Start()
    {
        base.Start();
        tr = gameObject.GetComponent<move_boss2_teleport_rotate>();
    }
    protected override void allShootCal()
    {
                //restCheck();
        //to check if the boss is still alive, because boss is not auto destroyed when it runs out of life
        if (hb.isAlive && shootCheck() && tr.shooting)
        {
            shoot();
            shootAgainCheck();
            //if low life then advanced shots to be made
            if (lowLife)
            {
                shoot2();
                shootAgainCheck2();
            }
        }
        //if (!lowLife && GameManager.gm.progressbar.fillAmount <= .5) lowLife = true;
        lowLifeCheck();
    }
}
