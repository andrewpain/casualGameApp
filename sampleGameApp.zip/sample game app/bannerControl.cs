﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class bannerControl : MonoBehaviour {

    private void Start()
    {
        GameManager.gm.bannerMode = true;
    }
    private void destroyNow()
    {
        GameManager.gm.bannerMode = false;
        Destroy(gameObject);
    }
}
