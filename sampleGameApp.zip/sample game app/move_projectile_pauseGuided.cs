﻿using UnityEngine;
//using System.Collections;

public class move_projectile_pauseGuided : move_projectile
{
    public float waitTime = 3;
    private float waitCap;
    private bool moving = false;
    // Use this for initialization
    public override void Start()
    {
        base.Start();
        speed *= 2f;
        waitCap = Time.time + waitTime;

        gameObject.transform.LookAt(target);
        //rotates 90 degrees facing "downwards" to make room for material animation
        //gameObject.transform.Rotate(90f, 0, 0);
    }


    protected override void calMove()
    {
        //assuming that projectile's is rotated upwards for animantion
        if (moving) transform.position += transform.forward/*up*/ * speed * Time.deltaTime;
        //if (moving) transform.position = Vector3.MoveTowards(transform.position, target.position, Time.deltaTime * speed);
        else if (!moving)
        {
            transform.LookAt(target);
            //transform.Rotate(90f, 0, 0);
            if (Time.time >= waitCap) moving = true;
        }

    }

}
