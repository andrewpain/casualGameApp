﻿using UnityEngine;
using System.Collections;
using System;

public class mission_scoreWithWeapon : mission
{

    public GameManager.weapons missionWeapon;
    bool rw = false;
    public override void setMissionStart(int cc, int mc, string mi)
    {
        base.setMissionStart(cc, mc, mi);
        missionAlias = missionType.hitEnemy;
        missionAlias2 = missionType2.useWeapon;


        //setting the power up type that is to be counted for mission
        if (misc == "")
        {
            //max number of weapons in game available to user
            int num = UnityEngine.Random.Range(0, Enum.GetValues(typeof(GameManager.weapons)).Length);
            misc = (Resources.Load("weapons/" + Enum.GetValues(typeof(GameManager.weapons)).GetValue(num).ToString(), typeof(GameObject)) as GameObject).GetComponent<infoWeapon>().iName;
            missionWeapon = (GameManager.weapons)Enum.GetValues(typeof(GameManager.weapons)).GetValue(num);
        }
        else
        {
            bool fin = false;
            int maxed = Enum.GetValues(typeof(GameManager.weapons)).Length;
            for (int i = 0; i < maxed && !fin; i++)
            {
                if (misc == (Resources.Load("weapons/" + Enum.GetValues(typeof(GameManager.weapons)).GetValue(i).ToString(), typeof(GameObject)) as GameObject).GetComponent<infoWeapon>().iName)
                {
                    missionWeapon = (GameManager.weapons)Enum.GetValues(typeof(GameManager.weapons)).GetValue(i);
                    fin = true;
                }
            }
            
        }
        //if max count not set, thus new mission
        setDiff(50, 150, 300);
        //setDiff(1, 2, 3);
        StartCoroutine(weaponCheck());
        //rw = GameManager.gm.weapon.GetComponent<infoWeapon>().iName == misc;
    }

    public override string getStatus()
    {
        if(!complete)return string.Format("Hit {0} enemies with {1}. {2}/{3} completed", maxCount, misc, count, maxCount);
        else return string.Format("Hit {0} enemies with the {1} completed! :)", maxCount, misc);

    }

    public void ifUsingRightWeapon()
    {
        rw = GameManager.gm.weapon.GetComponent<infoWeapon>().iName == misc;
    }
    //done so that there wouldnt need to be a constant check for the weapons name since weapon doesn't change during gameplay
    IEnumerator weaponCheck()
    {
        yield return new WaitUntil(() => (GameManager.gm && GameManager.gm.gameState == GameManager.gameStates.Playing));
        rw = GameManager.gm.weapon.GetComponent<infoWeapon>().iName == misc;
        print("Just checked for weapon!");

    }
    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        if (rw && !complete)
        {
            count += p;
            if (count <= maxCount) Instantiate(progressParticle, pos, rot);
            if (count >= maxCount) finishMission();
        }
    }
}
