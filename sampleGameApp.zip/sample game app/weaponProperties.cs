﻿using UnityEngine;
//using System.Collections;

public class weaponProperties
{
    public GameObject weaponGameObject;
    public crosshairControl weaponCrosshairControl;
    public GameObject weaponMuzzleFlash;
    public ParticleSystem.MainModule muzzleAni;
    public GameObject weaponUsedShell;
    public ParticleSystem.MainModule usedShell;
    public GameObject weaponProjectile;
    public ParticleSystem.MainModule weaponPsm;
    public LineRenderer weaponLr;
    public lightningBolt weaponLb;
    public GameObject[] hitParticles;
    public ParticleSystem.MainModule []hitParticlesAni;
    public bool shooting = false;

    public float fireRate = 0;
    private float nextFire = 0f;

    public void setHitParticles(int count, GameObject go)
    {
        hitParticles = new GameObject[count];
        hitParticlesAni = new ParticleSystem.MainModule[count];
        GameObject hph = new GameObject("hPh");
        for(int i = 0; i < count; i++)
        {
            hitParticles[i] = GameObject.Instantiate(go);
            hitParticles[i].SetActive(false);
            ParticleSystem ps =hitParticles[i].GetComponent<ParticleSystem>();
            hitParticlesAni[i] = ps.main;
            hitParticles[i].transform.parent = hph.transform;
        }


    }

    public void setHitPosOn(int c, Vector3 pos, Quaternion rot, bool looping)
    {
        hitParticles[c].SetActive(true);
        hitParticles[c].transform.position = pos;
        hitParticles[c].transform.rotation = rot;
        if (looping && !hitParticlesAni[c].loop) hitParticlesAni[c].loop = true;
    }

    public void setHitPosOff()
    {
        if (hitParticles == null) return;

        int hpa = hitParticles.Length;
        for (int i = 0; i < hpa; i++) if (hitParticlesAni[i].loop) hitParticlesAni[i].loop = false;
    }
    public void setMuzzlePosition(bool auto)
    {
        //weaponMuzzleFlash.transform.position = weaponGameObject.transform.position + weaponGameObject.transform.forward;
        //weaponMuzzleFlash.transform.rotation = weaponGameObject.transform.rotation;
        //if (!muzzleAni.loop)
        //{
        muzzleAni.loop = auto;

        if (weaponUsedShell)
        {
            usedShell.loop = auto;
            weaponUsedShell.SetActive(true);
        }
        weaponMuzzleFlash.SetActive(true);
        //}

    }

    public void stopMuzzleFlash()
    {
        if (muzzleAni.loop)
        {
            muzzleAni.loop = false;
            if (weaponUsedShell/* && usedShell.loop*/)
            {
                usedShell.loop = false;
                //weaponUsedShell.SetActive(true);
            }
            //weaponMuzzleFlash.SetActive(true);
        }
    }


    public bool timePast()
    {
        bool b = Time.time > nextFire;
        if (b) nextFire = Time.time + fireRate;
        return b;
    }
}
