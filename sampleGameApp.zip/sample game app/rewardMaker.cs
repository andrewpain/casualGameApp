﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class rewardMaker : MonoBehaviour
{
    public GameObject coinRewardObject;
    public float timeSecs = 1;
    public int coinAmnt = 1;

    public void OnParticleSystemStopped()
    {
        //print("On Particle System Stopped");
        Instantiate(coinRewardObject, transform.position,Quaternion.identity).GetComponent<rewardMovement>().setStart(timeSecs,coinAmnt);
        Destroy(gameObject);
    }
}
