﻿//using Azure.AppServices;
using RESTClient;
using System;
using System.Collections;
using System.IO;
//using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.SceneManagement;
using UnityEngine.UI;

#if UNITY_WSA
using WSAUnity;
#endif

public class gameOverControl : MonoBehaviour {
    public GameObject newNamePanel;
    public GameObject newHStext;
    public GameObject newHSfireWorks;
    public Text gameOverScoreDisplay;
    public GameObject gameOverPanel;

    public GameObject rankPanel;
    public Text rankList;
    public Text nameList;
    public Text scoreList;
    //public Text playerCountry;
    public GameObject rankRefreshButton;
    //for when the refresh button is pushed
    bool isLocal = false;
    // Use this for initialization
    //private GameObject loading;

    public GameObject gameOverPanelButtons;
    public GameObject shareSocialPanel, optionPanel;
    public Image polaroidImage;
    public Image fullImage;
    public GameObject giveRatingPanel;
    public string privacyPolicy = "https://sampleWebsite.com/Privacy";
    //start does functions/checks for when player dies
    public GameObject rankButton, settingButton, playButton, shareButton;
    public GameObject rankDef, settingDef, infoDef, restoreDef, ScreenShotDef, giveRatingDef, newNameDef, giftDef;
    void Start()
    {

        bool newHigh = GameManager.gm.score > GameManager.gamePlayer.score;
        bool ifSynch = (newHigh || PlayerPrefs.HasKey(GameManager.playerScoreUnsynchedKey) || PlayerPrefs.HasKey(GameManager.playerPlatformUnsynchedKey));


        //if new highscore or current highscore isn't synched
        if (ifSynch)
        {
            //if the new score is in fact highest
            if (newHigh)
            {

                //saving new highscore
                GameManager.gamePlayer.score = GameManager.gm.score;
                //the minus seven is to get rid of the '(clone)' in name, which is 7 characters
                GameManager.gamePlayer.weaponId = GameManager.gm.weapon.name.Substring(0, GameManager.gm.weapon.name.Length - 7);

                if (!PlayerPrefs.HasKey(GameManager.playerScoreUnsynchedKey)) PlayerPrefs.SetInt(GameManager.playerScoreUnsynchedKey, 0);
                if (!PlayerPrefs.HasKey(GameManager.playerPlatformUnsynchedKey)) PlayerPrefs.SetInt(GameManager.playerPlatformUnsynchedKey, 0);

                dataControl.savePlayer(GameManager.gamePlayer);

                newHStext.SetActive(true);
                //highscore animation here
                StartCoroutine(repeatParticles(newHSfireWorks, .25f, GameManager.gm.MinRange, GameManager.gm.MaxRange, "firework"));
            }
            Debug.Log("highscore: " + GameManager.gamePlayer.score);
            Debug.Log("weapon name: " + GameManager.gamePlayer.weaponId);

            GameManager.gamePlayer.ifScore = true;
            //GameManager.gamePlayer.weaponId = wn;
            //GameManager.gamePlayer.score = sc;
            print("highscore info set");

        }
        else GameManager.gamePlayer.ifScore = false;

        // set the end game score
        gameOverScoreDisplay.text = GameManager.gm.score.ToString();

        //int ca = GameManager.gamePlayer.coins;//PlayerPrefs.GetInt(GameManager.playerCoinsKey, 0);
        if (GameManager.gm.coinAmount != 0 || PlayerPrefs.HasKey(GameManager.playerCoinsUnsynchedKey))
        {
            GameManager.gamePlayer.coins += GameManager.gm.coinAmount;
            GameManager.gamePlayer.ifCoins = true;
            if (!PlayerPrefs.HasKey(GameManager.playerCoinsUnsynchedKey)) PlayerPrefs.SetInt(GameManager.playerCoinsUnsynchedKey, 0);
            dataControl.savePlayer(GameManager.gamePlayer);
            print("Coins info set");

        }
        else GameManager.gamePlayer.ifCoins = false;
        //if player has been created
        //if (PlayerPrefs.HasKey(GameManager.playerIdKey))
        if (GameManager.gamePlayer.id != null && GameManager.gamePlayer.id != "")
        {
            //if synching player coins and highscore
            if (GameManager.gamePlayer.ifScore || GameManager.gamePlayer.ifCoins || GameManager.gamePlayer.ifMission)
            {

                if (GameManager.gamePlayer.ifMission)
                    //GameManager.gamePlayer.missionDate = TimeZoneInfo.ConvertTimeToUtc(DateTime.Parse(GameManager.gamePlayer.missionDate),TimeZoneInfo.Local).ToString();
                    GameManager.gamePlayer.missionDate = TimeZoneInfo.ConvertTime(DateTime.Parse(GameManager.gamePlayer.missionDate), TimeZoneInfo.Local, TimeZoneInfo.Utc).ToString();
                //GameManager.gamePlayer.missionDate =  TimeZone.CurrentTimeZone.ToUniversalTime(DateTime.Parse(GameManager.gamePlayer.missionDate)).ToString();
                StartCoroutine(GameManager.client.InvokeApi<jointSynch, Message>("sampleMultiSynch", Method.POST, GameManager.gamePlayer, onMultiSynchComplete));
                if (GameManager.gamePlayer.ifMission)
                    GameManager.gamePlayer.missionDate = TimeZoneInfo.ConvertTime(DateTime.Parse(GameManager.gamePlayer.missionDate), TimeZoneInfo.Utc, TimeZoneInfo.Local).ToString();
                //GameManager.gamePlayer.missionDate = TimeZone.CurrentTimeZone.ToLocalTime(DateTime.Parse(GameManager.gamePlayer.missionDate)).ToString();
                //GameManager.gamePlayer.missionDate = TimeZoneInfo.ConvertTimeFromUtc(DateTime.Parse(GameManager.gamePlayer.missionDate), TimeZoneInfo.Local).ToString();
                print("milti-synch begun");
            }
            if (PlayerPrefs.HasKey(GameManager.playerPlatformUnsynchedKey))
            {
#if UNITY_ANDROID //&& !UNITY_EDITOR
                //if (GameManager.gamePlayer.score >= GameManager.gm.score)
                androidPlay.postHighscoreToLeaderBoard(GameManager.gamePlayer.score, true);
#elif UNITY_WSA //&& !UNITY_EDITOR
                if (GameManager.WSAPlayer) GameManager.WSAPlayer.postScoreToXbox(GameManager.gamePlayer.score, true);

#endif
            }
            //regular score
            else
            {
#if UNITY_ANDROID //&& !UNITY_EDITOR
                androidPlay.postHighscoreToLeaderBoard(GameManager.gm.score, false);
                //not necessary since xbox doest save the highest score, but only the most recent score, unlike google android
//#elif UNITY_WSA// && !UNITY_EDITOR
//                GameManager.WSAPlayer.postScoreToXbox(GameManager.gm.score, false);
#endif
            }
        }

        gameOverPanel.SetActive(true);
        GameManager.gm.setHighCoins();
        setAudioButtons('a');
        StartCoroutine(getScreenShot(false));

#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(playButton);
#endif
        //app rating check here
        if (!PlayerPrefs.HasKey("rated") && GameManager.gamePlayer.score > GameManager.gm.totalprogress/*150*/)
        {
            DateTime ls = DateTime.Parse(PlayerPrefs.GetString("lastSuggest", new DateTime(2019, 1, 1).ToString()));
            TimeSpan ts = new TimeSpan(3, 0, 0, 0);
            if (DateTime.Now - ls >= ts)
            {
                gameOverPanel.SetActive(false);//show suggestion to rate app here;
                giveRatingPanel.SetActive(true);
#if UNITY_WSA
                if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(giveRatingDef);
#endif
            }
        }

    }

    public static string getStoreLink()
    {
#if UNITY_ANDROID
            return "https://play.google.com/store/apps/details?id=com.IslandEnt.BlockyBusters";
#elif UNITY_WSA
            return "https://www.microsoft.com/store/apps/9MZSM7GV5RWK";
#else
        else return "https://pixelisland.azurewebsites.net";
#endif
    }
    public void ratingGo(bool go)
    {
        if (go)
        {
            //string rateAppUrl = ;
            //if (Application.platform == RuntimePlatform.Android)
            //    rateAppUrl = "https://play.google.com/store/apps/details?id=com.IslandEnt.BlockyBusters";
            //else if (Application.platform == RuntimePlatform.WindowsPlayer)
            //    rateAppUrl = "https://www.microsoft.com/store/apps/9MZSM7GV5RWK";
            PlayerPrefs.SetInt("rated", 1);
            PlayerPrefs.DeleteKey("lastSuggest");
            giveRatingPanel.SetActive(false);
            gameOverPanel.SetActive(true);
            Application.OpenURL(getStoreLink());

        }
        else
        {
            PlayerPrefs.SetString("lastSuggest", DateTime.Now.ToString()/*.ToShortDateString()*/);
            giveRatingPanel.SetActive(false);
            gameOverPanel.SetActive(true);
        }
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(playButton);
#endif
    }
    //static because called by iap manager
    public static void onMultiSynchComplete(IRestResponse<Message> response)
    {
        if (!response.IsError)
        {
            //statusMsg.text = "Highscore updated!";
            Debug.Log("On Multi Synch Complete: " + response.Url + " data: " + response.Content);
            Message h = response.Data;
            //GameManager.gm.timedMsg(h.message);
            if (GameManager.gamePlayer.ifScore && PlayerPrefs.HasKey(GameManager.playerScoreUnsynchedKey)) PlayerPrefs.DeleteKey(GameManager.playerScoreUnsynchedKey);
            if (GameManager.gamePlayer.ifCoins && PlayerPrefs.HasKey(GameManager.playerCoinsUnsynchedKey)) PlayerPrefs.DeleteKey(GameManager.playerCoinsUnsynchedKey);
            if (GameManager.gamePlayer.ifMission)
            {
                if (GameManager.gamePlayer.ifMissionDone) GameManager.gm.gameMissionControl.OnMissionDoneComplete(response);
                else GameManager.gm.gameMissionControl.OnMissionUpdateComplete(response);
            }
        }
        else
        {
            Debug.Log("Multi Synch Error Status:" + response.StatusCode + " Url: " + response.Url);
        }
    }
    //private int hscount = 0;
    public static IEnumerator repeatParticles(GameObject newHS, float waitSecs, Vector3 Min, Vector3 Max, string sfx)
    {
        int hscount = 0;
        for (int i = 0; i < 10; i++)
        {
            hscount++;
            float x = UnityEngine.Random.Range(Min.x, Max.x);
            float y = UnityEngine.Random.Range(Min.y, Max.y);
            //float z = Min.z;// UnityEngine.Random.Range(Min.z, Max.z);
            AudioManager.am.playSound(sfx, Instantiate(newHS, new Vector3(x, y, Min.z), newHS.transform.rotation));
            yield return new WaitForSecondsRealtime(waitSecs);
        }

    }


    //when ranking / local / friends / global buttons are pushed
    public void getHighScores(bool ifLocal)
    {
        //TEMPORARILY HERE SINCE MIGHT NOT BE USING COUNTRIES ANY MORE AND YET TO IMPLIMENT SOCIAL FRIENDS
        //if (ifLocal || isLocal) return;
        //makes the rank panel visible
        if (gameOverPanel.activeSelf || !rankPanel.activeSelf)
        {
            gameOverPanel.SetActive(false);
            rankPanel.SetActive(true);
#if UNITY_ANDROID
            platformHighsoreBtn.material = Resources.Load("ButtonMaterials/buttonAndroid", typeof(Material)) as Material;
#elif UNITY_WSA
            platformHighsoreBtn.material = Resources.Load("ButtonMaterials/buttonXbox", typeof(Material)) as Material;
#endif
        }
        isLocal = ifLocal;
        string nm = GameManager.gamePlayer.playerId;
        //setting/retrieving the name
        if (nm == null || nm == "")
        {
            GameManager.gm.gameState = GameManager.gameStates.newName;
            rankPanel.SetActive(false);
            newNamePanel.SetActive(true);
#if UNITY_WSA
            if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(newNameDef);
#endif
            return;
        }
        else getScores(isLocal);
    }

    public void scoresToMenu()
    {
        GameManager.gm.toggleLoading(false);
        GameManager.gm.statusMsg.text = "";
        rankPanel.SetActive(false);
        gameOverPanel.SetActive(true);
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(rankButton);
#endif
    }
    //getting the high scores
    private void getScores(bool local)
    {


        if (!local)
        {
            if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(rankDef);
            rankList.text = "";
            nameList.text = "";
            scoreList.text = "";
            GameManager.gm.statusMsg.text = "getting highscores..";
            GameManager.gm.toggleLoading(true);
            StartCoroutine(GameManager.client.InvokeApi<jointSynch>("sampleGetHighscores", Method.POST, OnReadScoresCompleted));
        }
        else
        {

#if UNITY_ANDROID && !UNITY_EDITOR
            androidPlay.showLeaderBoard();

#elif UNITY_WSA

            //XboxLiveContext xboxLiveContext = idManager.xboxLiveContext;
            //LeaderboardService boardService = xboxLiveContext.LeaderboardService;
            //await getXboxAsync();
            if (GameManager.WSAPlayer) GameManager.WSAPlayer.showXboxLeaderBoard();
            else GameManager.gm.timedMsg("Not currently signed in. Try again later");

#endif
        }
    }

    //#if UNITY_WSA
    //    async void getXboxAsync()
    //    {
    //        LeaderboardResult boardResult = await boardService.GetLeaderboardAsync(
    //     xboxLiveConfig.ServiceConfigurationId,
    //     leaderboardName
    //     );
    //    }
    //#endif

    //when the refresh button is pushed
    public void refreshScores()
    {
        getScores(isLocal);
    }
    //when scores have returned from server 
    private void OnReadScoresCompleted(IRestResponse<jointSynch[]> response)
    {
        if (!response.IsError)
        {
            Debug.Log("OnReadCompleted: " + response.Url + " data: " + response.Content);
            jointSynch[] items = response.Data;
            Debug.Log("players count: " + items.Length);
            bool pf = false;
            string playerName = GameManager.gamePlayer.playerId;//PlayerPrefs.GetString(GameManager.playerNameKey, "");
            for (int i = 0; i < items.Length; i++)
            {
                //rank colour
                string rc = "white";
                //player name colour
                string pc = "white";
                //if the player is in 1st/2nd/3rd
                if (i < 3)//else
                {
                    switch (i)
                    {
                        case 0: rc = "#FFD700"; break;//gold
                        case 1: rc = "#C0C0C0"; break;//silver
                        case 2: rc = "#CD7F32"; break;//bronze
                    }
                }
                //if current name is name of player
                if (items[i].playerId == playerName)
                {
                    pc = "lime";
                    pf = true;
                }
                //in the event a layer has a top 50 score but hasn't put in a name
                else if (items[i].playerId.StartsWith("play") || items[i].playerId.StartsWith("uwpp") || items[i].playerId.StartsWith("test"))
                {
                    Guid guid;
                    //if (Guid.TryParse(items[i].playerId.Substring(4, items[i].playerId.Length-4),out guid))
                    try
                    {
                        guid = new Guid(items[i].playerId.Substring(4, items[i].playerId.Length - 4));
                        items[i].playerId = "Unknown";
                    }
                    catch (Exception e) { print("could not parse Guid for player id: " + e.Message); }
                }
                rankList.text += "<color=" + rc + ">#" + (i + 1) + "</color>\n";
                nameList.text += "<color=" + pc + ">" + items[i].playerId + "</color>\n";
                scoreList.text += "<color=" + pc + ">" + items[i].score + "</color>\n";

            }
            //if player not in top 50, add player's name to bottom
            if (!pf)
            {
                rankList.text += "<color=white>#50+</color>\n";
                nameList.text += "<color=lime>" + GameManager.gamePlayer.playerId/*PlayerPrefs.GetString(GameManager.playerNameKey)*/ + "</color>\n";
                scoreList.text += "<color=lime>" + GameManager.gamePlayer.score/*PlayerPrefs.GetInt(GameManager.highscoreKey)*/ + "</color>\n";
            }
            //if (!rankPanel.activeSelf) rankPanel.SetActive(true);

        }
        else
        {
            Debug.LogWarning("Read Error Status:" + response.StatusCode + " Url: " + response.Url);
            rankRefreshButton.SetActive(true);
        }
        GameManager.gm.toggleLoading(false);
        GameManager.gm.statusMsg.text = "";

    }

    public void openOptions()
    {
        gameOverPanel.SetActive(false);
        optionPanel.SetActive(true);
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(settingDef);
#endif
    }

    public void playAgain()
    {
        string fp = getPathUri(getScreenShotName(false));
        if (File.Exists(fp)) File.Delete(fp);        //loads a new game
        GameManager.gm.loadGameScene();
    }

    public void showScreenShot()
    {
        print("show screenshot");
        StartCoroutine(getScreenShot(true));
    }
    //takes screen shot to upload to social media ie facebook
    public void shareSocial()
    {
        //gameOverPanelButtons.SetActive(false);
        //StartCoroutine(getScreenShot());
        shareScreenshot("o");
    }
    static readonly string screenShotNameKey = "BlockyBusters";
    static readonly string fileCountKey = "fileCount";
    public static string getScreenShotName(bool ifAppend)
    {
        int fc = PlayerPrefs.GetInt(fileCountKey, 0);
        if (ifAppend) PlayerPrefs.SetInt(fileCountKey, (fc + 1));
        else fc -= 1;
        string ss = screenShotNameKey + fc + ".png";
        return (ss);
    }
    public static string getPathUri(string fileName)
    {
#if UNITY_EDITOR
        //if (Application.isEditor) 
        return "C:/Users/Andrew/Documents/Unity Projects/final_project_game/" + fileName;//"C:/Users/Public/Documents/Unity Projects/final_project_game/" + fileName;
#else
			return Path.Combine(Application.persistentDataPath, fileName);
#endif
    }

    private IEnumerator getScreenShot(bool ifBig)
    {
        string ss = getScreenShotName(false);
        string url = getPathUri(ss);
        float waitTime = Time.time + 1f;
        yield return new WaitUntil(() => File.Exists(url) || Time.time >= waitTime);
        if (File.Exists(url))
        {
            try
            {
                //byte[] data;
                // Read the data from the file
                //#if !UNITY_WSA || UNITY_EDITOR
                byte[] data = File.ReadAllBytes(url);
                //#else
                //data = TextUtils.ReadAllBytes(ss); 
                //#endif
                // Create the texture
                Texture2D screenshotTexture = new Texture2D(Screen.width, Screen.height);
                // Load the image
                screenshotTexture.LoadImage(data);
                // Create the sprite
                Sprite screenshotSprite = Sprite.Create(screenshotTexture, new Rect(0, 0, Screen.width, Screen.height), new Vector2(0.5f, 0.5f));
                // Set the sprite to the screenshotPreview
                if (!ifBig)
                {
                    polaroidImage.sprite = screenshotSprite;
                    polaroidImage.transform.parent.gameObject.SetActive(true);
                }
                else
                {
                    fullImage.sprite = screenshotSprite;
                    gameOverPanel.SetActive(false);
                    shareSocialPanel.SetActive(true);
#if UNITY_WSA
                    if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(ScreenShotDef);
#endif
                }
            }
            catch (Exception e)
            {
                print("Error in getting screenshot: " + e.Message);
                GameManager.gm.timedMsg("Error in getting screenshot: " + e.Message);

            }
        }
        else GameManager.gm.timedMsg("no photo exists :( ");

    }

    bool isFocused = true;
    readonly string SHARE_TEXT = "Can you beat my score?";

    public void shareScreenshot(string choice)
    {
        string picName = getScreenShotName(false);
        string fileLoc = getPathUri(picName);
        print("Does file: " + fileLoc + " exist?!: " + File.Exists(fileLoc));

        if (!File.Exists(fileLoc))
        {
            GameManager.gm.timedMsg("Could not share screen shot :(");
            return;
        }
        //shareSocialPanel.SetActive(false);
        //switch (choice)
        //{
        //    case "f":gameOverPanel.SetActive(true);break;
        //    case "t":gameOverPanel.SetActive(true);break;
        //    case "o": StartCoroutine(sharingNow(fileLoc)); break;       
        //}
        gameOverPanel.SetActive(false);
#if !UNITY_EDITOR && UNITY_ANDROID
        
                try
                {
                    isFocused = false;
                    AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");
                    AndroidJavaObject intentObject = new AndroidJavaObject("android.content.Intent");
                    intentObject.Call<AndroidJavaObject>("setAction", intentClass.GetStatic<string>("ACTION_SEND"));
                    AndroidJavaClass uriClass = new AndroidJavaClass("android.net.Uri");
                    AndroidJavaObject uriObject = uriClass.CallStatic<AndroidJavaObject>("parse", "file://" + fileLoc);
                    intentObject.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_STREAM"), uriObject);
                    intentObject.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_TEXT"), SHARE_TEXT);
                    intentObject.Call<AndroidJavaObject>("setType", "image/jpeg");
                    AndroidJavaClass unity = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
                    AndroidJavaObject currentActivity = unity.GetStatic<AndroidJavaObject>("currentActivity");
                    AndroidJavaObject chooser = intentClass.CallStatic<AndroidJavaObject>("createChooser", intentObject, "Share your score!");
                    currentActivity.Call("startActivity", chooser);

                }
                catch (Exception e)
                {
                    GameManager.gm.timedMsg("unable to share screenshot :( : " + e.Message);
                    //gameOverPanel.SetActive(true);
                    isFocused = true;
                }

            
#elif UNITY_WSA //&& !UNITY_EDITOR
        print("sharing initiated");
        isFocused = false;
        Sharing.Title = "Blocky Busters score!";
        Sharing.Description = SHARE_TEXT;
        //@"Assets\curiosity_view.png"
        //@"Assets\Wide310x150Logo.scale-200.png"
        Sharing.ImageFilePath = picName; //@"LocalState\"+fileLoc;
        Sharing.TextToShare = "My Score is: " + GameManager.gm.score;
        Sharing.Url = getStoreLink();
        //Sharing.ShowShareUI(SharingType.Image, onShareComplete);
        try
        {
            Sharing.ShowShareUI(SharingType.Image, (obj) =>
            {
                Debug.Log("Status: " + obj.Status + ", Exception: " + obj.Exception);
                //GameManager.gm.timedMsg("Sharing Status: " + obj.Status + ", Exception: " + obj.Exception);
                isFocused = true;

            });
        }
        catch (Exception e) { print("tried to share pic but error: " + e.Message); }


#else
        GameManager.gm.timedMsg("Can't share while in Editor");
#endif
        StartCoroutine(shareWait());

    }


    IEnumerator shareWait()
    {
        yield return new WaitUntil(() => isFocused);
        gameOverPanel.SetActive(true);
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(shareButton);
#endif
    }
    //    IEnumerator sharingNow(string fileLoc)
    //    {
    //        //#if UNITY_ANDROID
    //        gameOverPanel.SetActive(false);
    //        if (!Application.isEditor)
    //        {
    //            if (Application.platform == RuntimePlatform.Android)
    //            {
    //                try
    //                {
    //                    isFocused = false;
    //                    AndroidJavaClass intentClass = new AndroidJavaClass("android.content.Intent");
    //                    AndroidJavaObject intentObject = new AndroidJavaObject("android.content.Intent");
    //                    intentObject.Call<AndroidJavaObject>("setAction", intentClass.GetStatic<string>("ACTION_SEND"));
    //                    AndroidJavaClass uriClass = new AndroidJavaClass("android.net.Uri");
    //                    AndroidJavaObject uriObject = uriClass.CallStatic<AndroidJavaObject>("parse", "file://" + fileLoc);
    //                    intentObject.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_STREAM"), uriObject);
    //                    intentObject.Call<AndroidJavaObject>("putExtra", intentClass.GetStatic<string>("EXTRA_TEXT"), SHARE_TEXT);
    //                    intentObject.Call<AndroidJavaObject>("setType", "image/jpeg");
    //                    AndroidJavaClass unity = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
    //                    AndroidJavaObject currentActivity = unity.GetStatic<AndroidJavaObject>("currentActivity");
    //                    AndroidJavaObject chooser = intentClass.CallStatic<AndroidJavaObject>("createChooser", intentObject, "Share your score!");
    //                    currentActivity.Call("startActivity", chooser);

    //                }
    //                catch (Exception e)
    //                {
    //                    GameManager.gm.timedMsg("unable to share screenshot :( : " + e.Message);
    //                    //gameOverPanel.SetActive(true);
    //                    isFocused = true;
    //                }
    //                yield return new WaitUntil(() => isFocused);

    //            }
    //            else if (Application.platform == RuntimePlatform.WindowsPlayer)
    //            {
    //#if UNITY_WSA //&& !UNITY_EDITOR
    //                print("SUPPOSE TO BE SHARING NOW");
    //                isFocused = false;
    //                Sharing.Title = "Share Your Score!";
    //                Sharing.Description = SHARE_TEXT;
    //                //Sharing.ImageFilePath = @fileLoc;
    //                Sharing.TextToShare = "My Score is: "+GameManager.gm.score;
    //                //Sharing.ShowShareUI(SharingType.Image, onShareComplete);
    //                Sharing.ShowShareUI(SharingType.Text, (obj) => 
    //                {
    //                    Debug.Log("Status: " + obj.Status + ", Exception: " + obj.Exception);
    //                    GameManager.gm.timedMsg("Sharing Status: " + obj.Status + ", Exception: " + obj.Exception);
    //                    isFocused = true;

    //                });
    //#endif
    //            }

    //            //else if (Application.platform == RuntimePlatform.IPhonePlayer) { }
    //            //#elif UNITY_IOS
    //            //        isFocused = false;
    //            //#elif UNITY_STANDALONE_WIN //UNITY_EDITOR
    //            //        isFocused = false;

    //            //#elif UNITY_WSA_10_0
    //            //        isFocused = false;


    //        }
    //        else
    //        {
    //            GameManager.gm.timedMsg("Can't share while in Editor");
    //        }

    //        //yield return new WaitUntil(() => isFocused);
    //        gameOverPanel.SetActive(true);

    //        //#endif
    //        //gameOverPanel.SetActive(true);
    //        yield return null;
    //    }

    private void OnApplicationFocus(bool focus)
    {
        isFocused = focus;
    }
    //holds all the restore information
    private restoreControl rc;
    //when the restore button is hit
    public void restoreCloud()
    {
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(restoreDef);
#endif
        localData.text = "<size=40><b>Local</b></size>";
        cloudData.text = "<b><size=40>Cloud</size></b>";
        string pid = GameManager.gamePlayer.id;//PlayerPrefs.GetString(GameManager.playerIdKey, "");
        //string cid = PlayerPrefs.GetString(GameManager.countryCodeKey, "");
        if (pid == null || pid == "")
        {
            //to remove msg
            GameManager.gm.timedMsg("Create profile in rankings first");
            return;
        }
        //restoreCount = 0;
        GameManager.gm.statusMsg.text = "Getting player's data..";
        //disables refresh button
        if (refreshRestore.activeInHierarchy) refreshRestore.SetActive(false);
        GameManager.gm.toggleLoading(true);
        StartCoroutine(GameManager.client.InvokeApi<Message, jointSynch>("sampleGetPlayerInfo", Method.POST, Message.Create(GameManager.gamePlayer.id), onJointSynchRestoreComplete));
    }
    public Text cloudData;
    public Text localData;
    private void onJointSynchRestoreComplete(IRestResponse<jointSynch[]> response)
    {
        if (!response.IsError)
        {
            if (response.Data == null || response.Data.Length == 0)
            {
                GameManager.gm.timedMsg("Error getting player's information");
                restoreFailed();
                return;

            }
            Debug.Log("On Player Read Complete: " + response.Url + " data: " + response.Content);
            jointSynch[] p = response.Data;
            //localData.text += "\n\n<b>Name: </b>" + GameManager.gamePlayer.playerId;
            //cloudData.text += "\n\n<b>Name: </b>" + p[0].playerId;

            localData.text += "\n<b>Coins: </b>" + GameManager.gamePlayer.coins;
            cloudData.text += "\n<b>Coins: </b>" + p[0].coins;
            //setting the high score
            localData.text += "\n<b>Highscore: </b>" + GameManager.gamePlayer.score;
            cloudData.text += "\n<b>Highscore: </b>" + p[0].score;
            StartCoroutine(GameManager.client.InvokeApi<Message, playerItem>("sampleGetPlayerItems", Method.POST, Message.Create(GameManager.gamePlayer.id), OnItemRestoreCompleted));
            GameManager.gm.statusMsg.text = "Getting Item Data..";
            rc = new restoreControl
            {
                //cloudPlayer = p
                cloudJoint = p[0]
            };
        }
        else
        {
            Debug.LogWarning("Read Player Info Status:" + response.StatusCode + " Url: " + response.Url);
            GameManager.gm.timedMsg("finding player Info failed");
            restoreFailed();
        }
    }
    public GameObject refreshRestore;

    private void OnItemRestoreCompleted(IRestResponse<playerItem[]> response)
    {
        if (!response.IsError)
        {
            Debug.Log("OnReadCompleted: " + response.Url + " data: " + response.Content);
            playerItem[] items = response.Data;
            Debug.Log("items count: " + items.Length);

            string[] la = new string[Enum.GetValues(typeof(GameManager.avatars)).Length];
            for (int i = 0; i < la.Length; i++)
                la[i] = Enum.GetValues(typeof(GameManager.avatars)).GetValue(i).ToString();


            string[] lw = new string[Enum.GetValues(typeof(GameManager.weapons)).Length];
            for (int i = 0; i < lw.Length; i++)
                lw[i] = Enum.GetValues(typeof(GameManager.weapons)).GetValue(i).ToString();

            int localWeaponCount = 0;
            int cloudWeaponCount = 0;
            int localCharCount = 0;
            int cloudCharCount = 0;

            localData.text += "\n<b>Characters: </b>";
            cloudData.text += "\n<b>Characters: </b>";

            //local avatars
            for (int i = 0; i < la.Length; i++)
            {
                //if (PlayerPrefs.HasKey(la[i]))
                if (GameManager.gameItems.itemNames.Contains(la[i]))
                {
                    //string wn = (Resources.Load("avatars/" + la[i], typeof(GameObject)) as GameObject).GetComponent<infoAvatar>().iName;
                    //localData.text += wn + "\n";
                    localCharCount++;
                }
            }
            localData.text += localCharCount;
            //cloud avatars
            //string [] repeatedNames = new string[items.Length];//to avoid the repeated names
            System.Collections.Generic.List<string> repeatedNames = new System.Collections.Generic.List<string>();
            for (int i = 0; i < items.Length; i++)
            {
                TimeSpan ts;
                if (items[i].boughtAt != "" && items[i].boughtAt != null) ts = DateTime.UtcNow - /*TimeZone.CurrentTimeZone.ToLocalTime*/(DateTime.Parse(items[i].boughtAt));
                else ts = DateTime.UtcNow - DateTime.UtcNow;
                if (ts <= ItemManager.itemTimeCap || items[i].perm)
                {

                    //string iName = "";
                    if (items[i].itemid.StartsWith("avatar"))
                    {
                        bool repeated = false;
                        for (int k = 0; k < repeatedNames.Count; k++)
                        {
                            if (repeatedNames[k] == items[i].itemid)
                            {
                                repeated = true;
                                print("DUPLICATE FOUND");
                                break;
                            }
                        }
                        if (!repeated)
                        {
                            //iName = (Resources.Load("avatars/" + items[i].itemid, typeof(GameObject)) as GameObject).GetComponent<infoAvatar>().iName;
                            //cloudData.text += iName + "\n";
                            cloudCharCount++;
                            repeatedNames.Add(items[i].itemid);
                        }
                    }
                }
            }
            cloudData.text += cloudCharCount;

            localData.text += "\n<b>Weapons: </b>";
            cloudData.text += "\n<b>Weapons: </b>";
            //local weapons
            for (int i = 0; i < lw.Length; i++)
            {
                //if (PlayerPrefs.HasKey(lw[i]))
                if (GameManager.gameItems.itemNames.Contains(lw[i]))
                {
                    //string wn = (Resources.Load("weapons/" + lw[i], typeof(GameObject)) as GameObject).GetComponent<infoWeapon>().iName;
                    //localData.text += wn + "\n";
                    localWeaponCount++;
                }
            }
            localData.text += localWeaponCount;

            repeatedNames.Clear();// = new System.Collections.Generic.List<string>();
            //cloud weapons
            for (int i = 0; i < items.Length; i++)
            {
                TimeSpan ts;
                if (items[i].boughtAt != "" && items[i].boughtAt != null) ts = DateTime.UtcNow - /*TimeZone.CurrentTimeZone.ToLocalTime*/(DateTime.Parse(items[i].boughtAt));
                else ts = DateTime.UtcNow - DateTime.UtcNow;
                if (ts <= ItemManager.itemTimeCap || items[i].perm)
                {
                    //string iName = "";
                    if (items[i].itemid.StartsWith("weapon"))
                    {
                        bool repeated = false;
                        for (int k = 0; k < repeatedNames.Count; k++)
                        {
                            if (repeatedNames[k] == items[i].itemid)
                            {
                                repeated = true;
                                print("DUPLICATE FOUND");

                                break;
                            }
                        }
                        if (!repeated)
                        {
                            //iName = (Resources.Load("weapons/" + items[i].itemid, typeof(GameObject)) as GameObject).GetComponent<infoWeapon>().iName;
                            //cloudData.text += iName + "\n";
                            cloudWeaponCount++;
                            repeatedNames.Add(items[i].itemid);
                        }
                    }
                }
            }
            cloudData.text += cloudWeaponCount;


            GameManager.gm.toggleLoading(false);
            GameManager.gm.statusMsg.text = "";
            rc.localWeapons = lw;
            rc.localAvatars = la;
            rc.cloudItems = items;
        }
        else
        {
            Debug.LogWarning("Read Error Status:" + response.StatusCode + " Url: " + response.Url);
            GameManager.gm.timedMsg("Can't get items");
            restoreFailed();
        }
    }
    //when yes/no button from restore panel is entered
    public void restoreExit(bool ifRestore)
    {
        //localData.text = "<size=40><b>Local</b></size>";
        //cloudData.text = "<b><size=40>Cloud</size></b>";
        if (GameManager.gm.statusMsg.text != "") GameManager.gm.statusMsg.text = "";
        //print("MISSION NAME: " + GameManager.gamePlayer.mname);
        //print("LOCAL MISSION NAME: " + rc.cloudJoint.mname);
        if (ifRestore && rc != null)
        {
            //save cloud information here
            rc.saveCloudData();
        }
        //rc = null;
        GameManager.gm.toggleLoading(false);
#if UNITY_WSA
        if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(settingDef);
#endif
    }
    private void restoreFailed()
    {
        rc = null;
        GameManager.gm.toggleLoading(false);
        localData.text = "<b>Local</b>";
        cloudData.text = "<b>Cloud</b>";
        refreshRestore.SetActive(true);
    }

    public void miscSwitch(string code)
    {
#if UNITY_WSA
        if (GameManager.ifJoyStick)
        {
            switch (code)
            {
                case "i":UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(settingDef);break;
                case "o": UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(settingButton); break;
                case "n": UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(rankButton); break;
                case "s": UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(shareButton); break;
                case "ti": UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(infoDef); break;
                case "r": UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(rankDef); break;
            }
        }

#endif
    }

    public Renderer musicBtn;
    public Renderer sfxBtn;
    public Renderer platformHighsoreBtn;

    public void toggleAudio(bool isMusic)
    {
        AudioManager.am.toggleAudio(isMusic);
        char c;
        if (isMusic) c = 'm';
        else c = 's';
        setAudioButtons(c);
    }

    void setAudioButtons(char c)
    {
        string matName;
        //setting single button
        if (c != 'a')//a is for all
        {
            Renderer ren;
            if (c == 'm')//m is for music
            {
                ren = musicBtn;
                if (AudioManager.musicEnabled) matName = "buttonMusicOn";
                else matName = "buttonMusicOff";
            }
            else //if (c == 's')//s is for sfx
            {
                ren = sfxBtn;
                if (AudioManager.sfxEnabled) matName = "buttonSoundOn";
                else matName = "buttonSoundOff";
            }
            ren.material = Resources.Load("ButtonMaterials/" + matName, typeof(Material)) as Material;
        }
        //if setting both buttons
        else
        {
            //setting the music button
            if (AudioManager.musicEnabled) matName = "buttonMusicOn";
            else matName = "buttonMusicOff";
            musicBtn.material = Resources.Load("ButtonMaterials/" + matName, typeof(Material)) as Material;

            //setting the sfx button
            if (AudioManager.sfxEnabled) matName = "buttonSoundOn";
            else matName = "buttonSoundOff";
            sfxBtn.material = Resources.Load("ButtonMaterials/" + matName, typeof(Material)) as Material;
        }
    }

    public void openPrivacyPolicy()
    {
        Application.OpenURL(privacyPolicy);
    }
}
