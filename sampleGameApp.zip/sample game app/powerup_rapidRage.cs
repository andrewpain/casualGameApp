﻿using UnityEngine;
//using System.Collections;

public class powerup_rapidRage : powerUp {

    //public float timeActive = 10f;
    //public bool isActive = false;

    private GameObject[] allenemies;
    private GameObject[] allprojectiles;
    
    //ce - closest enemy
    public GameObject closestEnemy;
    public GameObject autoAimPro;
    public GameObject crossHair;
    Transform player;
    private float dis;

    //private float timeStart;
    // Use this for initialization
    void Start()
    {

        if (GameManager.gm && GameManager.gm.player)
        {
            player = GameManager.gm.player.transform;// GameObject.FindGameObjectWithTag("Player");
            crossHair = Instantiate(crossHair);
            //crossHair.SetActive(false);
        }
    }
	
	float waitTime = 0f;
	public float fireRate = .1f;

    public bool timePast()
    {
        bool b = Time.time > waitTime;
        if (b) waitTime = Time.time + fireRate;
        return b;
    }

    public void takeShot(Vector3 pos, Quaternion rot)
    {
		//if(Time.time > waitTime)
		//{
        //waitTime = Time.time + fireRate;
        Instantiate(autoAimPro, pos, rot);// as GameObject;
		//}
    }

    public override void activeOff()
    {
        //GameManager.gm.crossHair.disableCrosshair();
        Destroy(crossHair);
        base.activeOff();
    }
	// Update is called once per frame
	public override void Update () {
        base.Update();
        if (isActive && player && GameManager.gm && GameManager.gm.gameState == GameManager.gameStates.Playing)
        {
            dis = 0;
            //tbc - used to determine if player is using dual weapons
            //ce - closest enemy
            GameObject temp_ce= closestEnemy;
            float temp;//stores the distance for each enemy

            allenemies = GameObject.FindGameObjectsWithTag("Enemy");
            //else allenemies = GameObject.FindGameObjectsWithTag("Boss");
            allprojectiles = GameObject.FindGameObjectsWithTag("Enemy_projectile");

            //if there are projectiles
            if (allprojectiles.Length != 0)
            {
                temp_ce = allprojectiles[0];
                dis = Vector3.Distance(player.position,allprojectiles[0].transform.position);
                for (int i = 1; i < allprojectiles.Length; i++)
                {
                    temp = Vector3.Distance(player.position, allprojectiles[i].transform.position);
                    if (temp < dis)
                    {
                        dis = temp;
                        temp_ce = allprojectiles[i];
                    }
                }

            }
            //if there are no projectiles but there are enmeies, or the closest is a caution missile
            else if(allenemies.Length!=0)
            {
                temp_ce = allenemies[0];
                dis = Vector3.Distance(player.position, allenemies[0].transform.position);
                for (int i = 1; i < allenemies.Length; i++)
                {
                    temp = Vector3.Distance(player.position, allenemies[i].transform.position);
                    if (temp < dis)
                    {
                        dis = temp;
                        temp_ce = allenemies[i];
                    }
                }
            }
            //OLD: making the ex closest back to regular view, and new closest to "rapid mode" view
            //UPDATE: replacing the old closest enemy to the new closest enemy alone

            if (temp_ce != closestEnemy)
            {
                closestEnemy = temp_ce;
            }
            //setting the crosshair to be shown where the target is
            //if (closestEnemy) GameManager.gm.crossHair.enableCrosshair(Camera.main.WorldToScreenPoint(closestEnemy.transform.position));
            //else GameManager.gm.crossHair.disableCrosshair();
            if (closestEnemy)
            {
                Vector3 p = new Vector3(closestEnemy.transform.position.x, closestEnemy.transform.position.y, crossHair.transform.position.z);
                crossHair.transform.position = Vector3.Lerp(crossHair.transform.position, p, Time.unscaledDeltaTime* 20);

            }
        }
    }
}
