﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class typeInfo : MonoBehaviour {

    public string typeTitle;
    public string typeDesc;
    public string typeAni;

}
