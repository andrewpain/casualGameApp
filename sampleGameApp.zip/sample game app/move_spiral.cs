﻿//using UnityEngine;
//using System.Collections;
//using System;

public abstract class move_spiral : movement
{
    //ideally between .01f and .04f
    public float spiralWidener = .04f;
    protected float timechecker = 0;
    // Use this for initialization
    public override void Start()
    {
		startPoints();
        //base.Start();
        speed = 3f;
		//slowMotionCheck();

    }
    public override void startPoints() { }

    protected override void calMove()
    {
        timechecker += .018f;
    }


}
