﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class tutorialStuff : MonoBehaviour {

    public GameObject touchAnimation, dontTouchAnimation,moveAnimation,powerUpAnimation;
    //current tutorial animation 
    GameObject g;
	// Use this for initialization
	void Start () {
        StartCoroutine(startTutorial());
	}

    IEnumerator startTutorial()
    {
        print("tutorialStarted");
        yield return new WaitUntil(() => GameManager.sceneLoaded);
        //these disables the chance of these game objects showing up on screen
        GameManager.gm.spawn.coinUsed = true;
        GameManager.gm.spawn.bombCurrent = true;
        GameManager.gm.tutorialMode = true;//for projectiles
        GameManager.gm.spawn.giftCurrent = true;
        GameManager.gm.spawn.suicideUsed = true;

        yield return new WaitUntil(() => GameManager.gm.gameState == GameManager.gameStates.Playing);

        //creates animation teaching the player to shoot, waits till a point is gained, destroys animation, then sets  wait back to normal
        print("teaching to shoot");
        g = Instantiate(touchAnimation);
        yield return new WaitUntil(() => GameManager.gm.score > 0);

        //setting up spawner for coins
        print("teaching to shoot coins");
        GameManager.gm.spawn.coinUsed = false;
        int temp = GameManager.gm.spawn.enemiesPerCoin;
        GameManager.gm.spawn.enemiesPerCoin = 0;
        yield return new WaitUntil(() => GameManager.gm.coinAmount> 0);
        GameManager.gm.spawn.enemiesPerCoin = temp;
        Destroy(g);

        //sets up spawner for bomb to appear
        print("teaching to not shoot bombs");
        GameManager.gm.spawn.bombCurrent = false;
        temp = GameManager.gm.spawn.enemiesPerBomb;
        GameManager.gm.spawn.enemiesPerBomb = 0;
        yield return new WaitUntil(() => GameManager.gm.spawn.bombCurrent);
        GameManager.gm.spawn.enemiesPerBomb = temp;
        g = Instantiate(dontTouchAnimation);

        yield return new WaitWhile(() => GameManager.gm.spawn.bombCurrent);
        GameManager.gm.spawn.bombCurrent = true;
        Destroy(g);

        //teaching the player to move
        print("teaching the player to move");
        g = Instantiate(moveAnimation);
        GameManager.gm.tutorialMode = false;
        move_player mp = GameManager.gm.player.GetComponent<move_player>();
        yield return new WaitUntil(() => mp.moved);
        yield return new WaitForSeconds(2f);
        yield return new WaitUntil(() => mp.moved);
        yield return new WaitWhile(() => mp.moved);
        GameManager.gm.tutorialMode = true;
        Destroy(g);


        //teaching the player to get power up
        print("teaching the player to get power up");
        g = Instantiate(touchAnimation);
        GameManager.gm.spawn.giftCurrent = false;
        temp = GameManager.gm.spawn.enemiesPerGift;
        GameManager.gm.spawn.enemiesPerGift = 0;
        yield return new WaitUntil(() => GameManager.gm.spawn.giftCurrent);
        yield return new WaitWhile(() => GameManager.gm.powerUps[0]==null);
        GameManager.gm.spawn.enemiesPerGift = temp;
        GameManager.gm.spawn.giftCurrent = true;
        Destroy(g);


        //teaching the player to use power up
        print("teaching the player to use power up");
        g = Instantiate(GameManager.gm.newPowerAnimation,GameManager.gm.powerImages[0].transform.position,Quaternion.identity);
		ParticleSystem ps = g.GetComponent<ParticleSystem>();
        ParticleSystem.MainModule psm = ps.main;
        psm.loop = true;
        yield return new WaitUntil(() => GameManager.powerActive != powerUp.powerType.none);
        psm.loop = false;

        GameManager.gm.spawn.bombCurrent = false;
        GameManager.gm.tutorialMode = false;
        GameManager.gm.spawn.giftCurrent = false;
        GameManager.gm.spawn.suicideUsed = false;

        print("End of Tutorial");
		//ADD BANNER INDICATING THE END OF THE TUTORIAL
		
        PlayerPrefs.SetInt(GameManager.tutorialKey, 0);
        Destroy(gameObject);
    }

    private void LateUpdate()
    {
        if (GameManager.gm.gameState == GameManager.gameStates.GameOver && g) Destroy(g);         
    }
}
