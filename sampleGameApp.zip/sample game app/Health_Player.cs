﻿using UnityEngine;
using System.Collections;
//using System;

public class Health_Player : Health
{
    //[HideInInspector]
    int healthPoints;
    Transform lifeContainer;
    public int startHealthPoints = 1;
    public int respawnHealthPoints = 1;
    public int numberOfLives = 2;
    public GameObject ringExplosion;
    private Vector3 respawnPosition;
    private Quaternion respawnRotation;
    GameObject heartSprite;
    GameObject heartExp;
    GameObject[] hearts = new GameObject[4];
    private bool vibe;
    private readonly bool dieAnim;
    //Animator ani;
    // Use this for initialization
    public override void Start()
    {
        // store initial position as respawn location
        vibe = SystemInfo.supportsVibration;
        respawnPosition = new Vector3(0,GameManager.playerYPos,GameManager.playerZPos);// transform.position;
        respawnRotation = transform.rotation;

        heartSprite = Resources.Load("hearts/heartObject", typeof(GameObject)) as GameObject;
        heartExp = Resources.Load("hearts/heartExp", typeof(GameObject)) as GameObject;
        GameObject go = new GameObject("HeartsHolder");
        go.transform.parent = transform;
        go.transform.localPosition = new Vector3(0, .8f, 0);
        lifeContainer = go.transform;
        //ani = GetComponent<Animator>();y
    }


    public void setLife()
    {
#if !UNITY_EDITOR
        if (startHealthPoints > 3) startHealthPoints = 2;//MORE THAN 3 CONDITION ONLY FOR TESTING
#endif
        healthPoints = startHealthPoints;
        for (int i = 0; i < healthPoints; i++)
			editHearts(true);
    }
	
    public override void ApplyDamage(float amount)
    {
#if UNITY_EDITOR
        if (healthPoints > 3) return;//MORE THAN 3 CONDITION ONLY FOR TESTING
#endif
        if ((int)amount < 1) amount = 1;//in case the amount as an interger is not at least 1

        if (isAlive && GameManager.gm && GameManager.powerActive != powerUp.powerType.shield && !GameManager.gm.jumping)//MORE THAN 3 CONDITION ONLY FOR TESTING
        {
            healthPoints -= (int)amount;
#if UNITY_EDITOR || UNITY_ANDROID || UNITY_IOS || UNITY_WSA_10_0        
            if (vibe)Handheld.Vibrate();
#endif
            //if (ani) ani.SetTrigger("hit");
            //if the mission for not losing life exists
            if (GameManager.gm.currentMission && GameManager.gm.currentMission.missionAlias2 == mission.missionType2.noLifeLost)
                    GameManager.gm.currentMission.progressMission(-1, Vector3.zero, Quaternion.identity);

            if (healthPoints >= 0)
            {
                editHearts(false);
                AudioManager.am.playSound("playerLossHealth");
            }
            if (healthPoints <= 0)
            {
                isAlive = false;
                numberOfLives--;
                activateExplosion();

            }
			
            

        }
    }

    void editHearts(bool b)
    {
        //destroys a heart
        if (!b)
        {
            Instantiate(heartExp, hearts[healthPoints].transform.position, hearts[healthPoints].transform.rotation);
            Destroy(hearts[healthPoints]);
            if (healthPoints + 1 < startHealthPoints)
            {
                //making sure other hearts that are suppose to be destroyed are destroyed
                for (int i = healthPoints + 1; i < startHealthPoints; i++)
                    if (hearts[i]) Destroy(hearts[i]);
            }
            //changes positions of hearts when heart is destroyed
            if (healthPoints < 4)//ASSUMING MAX HEALTH IS 4
            {
                int l = hearts.Length;
                for (int i = 0; i < l && hearts[i] != null; i++)
                {
                    Vector3 v = hearts[i].transform.localPosition;
                    hearts[i].transform.localPosition = new Vector3(v.x + .25f, 0,0);
                }
            }
        }
        //creates a heart
        else
        {
			bool heartCreated = false;
            for (int i = 0; i < hearts.Length && !heartCreated; i++)
            {
                if (hearts[i] == null)
                {
                    hearts[i] = Instantiate(heartSprite,lifeContainer);
					hearts[i].transform.localPosition = new Vector3(0,0,0);
                    if (i > 0)
                    {
                        Vector3 v = hearts[i-1].transform.localPosition;// heartSprite.transform.localPosition;
                        hearts[i].transform.localPosition = new Vector3(v.x +.5f,0,0);
                        int l = hearts.Length;
                        for (int j = 0; j < l && hearts[j] != null; j++)
                            hearts[j].transform.localPosition = new Vector3(hearts[j].transform.localPosition.x - .25f,0,0);
                    }
                    //break;
					heartCreated = true;
                }

            }
        }
    }
    
    public void respawn()
    {
        //getting rid of parent used for animation, and animation
        //if(gameObject.GetComponent<Animator>())Destroy(gameObject.GetComponent<Animator>());
        Animator a = GetComponent<Animator>();
        a.runtimeAnimatorController = Resources.Load("anim/playerPlay") as RuntimeAnimatorController;

        GameObject p = transform.parent.gameObject;
        p.transform.DetachChildren();
        Destroy(p);
        // reset the player to respawn position and rotation
        transform.position = respawnPosition;
        transform.rotation = respawnRotation;
        transform.localScale = new Vector3(1, 1, 1);
        healthPoints = respawnHealthPoints; // give the player health 
        isAlive = true;
        //if (ani)ani.SetTrigger("survive");
        //GameManager.gm.lifebar.fillAmount = respawnHealthPoints / startHealthPoints;
        editHearts(true);
        GameObject g = Instantiate(Resources.Load("hearts/moreLifeParticle", typeof(GameObject))) as GameObject;
        g.transform.parent = gameObject.transform;
        g.transform.localPosition = new Vector3(0, 0, 0);
        
        AudioManager.am.playSound("respawn");
    }
    public void ApplyHeal(int amount)
    {
        if (healthPoints < startHealthPoints)
        {
            healthPoints = healthPoints + amount;
            //GameManager.gm.lifebar.fillAmount = healthPoints / startHealthPoints;
            editHearts(true);
            GameObject g = Instantiate(Resources.Load("hearts/moreLifeParticle", typeof(GameObject))) as GameObject;
            g.transform.parent = gameObject.transform;
            g.transform.localPosition = new Vector3(0, 0, 0);
            AudioManager.am.playSound("applyHeal");
        }
    }

    //public void ApplyBonusLife(int amount)
    //{
    //    numberOfLives = numberOfLives + amount;
    //}

    public override void activateExplosion()
    {
        if (explosionPrefab) Instantiate(explosionPrefab, transform.position, transform.rotation);
        if (ringExplosion && numberOfLives<=0)   Instantiate(ringExplosion, transform.position, transform.rotation);
        //adds player animation here
        GameObject g = new GameObject();
        g.transform.position = transform.position;
        transform.parent = g.transform;
        transform.localPosition = new Vector3(0,0,0);
        //Animator a = gameObject.AddComponent<Animator>();
        Animator a = GetComponent<Animator>();
        a.runtimeAnimatorController = Resources.Load("anim/playerAnim") as RuntimeAnimatorController;
        //reverses if player is on right side of screen
        if (Camera.main.WorldToScreenPoint( transform.position).x > Screen.width / 2) g.transform.localScale = new Vector3(-1f, 1f, 1f);
        if (numberOfLives <= 0 || GameManager.gm.score > GameManager.gamePlayer.score) a.SetTrigger("soar");
        else a.SetTrigger("fall");
        AudioManager.am.playSound("dying");
    }
    //called by animations when player loses all health
    void takeSnapShot()
    {
        StartCoroutine(takingSnapShot());
    }

    IEnumerator takingSnapShot()
    {

        string ss = gameOverControl.getScreenShotName(true);

        yield return new WaitForEndOfFrame();
		try
		{
#if !UNITY_WSA
            ScreenCapture.CaptureScreenshot(ss);
#elif UNITY_WSA
            
            Texture2D screenImage = new Texture2D(Screen.width, Screen.height);
            //Get Image from screen
            screenImage.ReadPixels(new Rect(0, 0, Screen.width, Screen.height), 0, 0);
            screenImage.Apply();
            //Convert to png
            byte[] imageBytes = screenImage.EncodeToPNG();

            //Save image to file
			//#if UNITY_EDITOR
            System.IO.File.WriteAllBytes(gameOverControl.getPathUri(ss), imageBytes);
			//#else
			//WSAUnity.TextUtils.WriteAllBytes(ss, imageBytes);
		    //#endif
#endif
        }
		catch (System.Exception e)
        {
            print("COULD NOT SAVE SCREEN SHOT: "+e.Message);
        }
		//print("took snashot");
        if (numberOfLives > 0) GameManager.gm.playerDying();
        else GameManager.gm.playerDies();
    }

}
