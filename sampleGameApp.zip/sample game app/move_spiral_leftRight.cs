﻿using UnityEngine;
//using System.Collections;

public class move_spiral_leftRight : move_spiral
{


    public override void startPoints()
    {
        Vector3 minrange = GameManager.gm.MinRange;
        Vector3 maxrange = GameManager.gm.MaxRange;
        
        float randomx = minrange.x + (transform.lossyScale.x / 2);
        float randomy = 4.5f;
        float randomz = Random.Range(minrange.z + (transform.lossyScale.z / 2), maxrange.z - (transform.lossyScale.z / 2));
		if (minrange.z==maxrange.z) randomz =  maxrange.z;//TESTING FOR 2D GAME - (transform.lossyScale.z / 2);


        transform.position = new Vector3(randomx, randomy, randomz);
    }

    protected override void calMove()
    {
        base.calMove();
        gameObject.transform.Translate(transform.up * Mathf.Cos(timechecker) * spiralWidener);
        gameObject.transform.Translate(transform.right * speed * Time.deltaTime);
    }

    protected override bool ifBeyondBorders()
    {
        return transform.position.x + (transform.lossyScale.x / 2) >= GameManager.gm.MaxRange.x;
    }
}
