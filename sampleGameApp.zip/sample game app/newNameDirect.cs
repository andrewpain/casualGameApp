﻿using UnityEngine;
using UnityEngine.UI;
/**
 * This is to enable / disable the buttons and 
 * display the arrow directing the player to the rankings button
 * if the player does not have a name saved already
     */
public class newNameDirect : MonoBehaviour {


    private void OnEnable()
    {
        //if player name doesn't exist on server, and there is internet connectivity
        if (GameManager.gamePlayer.id!="" 
            && GameManager.gamePlayer.playerId == "" 
            && GameManager.conMade 
            && Application.internetReachability != NetworkReachability.NotReachable)
        {
            //and the arrow is not active yet
            if (!transform.GetChild(0).gameObject.activeSelf)
            {
                int count = 0;
                for (int i = 3; i < transform.childCount && count<3; i++)
                {
                    count++;
                    Button b = transform.GetChild(i).GetComponent<Button>();

                    if (b)b.interactable = false;
                }
            }
            //THIS IS STATICLY SET TO THE FIRST CHILD IN THE PANEL!!
            GameObject d = transform.GetChild(0).gameObject;
            d.SetActive(true);
            Animator a = d.GetComponent<Animator>();
            a.SetTrigger("direct");
            print("arrow enabled");

        }

        else if (transform.GetChild(0).gameObject.activeSelf)
        {
            int count = 0;
            for (int i = 3; i < transform.childCount && i<count; i++)
            {
                count++;
                Button b = transform.GetChild(i).GetComponent<Button>();
                if(b)b.interactable = true;
            }
            //THIS IS STATICLY SET TO THE FIRST CHILD IN THE PANEL!!
            GameObject d = transform.GetChild(0).gameObject;
            d.SetActive(false);
            print("arrow disabled");
        }
    }
}
