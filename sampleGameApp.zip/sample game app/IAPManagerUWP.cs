﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;
#if UNITY_WSA //&& !UNITY_EDITOR
using WSAUnity;
//using Microsoft.UnityPlugins;
#endif

public class IAPManagerUWP : IAPParent
{


    // Start is called before the first frame update
    public override void Start()
    {
        base.Start();

        InitializePurchasing();



    }

    public override void InitializePurchasing()
    {
        Debug.Log("InitializePurchasing Started");
        //apparently you only call this for testing, else the store will call the real windows store products
#if UNITY_WSA //&& !UNITY_EDITOR

        // Store.LoadListingInformation((res) =>
        // {

            // if (res.Status == CallbackStatus.Failure)
            // {
                // //GameManager.gm.timedMsg("LoadListingInformation Error:" + res.Exception.Message);
                // print("LoadListingInformation Error:" + res.Exception.Message);
                // return;
            // }

            // //GameManager.gm.timedMsg("LoadListingInformation Success! :" + res.Status);
            // Debug.Log(res.Result.Description.ToString());
            // foreach (var productListingKey in res.Result.ProductListings.Keys)
            // {
                // Debug.Log("Key: " + productListingKey + " value: " + res.Result.ProductListings[productListingKey].Name);
            // }

            // initialized = true;

            
        // });
        initialized = true;

        if (PlayerPrefs.HasKey(fulfilled1)) fulfillPurchase(product_250_Gold, PlayerPrefs.GetString(fulfilled1));
        if (PlayerPrefs.HasKey(fulfilled2)) fulfillPurchase(product_1000_Gold, PlayerPrefs.GetString(fulfilled2));
        if (PlayerPrefs.HasKey(fulfilled3)) fulfillPurchase(product_5000_Gold, PlayerPrefs.GetString(fulfilled3));
        if (PlayerPrefs.HasKey(fulfilled4)) fulfillPurchase(product_20000_Gold, PlayerPrefs.GetString(fulfilled4));




#endif
    }

    public override bool IsInitialized()
    {
        return initialized;
    }

    public override void BuyProductID(string productId)
    {
        if (IsInitialized())
        {
#if UNITY_WSA //&& !UNITY_EDITOR

            Store.RequestProductPurchase(productId, (response) =>
            {
                int collect = 0;
                bool done = false;
                if (response.Status == CallbackStatus.Failure)
                {
                    GameManager.gm.timedMsg("RequestProductPurchase Failure: " + response.Exception.Message);
                    print("RequestProductPurchase Failure: " + response.Exception.Message);
                    //finishPurchase(false, 0);
					processing = false;
                    return;
                }
                else if (response.Result.Status == ProductPurchaseStatus.Succeeded)
                {
                    done = true;
                    if (productId == product_250_Gold) collect = 250;
                    else if (productId == product_1000_Gold) collect = 1000;
                    else if (productId == product_5000_Gold) collect = 5000;
                    else if (productId == product_20000_Gold) collect = 20000;

                    //finishPurchase(true, collect);
                    //prettyPrintSuccess("RequestProductPurchase", response);
                    //text.text = "\nPurchase status: " + response.Result.Status.ToString() + text.text + "\n";
                    Debug.Log("Purchase Status: " + response.Result.Status.ToString());
                    Debug.Log("Purchase OfferId: " + response.Result.OfferId);
                    Debug.Log("Purchase ReceiptXml: " + response.Result.ReceiptXml);

                    fulfillPurchase(productId, response.Result.TransactionId.ToString());

                }
                finishPurchase(done,collect);
                
                //Store.VerifyReceipt(response.Result.ReceiptXml, (ReceiptResponse) =>
                //{
                //    Debug.Log("response: " + ReceiptResponse.Result.AppId);
                //    Debug.Log("response: " + ReceiptResponse.Result.IsValidReceipt.ToString());
                //});
            });
#endif
        }
        else
        {
            // ... report the product look-up failure situation  

            Debug.Log("BuyProductID: FAIL. Not purchasing product, either is not found or is not available for purchase");
            processing = false;
            GameManager.gm.timedMsg("BuyProductID: FAIL. Not purchasing product, either is not found or is not available for purchase");
        }

    }
    static readonly string fulfilled1 = "sampleFulfilled1";
    static readonly string fulfilled2 = "sampleFulfilled2";
    static readonly string fulfilled3 = "sampleFulfilled3";
    static readonly string fulfilled4 = "sampleFulfilled4";
    void fulfillPurchase(string productId, string transId)
    {
        if      (productId == product_250_Gold) PlayerPrefs.SetString(fulfilled1, transId);
        else if (productId == product_1000_Gold) PlayerPrefs.SetString(fulfilled2, transId);
        else if (productId == product_5000_Gold) PlayerPrefs.SetString(fulfilled3, transId);
        else if (productId == product_20000_Gold) PlayerPrefs.SetString(fulfilled4, transId);

        System.Guid guid = new System.Guid(transId);
#if UNITY_WSA //&& !UNITY_EDITOR

        Store.ReportConsumableFulfillment(productId, guid, (response) =>
        {
            if (response.Status == CallbackStatus.Failure)
            {
                //prettyPrintErrors("ReportConsumablesFulfilled", response);
                print("ReportConsumablesFulfilled: " + response);
                return;
            }
            else if (response.Result == FulfillmentResult.Succeeded)
            {
                if (productId == product_250_Gold) PlayerPrefs.DeleteKey(fulfilled1);
                else if (productId == product_1000_Gold) PlayerPrefs.DeleteKey(fulfilled2);
                else if (productId == product_5000_Gold) PlayerPrefs.DeleteKey(fulfilled3);
                else if (productId == product_20000_Gold) PlayerPrefs.DeleteKey(fulfilled4);
            }
            //prettyPrintSuccess("ReportConsumableFulfillment", response);
            Debug.Log("Reported Consumable Fulfillment Result: " + response.Result.ToString());
            //GameManager.gm.timedMsg("Reported Consumable Fulfillment Result: " + response.Result.ToString());
            //text.text = "\nReported Consumable fulfillment Result: " + response.Result.ToString() + text.text + "\n";
        });
#endif
    }


}
