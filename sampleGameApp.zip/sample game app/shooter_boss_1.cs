﻿//using UnityEngine;
//using System.Collections;

public class shooter_boss_1 : shooter_boss
{

    //public override void shoot()
    //{
    //    if (isShooting)
    //    {

    //        /*else if (!lowLife)*/
    //        base.shoot();

    //        if (lowLife)
    //        {
    //            //// Instantiante projectile at the camera + 1 meter forward with camera rotation
    //            //GameObject np = Instantiate(projectile1, transform.position + transform.forward - transform.up, transform.rotation) as GameObject;
    //            //GameManager.gm.editProjectileCount(1);
    //            //float deltaZ = zPos - np.transform.position.z;
    //            //float deltaY = yPos - np.transform.position.y;
    //            //float angle = (Mathf.Atan2(deltaY, deltaZ) * Mathf.Rad2Deg) - 180;
    //            ////if it is required to shoot any more than 1 at a time

    //            //GameObject np1 = Instantiate(projectile, transform.position + transform.forward - transform.up, transform.rotation) as GameObject;
    //            //GameManager.gm.editProjectileCount(1);
    //            //GameObject np2 = Instantiate(projectile, transform.position + transform.forward - transform.up, transform.rotation) as GameObject;
    //            //GameManager.gm.editProjectileCount(1);
    //            //np1.transform.Rotate(angle, rotateBy, 0f);
    //            //np2.transform.Rotate(angle, -rotateBy, 0f);


    //        }




    //    }
    //}

    //protected override void shoot2()
    //{
    //    // Instantiante projectile at the camera + 1 meter forward with camera rotation
    //    Instantiate(projectile1, transform.position + transform.forward - transform.up, transform.rotation);
    //    GameManager.gm.editProjectileCount(1);
    //}
}
