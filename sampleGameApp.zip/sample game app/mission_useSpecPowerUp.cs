﻿using UnityEngine;
//using System.Collections;

public class mission_useSpecPowerUp : mission
{

    public powerUp.powerType missionPowerUp;
    public override void setMissionStart(int cc, int mc, string mi)
    {
        base.setMissionStart(cc, mc,mi);
        missionAlias = missionType.usePowerUp;
        //setting the power up type that is to be counted for mission
        if (misc == "")
        {
            switch (Random.Range(0, 4))
            {
                case 0: misc = powerUp.powerType.shield.ToString(); missionPowerUp = powerUp.powerType.shield; break;
                case 1: misc = powerUp.powerType.grenade.ToString(); missionPowerUp = powerUp.powerType.grenade; break;
                case 2: misc = powerUp.powerType.auto.ToString(); missionPowerUp = powerUp.powerType.auto; break;
                case 3: misc = powerUp.powerType.slow.ToString(); missionPowerUp = powerUp.powerType.slow; break;
            }
        }
        else
        {
            switch (misc)
            {
                case "shield" : missionPowerUp = powerUp.powerType.shield; break;
                case "grenade": missionPowerUp = powerUp.powerType.grenade; break;
                case "auto"   : missionPowerUp = powerUp.powerType.auto; break;
                case "slow"   : missionPowerUp = powerUp.powerType.slow; break;
            }
        }
        //if max count not set, thus new mission
        setDiff(4, 8, 12);
        //setDiff(1,1,1);

    }

    public override string getStatus()
    {
        if (!complete)return string.Format("Use {0} {1} power ups. {2}/{3} completed", maxCount, misc, count, maxCount);
        else return string.Format("Use {0} {1} power ups completed! :)", maxCount, misc);

    }

    //public override string getDoneMsg()
    //{
    //    return string.Format("Use {0} {1} power ups completed! :)", maxCount, misc);
    //}

    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        if (GameManager.gm.activePowerUp.powerName == missionPowerUp)
        {
            count += p;
            if (count >= maxCount) finishMission();
        }
    }
}
