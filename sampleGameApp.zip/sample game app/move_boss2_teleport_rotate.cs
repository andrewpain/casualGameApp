﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class move_boss2_teleport_rotate : move_boss
{

    //private bool turn = false;
    // Use this for initialization
    bool visible = true;
    bool teleporting = false;
    float timeStart = 0;
    public bool shooting = true;

    //public MeshRenderer meshRen;
    BoxCollider bc;
    Animator an;

    Vector3 minRange;
    Vector3 maxRange;
    public override void startPoints()
    {
        speed = 0;

        //mr = gameObject.GetComponent<Health_Boss>().visibleRenderers[0].gameObject.GetComponent<MeshRenderer>();
        bc = gameObject.GetComponent<BoxCollider>();
        an = gameObject.GetComponent<Animator>();

        minRange = GameManager.gm.MinRange;
        maxRange = GameManager.gm.MaxRange;

        randomPos();
        
        timeStart = Time.time;
    }
    void randomPos()
    {
        float randomx = UnityEngine.Random.Range(minRange.x +1 + (transform.lossyScale.x / 2), maxRange.x -1- (transform.lossyScale.x / 2));//middle
        float randomy = UnityEngine.Random.Range(minRange.y /*+ 2*/ + (transform.lossyScale.y / 2), maxRange.y - 1 - (transform.lossyScale.y / 2));//middle
        //float randomz = /*maxRange.z - 1;*/ 0f;// closer to player than where enemies usually spawn


        //TESTING FOR 3D GAME
        //float randomz = minRange.z - (transform.lossyScale.z / 2); //minRange.z;
        transform.position = new Vector3(randomx, randomy, GameManager.gm.MinRange.z/*transform.position.zrandomz*/);
    }
    Vector3 currScale;
    void disappearNow()
    {
        visible = false;
        timeStart = Time.time;
        //QUEUE DISAPPEAR ANIMATION
        //meshRen.enabled = false;
        //currScale = transform.localScale;
        //transform.localScale = new Vector3(0, 0, 0);
        bc.enabled = false;
    }

    protected override void calMove()
    {
        //if boss is visible
        if (visible && shooting && (Time.time - timeStart) >= 15f )
        {
		    an.SetTrigger("idle");
            shooting = false;
            timeStart = Time.time;
            print("shooting stopped");
        }
        else if (visible && !shooting && !teleporting && (Time.time- timeStart) >=5f)
        {
            teleporting = true;
            //QUEUE ANIMATION WHICH THEN TRIGGERS THE DISAPPEARNOW METHOD
            an.SetTrigger("teleport");
            print("teleporting");
        }
        //if bossis invisible / teleporting
        else if (!visible && (Time.time - timeStart) > 2)
        {
            print("shooting again");
            randomPos();
            timeStart = Time.time;
            visible = true;
            shooting = true;
            teleporting = false;
            //QUEUE ENTER ANIMATION WHICCH THEN QUEUES THE MEDHOD WHICH MAKED THE BOSS VISIBLE AGAIN
            //meshRen.enabled = true;
            an.SetTrigger("reEnter");
            bc.enabled = true;
        }

        //else gameObject.transform.Translate(-transform.right * Time.deltaTime * speed);
    }
}
