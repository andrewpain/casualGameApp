﻿//using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class move_boss1 : move_boss {

    private bool turn = false;
	// Use this for initialization
	//public override void Start () {
		
	//}
    public override void startPoints()
    {
        speed = 3f;

        Vector3 minrange = GameManager.gm.MinRange;
        Vector3 maxrange = GameManager.gm.MaxRange;
        
        float randomx = (minrange.x+ maxrange.x)/2;//middle
        float randomy = maxrange.y - (transform.lossyScale.y / 2)-1f;// at the top of the screen
        //float randomz = 0f;// closer to player than where enemies usually spawn
        //TESTING FOR 3D GAME
        float randomz = minrange.z - (transform.lossyScale.z / 2);// minrange.z;
        transform.position = new Vector3(randomx, randomy, randomz);

    }

    protected override void calMove()
    {
        if (!turn) gameObject.transform.Translate(transform.right * Time.deltaTime * speed);

        else gameObject.transform.Translate(-transform.right * Time.deltaTime * speed);
    }

    //protected override void OnTriggerExit(Collider other){}

    protected override void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "wallLeft") turn = false;
        else if (other.gameObject.name == "wallRight") turn = true;
    }
    protected override void OnTriggerStay(Collider other){}
}
