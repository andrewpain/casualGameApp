﻿using UnityEngine;
//using System.Collections;
// hits enemies in a row without losing life
public class mission_hitNoLifeLost : mission
{
    //private GameObject progressAnimation = Resources.Load("missions/hitEnemies", typeof(GameObject)) as GameObject;
    //private void Start()
    //{
    //    progressAnimation = Resources.Load("missions/hitEnemies", typeof(GameObject)) as GameObject;
    //}
    public override void setMissionStart(int cc, int mc, string mi)
    {
        oneGame = true;
        //all base does is set the current count
        base.setMissionStart(cc, mc,mi);
        missionAlias = missionType.hitEnemy;
        missionAlias2 = missionType2.noLifeLost;
        //if the mission hasnt been set, thus new mission
        setDiff(50, 150, 300);
        //setDiff(1, 2, 3);
        //doneMessage = "Hit " + maxCount + " enemies without missing completed! :)";

    }


    public override string getStatus()
    {
        if (!complete)return "Hit " + maxCount + " enemies without losing a life. " + count + "/" + maxCount + " completed";
        else return "Hit " + maxCount + " enemies without losing any lives completed! :)";

    }
    //public override string getDoneMsg()
    //{
    //    return "Hit " + maxCount + " enemies without losing any lives completed! :)";
    //}
    bool lFull = true;
    public override void progressMission(int p, Vector3 pos, Quaternion rot)
    {
        if (lFull && !complete)
        {
            if (p > 0)
            {
                count += p;
                Instantiate(progressParticle, pos, rot);
            }
            else lFull = false;
            if (count >= maxCount && lFull) finishMission();
        }
    }


}
