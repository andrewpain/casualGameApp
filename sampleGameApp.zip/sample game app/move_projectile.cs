﻿using UnityEngine;
using System.Collections;

public abstract class move_projectile : movement
{
    public bool aimAtPlayer = false;
    public Transform target;
    public GameObject groundExplosion;
    //[HideInInspector]
    GameObject fakeTargetObject;
    protected bool fakeTarget = false;

    public override void Start()
    {
        if (GameManager.gm)
        {
            //speed = GameManager.gm.level + 3f;
            //if (speed > 5f) speed = 5f;
            //if (GameManager.gm.bossMode && speed != 4f) speed = 4f;

            //TESTING FOR POSSIBLE 2D
            speed = GameManager.gm.proSpeed;
            if (speed > 4f) speed = 4f;
            if (GameManager.gm.bossMode && speed > 4f) speed = 4f;

            if (aimAtPlayer && GameManager.gm.player && GameManager.gm.playerInfo.lessSuicide && Random.value > .2f)
            {
                //print("fake position");
                //GOING WITH THE ASSUMPTION THAT THE PLAYER DOESN'T MOVE
                Vector3 p = GameManager.gm.player.transform.position;
                float xPos;
                float v;//v for value
                if (Random.value < .5) v = -2f;
                else v= 2f;
                xPos = p.x + v;
                //Vector3 pos = new Vector3(xPos,0, p.z);
                //GameObject fakeG = new GameObject("fakePos");
                fakeTargetObject = new GameObject("fakePos");
                fakeTargetObject.transform.position = new Vector3(xPos, 0, p.z); //pos;
                target = fakeTargetObject.transform;
                fakeTarget = true;
                StartCoroutine(fakeTargetMove(v));
            }
            else if (aimAtPlayer && GameManager.gm.player) target = GameManager.gm.player.transform;
        }

    }

    //this makes the fake position stay the same position away from player
    IEnumerator fakeTargetMove(float v)
    {
        if (GameManager.gm)
        {
            Transform pp = GameManager.gm.player.transform;
            Vector3 pos = pp.position;
            while (GameManager.gm && target && GameManager.gm.gameState != GameManager.gameStates.GameOver)
            {
                pos = pp.position;
                pos = new Vector3(pos.x + v, pos.y, pos.z); 
                target.position = Vector3.MoveTowards(target.position,pos,Time.deltaTime * 6f);
                yield return null;
            }
        }
    }

    public void destroyFakeTarget()
    {
        if (fakeTarget)Destroy(fakeTargetObject);
    }
    public override void startPoints(){}
    protected override void OnTriggerEnter(Collider other){}
    protected override void OnTriggerStay(Collider other)
    {
        if (other.gameObject.name == "ground" && !leaving/*&& isAlive*/ && gameObject.transform.position.y <= .5f)
        {
            //isAlive = false;
            //hitSurface = true;
            //CREATE GROUND EXPLOSION HERE AND MAKE SOUND
            AudioManager.am.playSound("proGround", Instantiate(groundExplosion, transform.position, Quaternion.LookRotation(Vector3.up)));
            leave();
        }
    }

    protected override bool ifBeyondBorders()
    {
        return
        transform.position.x + (transform.lossyScale.x / 2) >= GameManager.gm.MaxRange.x ||
        transform.position.x - (transform.lossyScale.x / 2) <= GameManager.gm.MinRange.x ||
        transform.position.y + (transform.lossyScale.y / 2) >= GameManager.gm.MaxRange.y ||
        transform.position.y - (transform.lossyScale.y / 2) <= .5f;
    }


}
