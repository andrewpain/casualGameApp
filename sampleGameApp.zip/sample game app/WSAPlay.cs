﻿using Microsoft.Xbox.Services;
using Microsoft.Xbox.Services.Client;
using Microsoft.Xbox.Services.Leaderboard;
using Microsoft.Xbox.Services.Statistics;
using Microsoft.Xbox.Services.Statistics.Manager;//.StatisticManager.GetLeaderboard
using UnityEngine;
using System.Collections;
//using Microsoft.Xbox.Services.Statistics.Manager.StatisticManager.GetSocialLeaderboard
public class WSAPlay : platformPlay
{
	
    // Start is called before the first frame update
	//static StatisticManager statManager;
    //static XboxLiveUser xboxLiveUser;
    //static readonly string leaderBoardID = "leaderBoards";

    public GameObject leaderBoard;
    Leaderboard showing;

    public GameObject intStat;
    IntegerStat intStats;

    public override void Start()
    {
        base.Start();
    }

    public void xBoxCheck(/*XboxLiveUser user*/string Id)
    {
        //string Id = "";
#if UNITY_EDITOR
        Id = "yaBoyTesting";
//#else
//        Id = user.XboxUserId;
#endif
        //xboxLiveUser = user;



        StartCoroutine(platformIdCheck(Id,"mi"));

    }

	public void postScoreToXbox(int score,bool ifHigh)
	{
        //XboxLive.Instance.StatsManager.SetStatisticIntegerData(xboxLiveUser, /*this.ID*/leaderBoardID, score);

        //interger stats
        GameObject g = Instantiate(intStat);
        intStats = g.GetComponent<IntegerStat>();

        StartCoroutine(waitForXbox(score,ifHigh,false));
        
    }
    public void showXboxLeaderBoard()
    {
        if (intStats == null)
        {
            GameObject g = Instantiate(intStat);
            intStats = g.GetComponent<IntegerStat>();
        }       
        //leaderboard setting
        //Leaderboard lb = leaderBoard.GetComponentInChildren<Leaderboard>();
        //lb.stat = intStats;
		StartCoroutine(waitForXbox(0,false,true));

    }

    IEnumerator waitForXbox(int score, bool ifHigh, bool showLB)
    {
        float tMax = Time.time +3f;
        yield return new WaitUntil(() =>intStats.isLocalUserAdded|| Time.time>tMax);
        if (intStats.isLocalUserAdded)
        {
			if (!showLB)
			{
				intStats.Value = score;
				StatsManagerComponent.Instance.RequestFlushToService(SignInManager.Instance.GetPlayer(intStats.PlayerNumber), true);
                print("SUPPOSE TO HAVE CHANGED XBOX SCORE NOW");
                if (ifHigh && PlayerPrefs.HasKey(GameManager.playerPlatformUnsynchedKey))
					PlayerPrefs.DeleteKey(GameManager.playerPlatformUnsynchedKey);
			}
			else 
			{
				GameObject go = Instantiate(leaderBoard);
                showing = go.GetComponentInChildren<Leaderboard>();
		        showing.stat = intStats;
		        showing.Refresh();
                //STATICLY CHOOSING THE BACK BUTTON WHICH IS SUPPOSED TO BE THE LAST OBJECT
                Transform df = showing.gameObject.transform.GetChild(showing.gameObject.transform.childCount-1);
                if (GameManager.ifJoyStick) UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(df.gameObject);

            }
        }
        else print("XBOX LOCAL USER NOT ADDED. Try again");

    }
    
    public void closeLeaderBoard()
    {
        Destroy(showing.transform.parent.gameObject);
        GameObject.FindObjectOfType<gameOverControl>().miscSwitch("r");
    }
}
