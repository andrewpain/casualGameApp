﻿//using System;
using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class Health_Bomb : Health {
    private GameObject[] allenemies;
    private GameObject[] allprojectiles;
    private GameObject[] allothers;

    public float damageAmount = 2f;
    public GameObject flickerExplosion;
    public float shakeRange = .5f, shakeSpeed = .1f, shakeTime = 2.5f;

    //GameObject flicker;
    //Animator trembler;

    //public override void Start()
    //{
    //    trembler = gameObject.GetComponent<Animator>();
    //}

    public override void ApplyDamage(float amount)
    {
        if (isAlive)
        {
            gameObject.GetComponent<movement>().leaving = true;//.enabled = false;
            isAlive = false;
            if (GameManager.gm & GameManager.gm.playerInfo.lessBombs) StartCoroutine(tremble());
            else selfDestruct(true);
        }

    }
    public float range = .25f;
    public float timeTillExp = 2f;
    IEnumerator tremble()
    {
        Destroy(transform.GetChild(0).gameObject.GetComponent<Rotate>());
        Vector3 p = transform.position;
        //float range = .25f;
        float i = Time.time;
        AudioManager.am.playSound("fuse");

        while (Time.time - i < timeTillExp)
        {
            transform.position = new Vector3(
                p.x + UnityEngine.Random.Range(-range, range), 
                p.y + UnityEngine.Random.Range(-range, range), 
                p.z/*p.z + UnityEngine.Random.Range(-range, range)*/);
            yield return null;// waits till the end of the frame
        }

        selfDestruct(UnityEngine.Random.value > chance/*.4*/);
    }
    bool takeLife=false;
    public void selfDestruct(bool b)
    {
        if (b)
        {
            takeLife = true;
            allenemies = GameObject.FindGameObjectsWithTag("Enemy");
            allprojectiles = GameObject.FindGameObjectsWithTag("Enemy_projectile");
            allothers = GameObject.FindGameObjectsWithTag("OtherObject");

            foreach (GameObject enemy_pro in allprojectiles)
                if (enemy_pro)enemy_pro.GetComponent<Health>().activateExplosion();

            //for (int i = 0; i < allenemies.Length; i++) {
            foreach (GameObject enemy in allenemies)
                if (!enemy.gameObject.name.Contains("boss"))//avoid s the boss from being destroyed
                    enemy.GetComponent<Health>().activateExplosion();
            //other game objects that are to be destroyed - gift, caution missile
            foreach (GameObject oo in allothers)
                if(oo)oo.GetComponent<Health>().activateExplosion();
        }//Debug.Log("BOMB!");
        //Destroy(gameObject);
        activateExplosion();
    }

    private void OnDestroy()
    {
        //making the bomb available again to be used
        if (GameManager.gm) GameManager.gm.spawn.bombCurrent = false;
    }
    [Tooltip("The LOWER the number the more likely it WILL EXPLODE and take player's life")]
    public float chance;
    public override void activateExplosion()
    {
        if (GameManager.gm)
        {
            if (!takeLife)
            {
                AudioManager.am.playSound("fakeBomb", Instantiate(flickerExplosion, transform.position, transform.rotation));
                //Destroy(gameObject);
                StartCoroutine(removeThenDelete());
            }
            else
            {
                explosionSound = "bombExp";
                //applying damage to player
                GameManager.gm.playerHealth.ApplyDamage(damageAmount);
                if (GameManager.gm) GameManager.gm.bombMode = true;
                GameManager.gm.setCamManualMove(shakeRange, shakeSpeed, shakeTime);
                base.activateExplosion();

            }
        }
        //ParticleSystem ps = flicker.GetComponent<ParticleSystem>();
        //ParticleSystem.MainModule psm = ps.main;
        //psm.loop = false;
    }
}
