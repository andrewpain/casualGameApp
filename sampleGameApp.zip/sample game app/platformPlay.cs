﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

public class platformPlay : MonoBehaviour
{
    public static GameObject instance;
    public static bool isAuth = false;
    public static readonly string restoreKey = "sampleR";
    public static readonly string newIdKey = "sampleM";
    // Start is called before the first frame update
    public virtual void Start()
    {
        if (instance == null) instance = gameObject;
        else if (!isAuth)
        {
            Destroy(instance);
            instance = gameObject;
        }
        else
        {
            Destroy(gameObject);
            return;
        }
        DontDestroyOnLoad(gameObject);

    }
    //private void Update()
    //{
    //    print(
    //"Connection Made: " + (GameManager.conMade) + "\n" +
    //"FundaCheck: " + (GameManager.fundaCheck == null) + "\n" +
    //"GamePlayer ID: " + (GameManager.gamePlayer.id != "") + "\n" +
    //"GameOver State: " + (GameManager.gm.gameState != GameManager.gameStates.GameOver) + "\n" +
    //"NewName State: " + (GameManager.gm.gameState != GameManager.gameStates.newName));
    //}
    string platformID;
    protected IEnumerator platformIdCheck(string pid, string platformCode)
    {
		platformID = platformCode;
        float tUp = Time.time + 120f;
        print(
            "Connection Made: " + (GameManager.conMade) + "\n" +
            "FundaCheck: " + (GameManager.fundaCheck == null) + "\n" +
            "GamePlayer ID: " + (GameManager.gamePlayer.id != "") + "\n" +
            "GameOver State: " + (GameManager.gm.gameState != GameManager.gameStates.GameOver) + "\n" +
            "NewName State: " + (GameManager.gm.gameState != GameManager.gameStates.newName));
        yield return new WaitUntil(() =>
        GameManager.conMade &&
        GameManager.fundaCheck == null &&
        GameManager.gamePlayer.id != "" &&
        GameManager.gm.gameState != GameManager.gameStates.GameOver &&
        GameManager.gm.gameState != GameManager.gameStates.newName);// || Time.time > tUp);

        //tutorial is done and platform hasn't been done before
        if (GameManager.conMade
            && GameManager.fundaCheck == null
            && GameManager.gamePlayer.id != ""
            && GameManager.gm.gameState != GameManager.gameStates.GameOver
            && GameManager.gm.gameState != GameManager.gameStates.newName
            //&& PlayerPrefs.HasKey(GameManager.tutorialKey)
            && !PlayerPrefs.HasKey(restoreKey))
        {
#if UNITY_ANDROID
            GameManager.gamePlayer.go = pid;
#elif UNITY_WSA
            GameManager.gamePlayer.mi = pid;
#endif
            dataControl.savePlayer(GameManager.gamePlayer);
            StartCoroutine(GameManager.client.InvokeApi<Message, jointSynch>("sampleGetPlatformInfo", RESTClient.Method.POST, Message.Create(pid, platformID), platformIdCheckComplete));
            print("checking platform now");
        }
        else if (!PlayerPrefs.HasKey(restoreKey)) StartCoroutine(platformIdCheck(pid,platformID));
        //yield return null;
    }

    restoreControl rc;
    void platformIdCheckComplete(RESTClient.IRestResponse<jointSynch[]> res)
    {
        if (res.IsError)
        {
            Debug.Log("Couldn't get player's platform information Status:" + res.StatusCode + " Url: " + res.Url);
            return;
        }

        jointSynch[] pl = res.Data;
        Debug.Log("On getting player information complete: " + res.Url + " data: " + res.Content);
        if (pl[0].id != "none")
        {
            print("record of player exists, checking for items..");
            rc = new restoreControl
            {
                cloudJoint = pl[0]
            };
            StartCoroutine(GameManager.client.InvokeApi<Message, playerItem>("sampleGgetPlayerItems", RESTClient.Method.POST, Message.Create(pl[0].id), OnItemRestoreCompleted));
        }
        //no record with platform key
        else
        {
            print("no record, about to synch platform id");
            //GameManager.gamePlayer.go = pl[0].go;
            dataControl.savePlayer(GameManager.gamePlayer);
            PlayerPrefs.SetInt(newIdKey, 0);
            PlayerPrefs.SetInt(restoreKey, 0);

            //appempting to synch here
            if (GameManager.fundaCheck == null && (GameManager.gamePlayer.id != null && GameManager.gamePlayer.id != ""))
            {
				string platID="";
#if UNITY_ANDROID
               /* if(platformID=="go")*/platID = GameManager.gamePlayer.go;
#elif UNITY_WSA
				/*else if(platformID=="mi")*/platID = GameManager.gamePlayer.mi;
#endif
                GameManager.fundaCheck = StartCoroutine(GameManager.client.InvokeApi<Message, Message>
                    ("sampleFirstUpdate", RESTClient.Method.POST,
                    Message.Create(/*GameManager.gamePlayer.go*/ platID, GameManager.gamePlayer.id, platformID),
                    GameManager.playerUpdateComplete));
            }
        }


    }

    private void OnItemRestoreCompleted(RESTClient.IRestResponse<playerItem[]> response)
    {
        if (response.IsError)
        {
            Debug.LogWarning("Read Item Restore Status:" + response.StatusCode + " Url: " + response.Url);
            return;
        }
        Debug.Log("On getting player items complete: " + response.Url + " data: " + response.Content);

        rc.cloudItems = response.Data;
        print("items, if any, retrieved");
        GameObject g = Instantiate(Resources.Load("begin/restoreCanvas", typeof(GameObject))) as GameObject;
        Canvas c = g.GetComponent<Canvas>();
        c.worldCamera = Camera.main;
        c.planeDistance = 3f;
        g.GetComponent<restoreManager>().restoreInfoShow(rc);
    }
}
