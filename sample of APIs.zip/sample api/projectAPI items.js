//These APIs were created to facilitate the functions that were needed to carry out for the
//mantanence of the database


//this append the number of times an item is purchased by the user
module.exports = {
    "post": function (req, res, next) {
        var check = "select top 1 id from samplePlayer where id = @i";
        var checkQuery = 
        {
            sql: check,
            parameters: [{name: 'i', value: req.body.samplePlayerid}]
            
        };
        
        var insert0 = "insert into samplePlayer_sampleItem (samplePlayerid, sampleItemid, permanent,boughtAt) values (@p,@i,@pe,@b)";
        var query0 = 
        {
            sql: insert0,
            parameters: [{name: 'p', value: req.body.samplePlayerid}
                , {name: 'i', value: req.body.sampleItemid}
				, {name: 'pe', value: req.body.perm}
                , {name: 'b', value: req.body.boughtAt}
                ]
        };
        var insert = "update sampleItem set icount = icount+@p2 where iid = @p1";
        var query = {
            sql: insert,
            parameters: [{ name: 'p1', value: req.body.sampleItemid}
                ,{ name: 'p2', value: req.body.count}
                ]
        };
        
        req.azureMobile.data.execute(query).then(function(results){
			//if adding sampleItem to samplePlayer's records
			if (req.body.ifNew == true)
			{
                //checking if samplePlayer exists in records
                req.azureMobile.data.execute(checkQuery).then(function(results3){
                 if  (results3.length > 0)
                 {  
                     console.log("samplePlayer existing info:"+results3);
                     req.azureMobile.data.execute(query0).then(function(results2){
                         //res.send(200, { message :req.body.sampleItemid+"Append" });//sending 'message' back
                         res.status(200).send({ message :req.body.sampleItemid+"Append" });
                         });
                 
                 }
                 else 
                 {
                     //if samplePlayer id isnt found, probably because they have been deleted
                     res.send(200, { message : req.body.sampleItemid+"Update" });//sending 'message' back
                     
                 }
            });
			}
			//if time has run out/ or is not permanent sampleItem
			else 
			{
                res.send(200, { message : req.body.sampleItemid+"Update" });//sending 'message' back						
			}

        });
    }
};

//this deletes a user from the database
module.exports = {
    "post": function (req, res, next) {
        var update1 = "delete from samplePlayer where id =@p";
        var query = {
            sql:update1,
            parameters: [
                {name: 'p', value: req.body.message}
                ]
            //,multiple:true
        };
        req.azureMobile.data.execute(query).then(function(results){
            console.log('results',results);
            console.log('samplePlayer deleted: ',req.body.message);
            //res.json(results);
             //res.send(200,results);
             res.status(200).send({message: "delete successful"});
        });
    }
};

//This inserts a new user into the database when the user uses the app for the first time
module.exports = {
    "post": function (req, res, next) {        
            console.log('Insertion Attempt started');

            var query = {
                sql:"select pname as 'samplePlayerId' from samplePlayer where pname = @p",
                parameters: [{ name: 'p', value: req.body.samplePlayerId}]
                //multiple:true
                };
            req.azureMobile.data.execute(query).then(function(results){
                if(!results||results==null || results == '')
                {
                    console.log('Name NOT found, proceding with inserts');
                var query1 = {
                    //sql:"insert into samplePlayer (pname, coins, fbId, twitterId, googleId, microId, iosId) values(@p1,@p2,@p3,@p4,@p5,@p6,@p7)", 
                    sql:"insert into samplePlayer (pname, coins) values(@p1,@p2)", 
                    parameters: [
                        { name: 'p1', value: req.body.samplePlayerId}, 
                        { name: 'p2', value: req.body.coins}//,
                        //{ name: 'p3', value: req.body.fb},
                        //{ name: 'p4', value: req.body.tw},
                        //{ name: 'p5', value: req.body.go},
                        //{ name: 'p6', value: req.body.mi},
                        //{ name: 'p7', value: req.body.io}
                        ]
                };
                var query2 = {
                    sql:"insert into sampleHighscore (sampleWeaponid, samplePlayerid, score) values(@p1,(select id from samplePlayer where pname = @p2),@p3)", 
                    parameters: [
                        { name: 'p1', value: req.body.sampleWeaponId}, 
                        { name: 'p2', value: req.body.samplePlayerId},
                        { name: 'p3', value: req.body.score}
                        ]
                };
                
                var query3 = 
                {
                    sql: "insert into samplePlayer_sampleMission (mname,samplePlayerid,sampleMissionDate) values ('none',(select id from samplePlayer where pname = @p), @p2 )",/*GETDATE()*/
                    parameters: [{ name: 'p', value: req.body.samplePlayerId},{ name: 'p2', value: req.body.sampleMissionDate}]
                };
                
                var query4 = {
                    sql:"select id as 'samplePlayerId' from samplePlayer where samplePlayer.pname = @p", 
                    parameters: [{ name: 'p', value: req.body.samplePlayerId}]
                };
                //inserting into samplePlayer
                req.azureMobile.data.execute(query1).then(function(results1)
                    {
                        console.log('samplePlayer inserted');
                        //inserting into sampleHighscore
                        req.azureMobile.data.execute(query2).then(function(results2)
                            {
                                console.log('sampleHighscore inserted');
                                //inserting sampleMission
                                req.azureMobile.data.execute(query3).then(function(results3)
                                    {
                                        console.log('sampleMission inserted');
                                        //retrieving from samplePlayer
                                        req.azureMobile.data.execute(query4).then(function(results4)
                                            {
                                                console.log('results: ' ,results4);
                                                res.status(200).send(results4); 
                                                //res.json(results3);
                                            });
                                    });
                            });
                    });
                }
                
                else 
                {
                    console.log('Name found here bruh: ', results);            
                    res.status(200).send(results);   
                }
                
                });
    }};


//This is in case the user wasnt able to synch for the first time, this would be inserting into the database a new high score as well
module.exports = {
    "post": function (req, res, next) {

    var updateQuery;

            //if name 
    if (req.body.note=='name')
    {

                console.log('Update name attempt');
                var uQuery = {
                    sql:"select pname as 'samplePlayerId' from samplePlayer where pname = @p",
                    parameters: [{ name: 'p', value: req.body.message}]
                    //multiple:true
                    };
                    req.azureMobile.data.execute(uQuery).then(function(uResults){
                        if(!uResults||uResults==null || uResults == '')
                        {
                            console.log('name not found, continuing with update');
                            updateQuery ={ 
                                sql: "update samplePlayer set pname = @p where id = @p2",
                                parameters: [{ name: 'p', value: req.body.message},{ name: 'p2', value: req.body.title}]
                                };
                                console.log('updating samplePlayer name');
                                req.azureMobile.data.execute(updateQuery).then(function(updateResults){
                                    res.status(200).send({message : req.body.title});
                                    });    
                        }
                        else 
                        {

                            console.log('name found, update ends here ');
                            //res.status(200).send(uResults);  
                            res.status(200).send({message: req.body.message});
                            return;
                        }

                        });
                    
            //}
            }
            else if(req.body.note=='go')
            {
                console.log('updating google id');
                updateQuery ={
                    sql: "update samplePlayer set googleId = @p where id = @p2",
                    parameters: [{ name: 'p', value: req.body.message},{ name: 'p2', value: req.body.title}]
                    };
                    console.log('updating samplePlayer google id here');
                    req.azureMobile.data.execute(updateQuery).then(function(updateResults){
                        res.status(200).send({message : req.body.title});
                        });
                        }
            else if(req.body.note=='mi')
            {
                console.log('updating microsoft xBox id');
                updateQuery ={
                    sql: "update samplePlayer set winId = @p where id = @p2",
                    parameters: [{ name: 'p', value: req.body.message},{ name: 'p2', value: req.body.title}]
                    };
                    console.log('updating samplePlayer microsoft xBox id here');
                    req.azureMobile.data.execute(updateQuery).then(function(updateResults){
                        res.status(200).send({message : req.body.title});
                        });
                        }
            
    }
};

//this retrieves the avatars from the databse
module.exports = {
    "get": function (req, res, next) {
        var search1 = "select sampleAvatarid from sampleAvatar";
        var query = {sql:search1};
        console.log (req.body.message);
        req.azureMobile.data.execute(query).then(function(results){
            console.log('results',results);
             res.status(200).send(results);
        });
    }
};

//this retrieves the highscores from the database
module.exports = {
    "post": function (req, res, next) {
        var query = {
            sql:"select top 50 pname as 'samplePlayerId', score from samplePlayer, sampleHighscore where samplePlayer.id = sampleHighscore.samplePlayerid order by score desc",
            parameters: [{ name: 'p', value: req.body.message}]
            //multiple:true
        };
        req.azureMobile.data.execute(query).then(function(results){
            console.log('results: ' ,results);
            res.status(200).send(results); 
            //res.json(results3);
        });
    }
};

//this gets the mission info that was backed up in the database
module.exports = {
    "post": function (req, res, next) {
        var query = {
            sql:"select top 1 mname, curcount, maxcount, misc, sampleMissionDate, hourGift as 'hourly', dayGift as 'daily' from samplePlayer_sampleMission where samplePlayerid = @p",
            parameters: [{ name: 'p', value: req.body.message}]
            //multiple:true
        };
        req.azureMobile.data.execute(query).then(function(results){
            console.log('results: ',results);
            res.status(200).send(results); 
            //res.json(results3);
        });
    }
};

//this gets the player info in case the player is reinstlaling the app
module.exports = {    
    "post": function (req, res, next) {
        var query ;
        console.log('gettimg platform info now');
        if (req.body.title == "go"){
            query = {
                sql:"select top 1 id, pname as 'samplePlayerId',bought as 'buy', coins, score, sampleWeaponid as sampleWeaponId, mname, curcount, maxcount, misc, updatedAt, googleId as 'go' from samplePlayer, sampleHighscore, samplePlayer_sampleMission where samplePlayer.id = sampleHighscore.samplePlayerid and samplePlayer.id = samplePlayer_sampleMission.samplePlayerid and googleId = @p",
                parameters: [{ name: 'p', value: req.body.message}]
            //multiple:true
        };
        }
        else if (req.body.title == "mi"){
            query = {
                sql:"select top 1 id, pname as 'samplePlayerId',bought as 'buy', coins, score, sampleWeaponid as sampleWeaponId, mname, curcount, maxcount, misc, updatedAt, winId as 'mi' from samplePlayer, sampleHighscore, samplePlayer_sampleMission where samplePlayer.id = sampleHighscore.samplePlayerid and samplePlayer.id = samplePlayer_sampleMission.samplePlayerid and winId = @p",
                parameters: [{ name: 'p', value: req.body.message}]
            //multiple:true
        };
        }
        req.azureMobile.data.execute(query).then(function(results){
            console.log('platform info results: ',results);
            if(!results||results==null || results == '')
            {
                if (req.body.title == "go"){res.status(200).send([{id: "none", go:req.body.message }]);}
                else if (req.body.title == "mi"){res.status(200).send([{id: "none", mi:req.body.message }]);}
            }
            else
            {
                res.status(200).send(results);
            }
            //res.json(results3);
        });
    }
};

//this gets the info of the player
module.exports = {
    "post": function (req, res, next) {
        var query = {
            sql:"select top 1 id, pname as 'samplePlayerId',bought as 'buy', coins, score,googleId as 'go', sampleWeaponid as 'sampleWeaponId', mname, curcount, maxcount, misc from samplePlayer, sampleHighscore, samplePlayer_sampleMission where samplePlayer.id = @p and sampleHighscore.samplePlayerid = @p and samplePlayer_sampleMission.samplePlayerid = @p",
            parameters: [{ name: 'p', value: req.body.message}]
            //multiple:true
        };
        
        req.azureMobile.data.execute(query).then(function(results){
            console.log('results: ' ,results);
            res.status(200).send(results); 
            //res.json(results3);
        });
    }
};

//this verifies if the player has info in the database from past installations 
module.exports = {
    "post": function (req, res, next) {
        var search1 = "select sampleItemid, boughtAt, permanent as 'perm' from samplePlayer_sampleItem where samplePlayerid = @p1";
        var query = {
            sql:search1,
            parameters: [{name: 'p1', value: req.body.message}]
            //,multiple:true
        };
        console.log (req.body.message);
        req.azureMobile.data.execute(query).then(function(results){
            console.log('results',results);
            //res.json(results);
             //res.send(200,results);
             res.status(200).send(results);
        });
    }
};


//makeCon
module.exports = {
    "get": function (req, res, next) {
    console.log ("connection made to server");
    res.status(200).send({message: "conMade"});
    }
};



//this synchs the the user's new info if he/she has more coins, new highscore and/or mission update
module.exports = {
    "post": function (req, res, next) {
        //if coins to be updated
        if (req.body.ifCoins==true)
        {
            console.log('suppose to update coins');
            var insert0 = "update samplePlayer set coins = @p1, updatedAt = getutcdate() where id = @p2";
            var query1 = 
            {
                sql: insert0,
                parameters: [
                    {name: 'p1', value: req.body.coins},
                    {name: 'p2', value: req.body.id}
                    ]
                    };
                req.azureMobile.data.execute(query1).then(function(results){
                        if (req.body.ifScore==false && req.body.ifsampleMission == false)
                        {
                            //sending 'message' back
                            //res.send(200, { message :"coins updated alone" });
                            res.status(200).send({ message :"coins updated alone" });
                        }
                    });
        }
        //if score is to be updated
        if (req.body.ifScore==true)
        {
            console.log('suppose to update score');
            var insert = "update sampleHighscore set score = @p1, sampleWeaponid = @p2 where samplePlayerid = @p3";
            var query2 = {
                sql: insert,
                parameters: [
                    { name: 'p1', value: req.body.score},
                    { name: 'p2', value: req.body.sampleWeaponId},
                    { name: 'p3', value: req.body.id}
                    ]
                    };
                    
               req.azureMobile.data.execute(query2).then(function(results2){
                   if (req.body.ifCoins==false && req.body.ifsampleMission == false) 
                   {
                       res.status(200).send({ message :"sampleHighscore updated alone" });//sending 'message' back
                   }
                   });
        }
        //if sampleMission is to be updated
        if (req.body.ifsampleMission==true)
        {
            console.log('suppose to update sampleMission');
            var insert1;
            var query1;
            if (req.body.ifsampleMissionDone == true) 
            {
                insert1 = "begin update samplePlayer_sampleMission set mname = 'none', curcount = 0, maxcount = 0, misc = '', sampleMissionDate = @p where samplePlayerid = @i; update sampleMission set mcount = mcount+1 where mname = @m; end;";
                query1 = {
                    sql: insert1,
                    parameters: [
                    { name: 'm', value: req.body.mname},
                    { name: 'p', value: req.body.sampleMissionDate},
                    { name: 'i', value: req.body.id}
                    ]
                    };
            
            
            }
            else 
            {
                insert1 = "update samplePlayer_sampleMission set mname = @mn, curcount = @p1, maxcount = @p2, misc = @p3 where samplePlayerid = @i";
                query1 = {
                sql: insert1,
                parameters: [
                    { name: 'mn', value: req.body.mname},
                    { name: 'p1', value: req.body.curcount},
                    { name: 'p2', value: req.body.maxcount},
                    { name: 'p3', value: req.body.misc},
                    { name: 'i', value: req.body.id}
                    ]
                    };
            }
            req.azureMobile.data.execute(query1).then(function(results1){
                if (req.body.ifCoins==false && req.body.ifScore == false)
                {
                    res.status(200).send({ message :"sampleMission updated alone"});//sending 'message' back
                }
                });
        }
        if (req.body.ifScore==true && req.body.ifCoins==true && req.body.ifsampleMission==true)
        {
            res.status(200).send({ message :"coins and sampleHighscore and sampleMission updated bruh" });//sending 'message' back
        }
        else if (req.body.ifScore==true && req.body.ifCoins==true)
        {
            res.status(200).send({ message :"coins and sampleHighscore updated bruh" });//sending 'message' back
        }
        else if (req.body.ifsampleMission==true && req.body.ifCoins==true)
        {
            res.status(200).send({ message :"coins and sampleMission updated bruh" });//sending 'message' back
        }
        else if (req.body.ifScore==true && req.body.ifsampleMission==true)
        {
            res.status(200).send({ message :"sampleMission and sampleHighscore updated bruh" });//sending 'message' back
        }
    }
};

//this registers an item as purchased
module.exports = {
        "post": function (req, res, next) {
                var insert = "update samplePlayer set bought = 1 where id = @p1";
                var query = {
                sql: insert,
                parameters: [
                    { name: 'p1', value: req.body.message}
                    ]
                    };
                    req.azureMobile.data.execute(query).then(function(results){
            console.log('results',results);
            //res.json(results);
             //res.send(200,results);
             res.status(200).send({message: req.body.message});
             
        });
        }
};
