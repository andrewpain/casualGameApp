begin

--drop table sampleHighscore, samplePlayer_sampleItem, sampleAvatar_type, sampleWeapon_type, sampleAvatar ,sampleWeapon , sampleUtiltype, sampleShotype,sampleItem ,samplePlayer_sampleMission, sampleMission, samplePlayer;
--drop trigger sampleItemTypeCheck;
--create table country 
--(
--countryid varchar(2),
--countryname varchar(40)
--)

create table samplePlayer
(
id varchar(36) primary key default newid(),
bought bit not null default 0,
--fbId nvarchar(255),
--twitterId nvarchar(255),
googleId nvarchar(100),
--microId nvarchar(255),
--iosId nvarchar(255),
createdAt smalldatetime default getutcdate(),
updatedAt smalldatetime default getutcdate(), 
pname nvarchar(40) not null,
coins int not null default 0,
constraint uk_pn unique (pname),
);

create table sampleMission(
mname varchar(50) primary key,
mdesc varchar(60) not null,
mcount int default 0
);

--note: when samplePlayer can do multiple sampleMissions at once, the unique key uk_pm should be removed
create table samplePlayer_sampleMission(
curcount float not null default 0,
maxcount float not null default 1,
mname varchar(50) not null,
samplePlayerid varchar(36) not null,
sampleMissionDate varchar(40),
hourGift varchar(40),
dayGift varchar(40),
misc nvarchar(40),
constraint pk_pm primary key (mname, samplePlayerid),
constraint uk_pm unique (samplePlayerid),
constraint fk_pmm foreign key (mname) references sampleMission(mname) 
on update cascade on delete cascade,
constraint fk_pmp foreign key (samplePlayerid) references samplePlayer(id)
on update cascade on delete cascade
);

create table sampleItem (
iid varchar(40) not null primary key,
idesc varchar(60) not null,
icount float not null default 0,
itype char(1) not null 
constraint ch_it CHECK (itype = 'w' or itype = 'a')
);


create table sampleShotype(
sname varchar(20) primary key,
sdesc varchar(60) not null
);

create table sampleUtiltype(
uname varchar(20) primary key,
udesc varchar(60) not null
);

create table sampleWeapon(
sampleWeaponid varchar(40) primary key not null,
constraint fk_wi foreign key (sampleWeaponid) references sampleItem(iid)
on update cascade on delete cascade
);

create table sampleAvatar(
sampleAvatarid varchar(40) primary key not null,
constraint fk_ai foreign key (sampleAvatarid) references sampleItem(iid)
on update cascade on delete cascade
);

create table sampleWeapon_type(
sampleWeaponid varchar(40) not null,
sname varchar(20) not null,
constraint pk_ws primary key (sampleWeaponid,sname),
constraint fk_wtw foreign key (sampleWeaponid) references sampleWeapon(sampleWeaponid)
on update cascade on delete cascade,
constraint fk_wts foreign key (sname) references sampleShotype(sname)
on update cascade on delete cascade
);

create table sampleAvatar_type(
sampleAvatarid varchar(40) not null,
uname varchar(20) not null,
constraint pk_au primary key (sampleAvatarid,uname),
constraint fk_ata foreign key (sampleAvatarid) references sampleAvatar(sampleAvatarid)
on update cascade on delete cascade,
constraint fk_atu foreign key (uname) references sampleUtiltype(uname)
on update cascade on delete cascade
);

--note: no primary key incase the off chance occurs that DBA deletes record just before samplePlayer updates the record of the sampleItem
create table samplePlayer_sampleItem(
samplePlayerid varchar(36) not null,
sampleItemid varchar(40) not null,
permanent bit not null,
boughtAt nvarchar(40),
constraint fk_pii foreign key (sampleItemid) references sampleItem(iid)
on update cascade on delete cascade,
constraint fk_pip foreign key (samplePlayerid) references samplePlayer(id)
on update cascade on delete cascade);

create table sampleHighscore(
--countryid char(2),
score float not null default 0,
samplePlayerid varchar(36) not null,
sampleWeaponid varchar(40) not null,
--constraint uk_hs unique (samplePlayerid),
constraint pk_hs primary key (samplePlayerid),
constraint fk_hswt foreign key (sampleWeaponid) references sampleWeapon(sampleWeaponid)
on update cascade on delete cascade,
constraint fk_hsp foreign key (samplePlayerid) references samplePlayer(id)
on update cascade on delete cascade
);

--putting end here since trigger needs the table to exist in order for it to be created
end;


--trigger for when sampleItem is inserted or updated, to add/delete sampleWeapon/sampleAvatar record from sampleAvatar/sampleWeapon tables
CREATE TRIGGER sampleItemTypeCheck 
ON sampleItem
AFTER INSERT, UPDATE   
AS
PRINT 'trigger is running';
if (UPDATE(itype))
begin
--DECLARE @it char(1) = select iid, itype from inserted;
declare @sampleItemId varchar(40);
declare @sampleItemType char(1);

DECLARE sampleItems CURSOR FOR  
SELECT iid, itype from inserted;

OPEN sampleItems;  

-- Perform the first fetch.  
FETCH NEXT FROM sampleItems into @sampleItemId, @sampleItemType;  

-- Check @@FETCH_STATUS to see if there are any more rows to fetch.  
WHILE @@FETCH_STATUS = 0  
BEGIN  
--deleting
if (@sampleItemType = 'w')
begin
 delete from sampleAvatar where sampleAvatarid = @sampleItemId;
 insert into sampleWeapon values (@sampleItemId);
end;
else if (@sampleItemType = 'a')
begin
 delete from sampleWeapon where sampleWeaponid = @sampleItemId;
 insert into sampleAvatar values (@sampleItemId);
end;
--setting
--if (@sampleItemType = 'w')insert into sampleWeapon values (@sampleItemId);
--else if (@sampleItemType = 'a') insert into sampleAvatar values (@sampleItemId);

FETCH NEXT FROM sampleItems into @sampleItemId, @sampleItemType;  

END  

CLOSE sampleItems;  
DEALLOCATE sampleItems; 

PRINT 'trigger is finished';
end;



